# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
#class TutorialPipeline(object):
#    def process_item(self, item, spider):
#        return item
from sqlalchemy.orm import sessionmaker
from models import Dmoz, db_connect, create_dmoz_table

class TutorialPipeline(object):
   def __init__(self):
       engine = db_connect()
       create_dmoz_table(engine)
       self.Session = sessionmaker(bind=engine)
       self.Session.configure(bind=engine)
       
 
   def process_item(self, item, spider):
        session = self.Session()
        dmoz = Dmoz(**item)
        try:
            session.add(dmoz)
            session.commit()
        except:
            print "**"*100
            print "lcy:error"
        finally:
            return item

