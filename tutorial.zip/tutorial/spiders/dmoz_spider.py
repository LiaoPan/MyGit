# -*- coding: utf-8 -*-
#encoding=utf-8
import datetime
import os
import re
import sys
reload(sys) 
sys.setdefaultencoding('utf-8')
import scrapy
from scrapy.selector import Selector
from tutorial.items import DmozItem
from scrapy.http import Request,FormRequest
from scrapy.selector import HtmlXPathSelector
#from scrapy import log
import mysql.connector
import pdb
#from scrapy.spider import BaseSpider
#import MySQLdb
class DmozSpider(scrapy.Spider):
    name = "dmoz"
    #def __init__(self):
        #log.start()
    def start_requests(self):
   
        id_link = self.getUrls()
        i = 0
      
        '''
        while i<40:
            sigle_information=id_link[i]
            if (sigle_information[0]==i+1):
               
                #yield Request(sigle_information[1],callback=self.'parse'+str(i))
                print sigle_information[1]
            i=i+1
        '''
     
        #log.msg(id_link,level=log.INFO)
        #url='http://sec.chinabyte.com/'
   
        if(id_link[33][0]==34):
            #log.msg('test34',level=log.INFO)
            #test34 = id_link[33][1]
            #log.msg(test34,level=log.INFO)
            yield Request(id_link[33][1],callback=self.parse33)
            #log.msg('test34end',level=log.INFO)
        if(id_link[39][0]==40):
            #log.msg('test40',level=log.INFO)
            #test40 = id_link[39][1]
            #log.msg(test40,level=log.INFO)
            yield Request(id_link[39][1],callback=self.parse39)
            #log.msg('test40end',level=log.INFO)
      
        
        if(id_link[0][0]==1):
            start_urls=[id_link[0][1]]
            yield Request(id_link[0][1],callback=self.parse0)
            
        if(id_link[1][0]==2):
            yield Request(id_link[1][1],callback=self.parse1)
   
        if(id_link[2][0]==3):
            yield Request(id_link[2][1],callback=self.parse2)

        if(id_link[3][0]==4):
            yield Request(id_link[3][1],callback=self.parse3)
        
        if(id_link[4][0]==5):
            yield Request(id_link[4][1],callback=self.parse4)
        if(id_link[5][0]==6):
            yield Request(id_link[5][1],callback=self.parse5)
        if(id_link[6][0]==7):
            yield Request(id_link[6][1],callback=self.parse6)
        if(id_link[7][0]==8):
            yield Request(id_link[7][1],callback=self.parse7)
        if(id_link[8][0]==9):
            yield Request(id_link[8][1],callback=self.parse8)
        if(id_link[9][0]==10):
            yield Request(id_link[9][1],callback=self.parse9)
        if(id_link[10][0]==11):
            yield Request(id_link[10][1],callback=self.parse10)
        if(id_link[11][0]==12):
            yield Request(id_link[11][1],callback=self.parse11)
      
        if(id_link[12][0]==13):
            yield Request(id_link[12][1],callback=self.parse12)
          
     
        if(id_link[13][0]==14):
            yield Request(id_link[13][1],callback=self.parse13)
        
        if(id_link[14][0]==15):
            yield Request(id_link[14][1],callback=self.parse14)
      
        if(id_link[15][0]==16):
            yield Request(id_link[15][1],callback=self.parse15)
     
        if(id_link[16][0]==17):
            yield Request(id_link[16][1],callback=self.parse16)
        if(id_link[17][0]== 18):
            yield Request(id_link[17][1],callback=self.parse17)
        if(id_link[18][0]==19):
            yield Request(id_link[18][1],callback=self.parse18)
        if(id_link[19][0]==20):
            yield Request(id_link[19][1],callback=self.parse19)
        if(id_link[20][0]==21):
            yield Request(id_link[20][1],callback=self.parse20)
        if(id_link[21][0]==22):
            yield Request(id_link[21][1],callback=self.parse21)
        if(id_link[22][0]==23):
            yield Request(id_link[22][1],callback=self.parse21)
        if(id_link[23][0]==24):
            yield Request(id_link[23][1],callback=self.parse21)
        if(id_link[24][0]==25):
            yield Request(id_link[24][1],callback=self.parse21)
        if(id_link[25][0]==26):
            yield Request(id_link[25][1],callback=self.parse21)
        if(id_link[26][0]==27):
            yield Request(id_link[26][1],callback=self.parse26)
        if(id_link[27][0]==28):
            yield Request(id_link[27][1],callback=self.parse26)
        if(id_link[28][0]==29):
            yield Request(id_link[28][1],callback=self.parse26)
        if(id_link[29][0]==30):
            yield Request(id_link[29][1],callback=self.parse26)
        if(id_link[30][0]==31):
            yield Request(id_link[30][1],callback=self.parse26)
        if(id_link[31][0]==32):
            yield Request(id_link[31][1],callback=self.parse31)
     
        if(id_link[32][0]==33):
            #log.msg('test33',level=log.INFO)
            yield Request(id_link[32][1],callback=self.parse32)
      
        if(id_link[34][0]==35):
            yield Request(id_link[34][1],callback=self.parse34)
        if(id_link[35][0]==36):
            yield Request(id_link[35][1],callback=self.parse35)
        if(id_link[36][0]==37):
            yield Request(id_link[36][1],callback=self.parse35)
        if(id_link[37][0]==38):
            yield Request(id_link[37][1],callback=self.parse37)
  
        if(id_link[38][0]==39):
            yield Request(id_link[38][1],callback=self.parse38)

        if(id_link[40][0]==41):
            yield Request(id_link[40][1],callback=self.parse40)

     
        if(id_link[41][0]==42):
            yield Request(id_link[41][1],callback=self.parse41)

        if(id_link[42][0]==43):
            yield Request(id_link[42][1],callback=self.parse42)
      
        if(id_link[43][0]==44):
            yield Request(id_link[43][1],callback=self.parse43)    
  
        if(id_link[44][0]==45):
            yield Request(id_link[44][1],callback=self.parse44)          

        if(id_link[45][0]==46):
            yield Request(id_link[45][1],callback=self.parse44)

        if(id_link[46][0]==47):
            yield Request(id_link[46][1],callback=self.parse46)
 
        if(id_link[47][0]==48):
            yield Request(id_link[47][1],callback=self.parse47)
        if(id_link[48][0]==49):
            yield Request(id_link[48][1],callback=self.parse48)
      
        if(id_link[49][0]==50):
            yield Request(id_link[49][1],callback=self.parse49)
       

        if(id_link[50][0]==51):
            yield Request(id_link[50][1],callback=self.parse50)

           
        if(id_link[51][0]==52):
            yield Request(id_link[51][1],callback=self.parse51)

        if(id_link[52][0]==53):
            yield Request(id_link[52][1],callback=self.parse52)

        if(id_link[53][0]==54):
            yield Request(id_link[53][1],callback=self.parse53)

        if(id_link[54][0]==55):
            yield Request(id_link[54][1],callback=self.parse54)

        
          
    def getUrls(self):
        db = mysql.connector.connect(user="root",password="lcy492",database="spiderdb")	   
        cursor = db.cursor()
        information=[]
      
        sql = "select id,link from spiderdb.spider_table" 
        try:
            cursor.execute(sql)
            data = cursor.fetchall()
            for row in data:
                information.append(row)
           
         
        except:
            print "Error: unable to fetch data"
        finally:
            return information
    
 
 #比特网
   
    def parse0(self,response):
        #print response.body
        sel = Selector(response)   
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//ul/li/a[@title]/text()').extract())
        item['link'] = "".join(sel.xpath('ul/li/a/@href').extract())
        #print item['link']
        #print item['title']
        #yield item
#       pdb.set_trace()
#       yield item
        for page_url in sel.xpath('//ul/li/a/@href').extract():
            yield Request(page_url,callback=self.parse_page0)
#51CTO
    
    def parse1(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a[@title]/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            
            yield Request(page_url,callback=self.parse_page1)

#ZDNet      
    def parse2(self,response):           
        sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h3/a[@title]/text()").extract())
        item['link'] = "".join(sel.xpath("//h3/a/@href").extract())    
        for page_url in sel.xpath('//h3/a/@href').extract():
            yield Request(page_url,callback=self.parse_page2)

#freebuf网站爬取
    def parse3(self,response):          
        sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//dt/a[@title]/text()").extract())
        item['link'] = "".join(sel.xpath("//dt/a/@href").extract())
        for page_url in sel.xpath("//dt/a/@href").extract():
            yield Request(page_url,callback=self.parse_page3)
#hackbase黑基网
    def parse4(self,response):
        sel = Selector(response) 
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//a[@title]/text()").extract())
        item['link'] = "".join(sel.xpath("//a[@title]/@href").extract())
        for page_url in sel.xpath("//a[@title]/@href").extract():

            yield Request("http://www.hackbase.com"+page_url,callback=self.parse_page4)

#红黑联盟
    def parse5(self,response):           
        sel = Selector(response)     
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//dd[@class='list']/a/text()|//div[@class='LTitle']/h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//dd[@class='list']/a/@href|//div[@class='LTitle']/h3/a/@href").extract())
        for page_url in sel.xpath("//dd[@class='list']/a/@href|//div[@class='LTitle']/h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page5)

#硅谷动力网络安全
    def parse6(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h1/a[@title]/text()").extract())
        item['link'] = "".join(sel.xpath("//h1/a[@title]/@href").extract())
        for page_url in sel.xpath("//h1/a[@title]/@href").extract():
            yield Request(page_url,callback=self.parse_page6)
#360安全播报
    def parse7(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//a[@class='title']/text()").extract())
        item['link'] = "".join(sel.xpath("//a[@class='title']/@href").extract())
        for page_url in sel.xpath("//a[@class='title']/@href").extract():
            yield Request("http://bobao.360.cn"+page_url,callback=self.parse_page7)
#信息安全博士网
    def parse8(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            yield Request("http://www.secdoctor.com"+page_url,callback=self.parse_page8)
#http://www.securityfocus.com/爬取
    def parse9(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//span[@class='txtXSmall']/ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//span[@class='txtXSmall']/ul/li/a/@href").extract())
        for page_url in sel.xpath("//span[@class='txtXSmall']/ul/li/a/@href").extract():
            yield Request("http://www.securityfocus.com"+page_url,callback=self.parse_page9)
#绿盟科技
    def parse10(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//li/a/@href").extract())
        for page_url in sel.xpath("//li/a/@href").extract():
            yield Request("http://www.nsfocus.net"+page_url,callback=self.parse_page10)
#网界网安全
    def parse11(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//p/a[@class='TextListTitle']/text()").extract())
        item['link'] = "".join(sel.xpath("//p/a[@class='TextListTitle']/@href").extract())
        for page_url in sel.xpath("//p/a[@class='TextListTitle']/@href").extract():
            yield Request(page_url,callback=self.parse_page11)
 
#searchsecurity网
    def parse12(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//div[@class='listtitle']/a/text()").extract())
        item['link'] = "".join(sel.xpath("//div[@class='listtitle']/a/@href").extract())
        print item['link']
        for page_url in sel.xpath("//div[@class='listtitle']/a/@href").extract():
            print page_url
            yield Request("http://www.searchsecurity.com.cn"+page_url,callback=self.parse_page12)
        print 'ok3'

    def parse_page12(self, response):
	sel = Selector(response)
        item = DmozItem()
      
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath('//title/text()').extract())
        ts=sel.xpath("//div[@class='article']/div/p/span/text()").extract()
        if ts:
         
            find_num=re.findall(r"\d+",ts[0])
      
         
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
          
        else:
            item['time']=""           
        yield item
        
   

#电子信息产业网
    def parse13(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
      
        
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            yield Request("http://yjs.cena.com.cn/"+page_url,callback=self.parse_page13)

#新华网安全频道
    def parse14(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//li/h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//li/h3/a/@href").extract())
        for page_url in sel.xpath("//li/h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page14)
  
#人民网
    def parse15(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())

        for page_url in sel.xpath("//ul/li/a/@href").extract():
            url="http://it.people.com.cn"
            if url in page_url:
                yield Request(page_url,callback=self.parse_page15)
            else:                
                yield Request("http://it.people.com.cn"+page_url,callback=self.parse_page15)
  
#msn中文网
    def parse16(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//a/text()").extract())
        item['link'] = "".join(sel.xpath("//a/@href").extract())
        for page_url in sel.xpath("//a/@href").extract():
            yield Request("http://it.msn.com.cn/network/"+page_url,callback=self.parse_page16)
    def parse17(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//h3/a/@href").extract())
        for page_url in sel.xpath("//h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page17)
    def parse18(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//li/a/@href").extract())
        for page_url in sel.xpath("//li/a/@href").extract():
            yield Request(page_url,callback=self.parse_page18)
    def parse19(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//h3/a/@href").extract())
        for page_url in sel.xpath("//h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page19)
    def parse20(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//h3/a/@href").extract())
        for page_url in sel.xpath("//h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page20)
    def parse21(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//h3/a/@href").extract())
        for page_url in sel.xpath("//h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page21)
    def parse26(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//h3/a/text()").extract())
        item['link'] = "".join(sel.xpath("//h3/a/@href").extract())
        for page_url in sel.xpath("//h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page21)
    def parse31(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            yield Request("http://www.secdoctor.com"+page_url,callback=self.parse_page8)
   
    def parse32(self,response):
        #log.msg('test33test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            yield Request("http://www.secdoctor.com"+page_url,callback=self.parse_page32)
    
    def parse33(self,response):
        #test1 = response.url
        #log.msg('test34test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            yield Request("http://www.secdoctor.com"+page_url,callback=self.parse_page33)
        #log.msg('test34test1',level=log.INFO)    
    def parse34(self,response):
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())           
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            yield Request("http://www.secdoctor.com"+page_url,callback=self.parse_page33)
    def parse35(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//dl/dt/a/text()").extract())
        item['link'] = "".join(sel.xpath("//dl/dt/a/@href").extract())
        for page_url in sel.xpath("//dl/dt/a/@href").extract():
            yield Request(page_url,callback=self.parse_page1)
    def parse37(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//td/a/text()").extract())
        item['link'] = "".join(sel.xpath("//td/a/@href").extract())
        for page_url in sel.xpath("//td/a/@href").extract():
            yield Request(page_url,callback=self.parse_page1)
  
    def parse38(self,response):
        sel = Selector(response)       
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//a[@class='title']/text()").extract())
        item['link'] = "".join(sel.xpath("//a[@class='title']/@href").extract())
      
        for page_url in sel.xpath("//a[@class='title']/@href").extract():
            yield Request("http://bobao.360.cn"+page_url,callback=self.parse_page38)
   
    def parse39(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//ul/li/a/text()").extract())
        item['link'] = "".join(sel.xpath("//ul/li/a/@href").extract())
        for page_url in sel.xpath("//ul/li/a/@href").extract():
            print '*'*100
            print page_url
            yield Request("http://www.secdoctor.com"+page_url,callback=self.parse_page39)
  
    #IEEE国际会议开会日期
    def parse40(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        j=0
        mysign=sel.xpath("//div[@class='div-pad5b']")
        for s in mysign:
            item['link'] = sel.xpath("//div[@class='div-pad5b']/p/a/@href").extract()[j]
            item['title']=sel.xpath("//div[@class='div-pad5b']/p/a/text()").extract()[j]
            item['time']=sel.xpath("//p[@class='note']/text()").extract()[j]
            item['content']=sel.xpath("//div[@class='div-pad5b']/p/a/text()").extract()[j]
            yield item
            j=j+1
    #中国计算机学会会员推荐会议
    def parse41(self,response):
        sel = Selector(response)      
        item = DmozItem()
        mysign=sel.xpath("//a[@title]").extract()
        j=0
        for s in mysign:
            item['link'] = sel.xpath("//ul[@class='ulstyle2']/li/a/@href").extract()[j]
            item['time']=sel.xpath("//span[@class='']/text()").extract()[j]
            item['title']=sel.xpath("//a[@title]/span/text()").extract()[j]
            item['content']=sel.xpath("//a[@title]/span/text()").extract()[j]   
            yield item
            j=j+1
    def parse42(self,response):
        sel = Selector(response)      
        item = DmozItem()
        mysign=sel.xpath("//a[@title]").extract()
        j=0
        for s in mysign:
            item['link'] = sel.xpath("//ul[@class='ulstyle2']/li/a/@href").extract()[j]
            item['time']=sel.xpath("//span[@class='']/text()").extract()[j]
            item['title']=sel.xpath("//a[@title]/span/text()").extract()[j]
            item['content']=sel.xpath("//a[@title]/span/text()").extract()[j]   
            yield item
            j=j+1  
    def parse43(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = "".join(sel.xpath("//tr/td/a/@href").extract())
        for page_url in sel.xpath("//tr/td/a/@href").extract():
            yield Request("http://www.itsec.gov.cn"+page_url,callback=self.parse_page43)
            
    def parse_page43(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url 
        item['content'] ="".join(sel.xpath("//div[@class='paragraph']/p/text()").extract())
        ts=sel.xpath("//div[@class='artInfo']/span/text()").extract()        
        if ts:
            find_num=re.findall(r"\d+",ts[0])
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            item['time']=k
        else:
            item['time']=""
        yield item
       
    def parse44(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = "".join(sel.xpath("//tr/td/a/@href").extract())
        for page_url in sel.xpath("//tr/td/a/@href").extract():
            yield Request("http://www.itsec.gov.cn"+page_url,callback=self.parse_page44)
            
    def parse_page44(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url 
        item['content'] ="".join(sel.xpath("//div[@class='paragraph']/p/text()").extract())
        ts=sel.xpath("//div[@class='artInfo']/span/text()").extract()     
        if ts:
            find_num=re.findall(r"\d+",ts[0])
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            item['time']=k
        else:
            item['time']=""
        yield item
  
    def parse46(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = sel.xpath("//ul[@class='active_con']/li/a/@href").extract()
        print item['link']
        for page_url in sel.xpath("//ul[@class='active_con']/li/a/@href").extract():
            yield Request("http://www.cert.org.cn"+page_url,callback=self.parse_page46)
            
    def parse_page46(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//h2[@class="artil_tit"]/font/text()').extract())
        item['link'] = response.url 
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//h2[@class='artil_art']/text()").extract()
        if ts:
            find_num=re.findall(r"\d+",ts[0])
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            item['time']=k
        else:
            item['time']=""
        yield item
 
    #城堡网
    def parse47(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = "".join(sel.xpath("//tr/td[@class='1_t']/a/@href").extract())
        for page_url in sel.xpath("//ul[@class='slist']/li/a/@href").extract():
            yield Request("http://www.cbw365.com"+page_url,callback=self.parse_page47)
            
    def parse_page47(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url 
        item['content'] ="".join(sel.xpath("//span/text()").extract())
        ts=sel.xpath("//label/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            print "OK!"
            print find_num
            item['time']=find_num
        else:
            item['time']=""
        yield item
    def parse48(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = "".join(sel.xpath("//div/div/a/@href").extract())
        for page_url in sel.xpath("//div/div/a/@href").extract():
            yield Request("http://bobao.360.cn/"+page_url,callback=self.parse_page48)
            
    def parse_page48(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//h3/text()").extract()
        print 'ok1'
        print ts
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])
            item['time']=find_num[0]
        else:

            item['time']=""        
        yield item

    def parse49(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = "".join(sel.xpath("//div[@class='news']/h3/a/@href").extract())
        for page_url in sel.xpath("//div[@class='news']/h3/a/@href").extract():
            yield Request(page_url,callback=self.parse_page49)
            
    def parse_page49(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        print item['title']
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='summary']/text()").extract())
        print item['content']
        ts=sel.xpath("//span/text()").extract()
        print ts
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:

            item['time']=""        
        yield item

    def parse50(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        i=0
        item['link'] ="".join(sel.xpath("//td/a/@href").extract())
        for page_url in sel.xpath("//td/a/@href").extract():
            if i%2==0:
                yield Request(page_url,callback=self.parse_page50)
                print page_url
            i=i+1
            
    def parse_page50(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        print item['title']
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@align='left']/text()").extract())
        ts=sel.xpath("//div[@class='y']/text()").extract()
        if ts:
            find_num=re.findall(r"\d+",ts[0])[0]
        
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            item['time']=k
        else:
            item['time']=""
        yield item
    
 
    def parse51(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        item['link'] = "".join(sel.xpath("//h1/a/@href").extract())
        print item['link']
        for page_url in sel.xpath("//h1/a/@href").extract():
            yield Request(page_url,callback=self.parse_page51)
            
    def parse_page51(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//section[@id='bd_content']/div/p/text()").extract())
        #print item['content']
        ts=sel.xpath("//p[@class='info']/span[@class='date']/text()").extract()
        print ts
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            print find_num
            item['time']=find_num
            #print item['time']
        else:
            item['time']=""
        yield item

    def parse52(self,response):
        #log.msg('test10test',level=log.INFO)
        sel = Selector(response)      
        item = DmozItem()
        mysign=sel.xpath("//h4/a/@href").extract()
        j=0
        for i in mysign:
            item['link'] =sel.xpath("//h4/a/@href").extract()[j]
            item['title']=sel.xpath("//h4/a/text()").extract()[j]
           
            item['content']=sel.xpath("//h4/a/text()").extract()[j]
            ts =sel.xpath("//span[@class='bugs-time']/text()").extract()
            print ts
            if ts:
                find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[j])[0]
                item['time']=find_num
            else:
                item['time']=""
            yield item
            j=j+1

    def parse53(self,response):
        sel = Selector(response)      
        item = DmozItem()
        mysign=sel.xpath("//td/a/text()").extract()
        j=0
        for s in mysign:
            item['link'] ="http://www.wooyun.org"+sel.xpath("//td/a/@href").extract()[j]
            item['title']=sel.xpath("//td/a/text()").extract()[j]
            item['content']=sel.xpath("//td/a/text()").extract()[j]
            item['time']=sel.xpath("//th/text()").extract()[j]

            yield item
            j=j+1
    
    def parse54(self,response):
        sel = Selector(response)      
        item = DmozItem()
        mysign=sel.xpath("//div[@class='ld-lsit-info']").extract()
      
        j=0
        for s in mysign:
            
            item['link'] ="https://butian.360.cn"+sel.xpath("//p[@class='list-view']/a/@href").extract()[j]
          
            item['title']=sel.xpath("//p[@class='list-view']/a/text()").extract()[j]
        
            item['content']=sel.xpath("//p[@class='list-view']/a/text()").extract()[j]
            ts=sel.xpath("//p/text()").extract()[j]
           
            if ts:
                find_num=re.findall(r"\d+",ts[0])
                k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
                item['time']=k
            else:
                item['time']=""
            yield item        
            j=j+1

#比特网
  
    def parse_page0(self, response):
        
        sel = Selector(response)
        #print sel
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        #item['content'] =sel.xpath('//div[@class="qu_ocn"]/p/text()').extract()
        item['content'] ="".join(sel.xpath("//div[@id='logincontent']/p/text()").extract())
        #item['time']="".join(sel.xpath('//span[@class="date"]/text()').extract())
        
        ts = sel.xpath('//span[@class="date"]/text()').extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""
        yield item
    
    def parse_page1(self, response):    
        sel = Selector(response)
        item = DmozItem()    
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url 
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//div[@class='msg']/div/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""
        yield item
 
    def parse_page2(self, response):
        sel = Selector(response)
        item = DmozItem()  
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='qu_ocn']/p/text()").extract())
        #ts=sel.xpath("//div[@class='qu_zuo']/p[position()<2]/text()").extract()
        ts=sel.xpath("//div[@class='qu_zuo']/p/text()").extract()        
        
        if ts:
                     
            find_num=re.findall(r'\d+',ts[0])
           
            
            if find_num:
                t=int(find_num[1])
                if (t<32):
                    k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
      
                    item['time']=k
                else:
                    k=datetime.date(int(find_num[1]),int(find_num[2]),int(find_num[3]))
      
                    item['time']=k
            else:
                find_num=re.findall(r'\d+',ts[1])
                t=int(find_num[1])
                if (t<32):
                
                    k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
          
                    item['time']=k
                else:
                    k=datetime.date(int(find_num[1]),int(find_num[2]),int(find_num[3]))
          
                    item['time']=k                    
                       
                       
        else:
            item['time']=""
        yield item

    def parse_page3(self, response):
        sel = Selector(response)
        item = DmozItem()     
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='contenttxt']/p/text()").extract())
        ts=sel.xpath("//div[@class='property']/span[@class='time']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""
        yield item
    def parse_page4(self, response):
        sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='content_text']/p/text()").extract())
        ts=sel.xpath("//div[@id='property']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""        
        yield item

    def parse_page5(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//dd[@id='Article']/p/text()").extract())
        ts=sel.xpath("//dd[@class='frinfo line_blue']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""     
        yield item

    def parse_page6(self, response):
	sel = Selector(response)
        item = DmozItem()  
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='wzjj']/text()").extract())
        ts=sel.xpath("//div[@class='autordate']/text()").extract()
        if ts:
            find_num=re.findall(r"\d+",ts[0])

            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            item['time']=k
        else:
            item['time']=""
        yield item        

    def parse_page7(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/span/text()").extract())
        ts=sel.xpath("//span[@class='time']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""            
        yield item
    def parse_page8(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='content']/p/text()").extract())
        ts=sel.xpath("//div[@class='info']/span/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""        
        yield item
    def parse_page9(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//div[@class='expanded']/a/text()").extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='content']/p/text()").extract())
        ts=sel.xpath("//span[@class='commentDate']/text()").extract()
        if ts:
            print "OK!!!"
            find_num=re.findall(r"\w{3,4} \d{2} \d{4}",ts[0])[0]
            dd=datetime.datetime.strptime(find_num,'%b %d %Y')
            t=dd.strftime('%Y-%m-%d')
            item['time']=t
        else:
            item['time']=""          
        yield item
    def parse_page10(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath("//div[@align='center']/b/text()").extract())
        item['link'] = response.url
        item['content'] =sel.xpath("//tr/td/text()").extract()[37]
        #item['time']="".join(sel.xpath('/tbody/tr/td[2]/table/tbody/tr/td/table[3]/tbody/tr[2]/td/text()[1]').extract())
        ts=sel.xpath('//tr/td/text()').extract()
        print 'ok'
        print ts
        print 'ok'
        
        print ts[34]
        if ts:
            find_num=re.findall(r"\d+",ts[34])
            print find_num
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            item['time']=k
        else:
            item['time']=""
        
        yield item
    def parse_page11(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//div[@class='contentTitle']/p/text()").extract()
        if ts:
            find_num=re.findall(r"\d+",ts[0])
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
     

            item['time']=k
        else:
            item['time']=""        
        yield item

    def parse_page13(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//div[@class='pub_date left']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""             
        yield item

    def parse_page14(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
            print "OK!!!"
            find_num=re.findall(r"\d+",ts[0])
            print find_num
            print "OK!!!"
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item


    def parse_page15(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='text']/div/p/text()").extract())
        ts=sel.xpath("//h5/span[@id='p_publishtime']/text()").extract()
        if ts:
            find_num=re.findall(r"\d+",ts[0])
            print find_num
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))
            
            #dd=datetime.datetime.strptime(find_num,'%Y年%m月%d日')
            #t=dd.strftime('%Y-%m-%d')

            item['time']=k
        else:
            item['time']=""             
        yield item

    def parse_page16(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//span[@class='nry_wxcc']/text()").extract()
        #ts=sel.xpath("//div[@class='pub_date left']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""     
        yield item

    def parse_page17(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
            print "OK!!!"
            find_num=re.findall(r"\d+",ts[0])
            print find_num
            print "OK!!!"
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item
    def parse_page18(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
            print "OK!!!"
            find_num=re.findall(r"\d+",ts[0])
            print find_num
            print "OK!!!"
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item
    def parse_page19(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
         
            find_num=re.findall(r"\d+",ts[0])
           
        
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item
    def parse_page20(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
            print "OK!!!"
            find_num=re.findall(r"\d+",ts[0])
            
          
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item
    def parse_page21(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
         
            find_num=re.findall(r"\d+",ts[0])
            
          
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item  
    def parse_page26(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@id='content']/p/text()").extract())
        ts=sel.xpath("//span[@id='pubtime']/text()").extract()
        if ts:
          
            find_num=re.findall(r"\d+",ts[0])
          
          
            k=datetime.date(int(find_num[0]),int(find_num[1]),int(find_num[2]))

            item['time']=k
        else:
            item['time']=""         
        yield item
 
    def parse_page32(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='content']/div/p/text()").extract())
        ts=sel.xpath("//div[@class='side-list-item']/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[2])[0]
          
            item['time']=find_num
        else:
            item['time']=""        
        yield item
    
    def parse_page33(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='content']/p/text()").extract())
        ts=sel.xpath("//div[@class='info']/span/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""        
        yield item
        #log.msg('test34test2',level=log.INFO) 
    def parse_page34(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//div[@class='content']/p/text()").extract())
        ts=sel.xpath("//div[@class='info']/span/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""        
        yield item
 

    def parse_page38(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] =sel.xpath("//p/text()").extract()[4]
        ts=sel.xpath("//h3/text()").extract()
        print 'ok1'
        print ts
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[7])
            item['time']=find_num[0]
        else:

            item['time']=""        
        yield item

    def parse_page39(self, response):
	sel = Selector(response)
        item = DmozItem()
        item['title'] = "".join(sel.xpath('//title/text()').extract())
        item['link'] = response.url
        item['content'] ="".join(sel.xpath("//p/text()").extract())
        ts=sel.xpath("//div[@class='info']/span/text()").extract()
        if ts:
            find_num=re.findall(r"\d{4}-\d{2}-\d{2}",ts[0])[0]
            item['time']=find_num
        else:
            item['time']=""        
        yield item
   
    
