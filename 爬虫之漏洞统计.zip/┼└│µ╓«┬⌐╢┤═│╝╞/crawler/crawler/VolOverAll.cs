﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.IO;


namespace crawler
{
    public class VolOverAll
    {
        // 使用单例模式
        private VolOverAll() { }

        //public static string DataBaseName = "W_NVD_20140710_jw_os_混vendor_stop";
        //public static string DataBaseName = "W_NVD_20140710_fenci_nvd";
        //public static string DataBaseName = "W_NVD_20140514";
        //public static string DataBaseName = "W_NVD_20140705_stopword";
        //public static string DataBaseName = "W_NVD_20140705_fenci_os_去掉vendor";
        //public static string DataBaseName = "W_NVD_20140705_jiangwei_os_去vendor_stopword";
        //public static string DataBaseName = "W_NVD_20140710_jw_os_混vendor_stop";
        //public static string DataBaseName = "W_NVD_20140705_time_vendor";
        //public static string DataBaseName = "W_NVD_20140705_jiangwei_os_去vendor_stopword_zengyi";
        //public static string DataBaseName = "W_NVD_20140609_7月上线";
        //public static string DataBaseName = "R_20140609";
        //public static string DataBaseName = "W_NVD_20140914_sf_cvss";
        //public static string DataBaseName = "W_NVD_20140928_sf_cvss";
        //public static string DataBaseName = "W_NVD_20141019_sf_cvss";
        //public static string DataBaseName = "W_NVD_20141031_sf_cvss";
        //public static string DataBaseName = "W_NVD_20141123_非nvd分类";
        //public static string DataBaseName = "W_NVD_20141127_非nvd分级";
        public static string DataBaseName = "1_crawler";
        public static string DataBaseIP = "127.0.0.1";
        public static string DataUid = "liu-PC\\liu";
        public static string DataPassword = "sqlserver";
        public static string datacode = "d://datacode//";


        public static string replace = "!@#$%&*!@#$%&*!@#$%&*";
        public static string replace2 = "@@@@@@@@@@$$$$$$$$$$&&&&&&&&&&##########";
        public static string replace_br = "@@@@@@@@@@$$$$$$$$$$&&&&&&&&&&##########suijishu0518893********";
        public static string replace_br2 = "22222";
        public static string documentText = "";
        public static int over_maxCishu = 0;

        //public static bool PauseString_Naviget = false;
        //public static bool DownloadString_Re = false;
        //public static bool DownloadString_next = false;
        public static int pause_redownload_nextdownload = 0;

        public static string Display_Messagebox = "";
        public static string Display_Messagebox2 = "";
        public static string Display_Messagebox3 = ""; //sql
        public static string Display_Messagebox4 = ""; //线程

        public static List<string> ls_path_temp = new List<string>();

        public static string receivePath = @"d:\";

        public static bool closewindow = false;
        public static List<string> ls_filename_chk = new List<string>();

    }
}
