﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

//29

//using XmlReader;

namespace crawler
{
    public partial class CrawlerDlg : Form
    {
        public CrawlerDlg()
        {
            InitializeComponent();
            webBrowser1.ScriptErrorsSuppressed = true;
            //url_txt.Text = "http://web.nvd.nist.gov/view/vuln/search-results?amp;cves=on";
            url_txt.Text = "http://www.securityfocus.com/cgi-bin/index.cgi?o=30&l=30&c=12";
            //url_txt.Text = "http://ivy.pconline.com.cn/adpuba/click?adid=341995&id=pc.xz.rjxz.xinxi.wytjsf.";
            textBox_num.Text = "当前站点第1个，当前站点共1个；已经完成0个，所有站点共1个 {1/1; 1/1} ";
            textBox_url.Text = "http://www.baidu.com";

            button_redownload.Enabled = false;
            button_downloadnext.Enabled = false;
            //checkBox_display_prompt.Checked = true;
            //checkBox_display_prompt3.Checked = true;
            chk_PauseContiune.Checked = true;
        }

        private void getInterface(XmlReader xmlR)
        {
            textBox_dancixunhuamiao1.Text = xmlR.DanCiXunHuanMiaoShu1;
            textBox_dancixunhuamiao1.Refresh();
            textBox_dancixunhuamiao.Text = xmlR.DanCiXunHuanMiaoShu2;
            textBox_dancixunhuamiao.Refresh();
            textBox_xunhuanlunshu.Text = xmlR.XunHuanLunShu;
            textBox_xunhuanlunshu.Refresh();
            textBox_tongziduan.Text = xmlR.ls_tongziduan[0];
            textBox_tongziduan.Refresh();
            textBox_PauseSecond.Text = xmlR.ZanTingMiaoShu;
            textBox_PauseSecond.Refresh();
            textBox_delay.Text = xmlR.YanShi;
            textBox_delay.Refresh();
        }

        XmlReader xmlR = null;
        string SQLSentence = "";
        bool flag_WriteClear = true;

        public int YiJingWanChengUrl = 0;
        private void GetXML_Click(object sender, EventArgs e)
        {
            //string TableName_Temp = "nvd_temp_new";
            //string Table_Content = "nvd_temp_new_content";
            //string Table_Content_ceshi = "nvd_temp_new_content_200_ceshi_b6";
            //string XmlName1 = "nvd1.xml";
            //string XmlName2 = "nvd2.xml";

            //string TableName_Temp = "CXSecurity_temp_new";
            //string Table_Content = "CXSecurity_temp_new_content";
            //string Table_Content_ceshi = "CXSecurity_temp_new_content_200_ceshi";
            //string XmlName1 = "CXSecurity1.xml";
            //string XmlName2 = "CXSecurity2.xml";

            //string TableName_Temp = "SecurityFocus_info_temp_new";
            //string Table_Content = "SecurityFocus_info_temp_new_content";
            //string Table_Content_ceshi = "SecurityFocus_info_temp_new_content_200_ceshi";
            //string XmlName1 = "SecurityFocus_info1.xml";
            //string XmlName2 = "SecurityFocus_info2.xml";

            //string TableName_Temp = "SecurityFocus_discussion_temp_new";
            //string Table_Content = "SecurityFocus_discussion_temp_new_content";
            //string Table_Content_ceshi = "SecurityFocus_discussion_temp_new_content_200_ceshi";
            //string XmlName1 = "SecurityFocus_discussion1.xml";
            //string XmlName2 = "SecurityFocus_discussion2.xml";

            //string TableName_Temp = "SecurityFocus_exploit_temp_new";
            //string Table_Content = "SecurityFocus_exploit_temp_new_content";
            //string Table_Content_ceshi = "SecurityFocus_exploit_temp_new_content_200_ceshi";
            //string XmlName1 = "SecurityFocus_exploit1.xml";
            //string XmlName2 = "SecurityFocus_exploit2.xml";

            //string TableName_Temp = "SecurityFocus_solution_temp_new";
            //string Table_Content = "SecurityFocus_solution_temp_new_content";
            //string Table_Content_ceshi = "SecurityFocus_solution_temp_new_content_200_ceshi";
            //string XmlName1 = "SecurityFocus_solution1.xml";
            //string XmlName2 = "SecurityFocus_solution2.xml";

            //string TableName_Temp = "SecurityFocus_references_temp_new";
            //string Table_Content = "SecurityFocus_references_temp_new_content";
            //string Table_Content_ceshi = "SecurityFocus_references_temp_new_content_200_ceshi";
            //string XmlName1 = "SecurityFocus_references1.xml";
            //string XmlName2 = "SecurityFocus_references2.xml";

            //string TableName_Temp = "EDB_remote_temp_new";
            //string Table_Content = "EDB_remote_temp_new_content";
            //string Table_Content_ceshi = "EDB_remote_temp_new_content_200_ceshi";
            //string XmlName1 = "EDB_remote1.xml";
            //string XmlName2 = "EDB_remote2.xml";

            if (TableName1.Text == "")
            {
                MessageBox.Show("xml文件名不能为空");
            }
            else
            {
                //xmlR = new XmlReader(TableName1.Text + ".xml", VolOverAll.datacode);
                //getInterface(xmlR);
                //xmlrc = new XmlReader_Content(TableName2.Text + ".xml", VolOverAll.datacode);

                //UpdateVul();
                reNew();
                crewler_to_remote();
            }
        }

        //更新漏洞
        //***********************************************************************
        //步骤：
        //1、获取列表
        //2、写入列表
        //3、下载漏洞
        //4、计算md5
        //5、判断下载的漏洞是否全部是新的
        //6、xmlR.startpage  = xmlR.startpage + xmlR.eachpage
        //  循环
        //7、更新入总库     
        //8、删除被更新条目
        //***********************************************************************
        //参数：
        //TableName_Temp        ：列表存如表
        //Table_Content         ：漏洞内容存如表
        //Table_Content_ceshi   ：所有漏洞所在表
        //XmlName1              ：xml1 存放漏洞列表的网页
        //XmlName2              ：xml2 存放漏洞内容的网页
        public void UpdateVul()
        {
            //flag_WriteClear = true
            //flag_newest表示当前下载是否全部为最新
            bool flag_newest = false;
            int maxCishu = 1;

            //list表名
            //string TableName_Temp = xmlR.Table_List_temp;
            string Table_List_temp = xmlR.Table_List_temp;
            //content表名
            //string Table_Content = xmlR.Table_Content_temp;
            string Table_Content_temp = xmlR.Table_Content_temp;
            //总表名
            //string Table_Content_ceshi = xmlR.Table_Content_Final;
            string Table_Content_Final = xmlR.Table_Content_Final;
            string XmlName1 = TableName1.Text;
            string XmlName2 = TableName2.Text;
            //最大循环次数
            int maxCishu_total = xmlR.maxCishu_total_int;

            //string str_names_length = "id int, vul_url nvarchar(MAX), vul_id nvarchar(50), datetime nvarchar(50), vul_url_integ nvarchar(MAX)";
            //CreateTableAfterSave(TableName_Temp, str_names_length);
            //int PageNumber = xmlR.PageNumber_int + xmlR.StartPage_buchong_int;
            int PageNumber = xmlR.PageNumber_int;

            // delete cxs_Content_temp table
            if (DBManager.OpSQLIfExist(Table_Content_temp))
            {
                SQLSentence = string.Format("delete from {0}", Table_Content_temp);
                DBManager.OpSQLWrite(SQLSentence);
            }

            while (flag_newest == false && maxCishu <= maxCishu_total)
            {
                VolOverAll.over_maxCishu = maxCishu;
                //获取列表
                YiJingWanChengUrl = 0;
                GetVulList(Table_List_temp);
                //List<List<string>> lls = GetVulList(TableName_Temp);
                //List<string> ls_AllNewList = lls[0];
                //列表写入数据库
                //WriteVulListToTempTable(lls, TableName_Temp);
                //获取page内容
                YiJingWanChengUrl = 0;
                List<SessionPage> ls_sp = GetVulContent(XmlName2, VolOverAll.datacode, Table_List_temp);
                //写入page内容
                WriteVulContent(ls_sp, Table_Content_temp);

                //判断是否更新到最新
                flag_newest = IfNewest(xmlR.IfNewest_int, Table_Content_Final, Table_Content_temp);
                //flag_newest = false;
                if (flag_newest == false)
                {
                    xmlR.StartPage_int = xmlR.StartPage_int + PageNumber;
                    xmlR.PageNumber_int = xmlR.PageNumber_int + PageNumber;
                }
                //flag_WriteClear = false;
                maxCishu = maxCishu + 1;

                StringHelper.MyMessagebox(maxCishu.ToString(), 1);
            }

            //string Table_Content_UpdateVul = Table_Content + "UpdateVul";
            //CreateTableAfterSave(Table_Content_UpdateVul, over_str_names_lengh);

        }

        public void reNew()
        {
            //list表名
            //string TableName_Temp = xmlR.Table_List_temp;
            //string Table_List_temp = xmlR.Table_List_temp;
            //content表名
            //string Table_Content = xmlR.Table_Content_temp;
            string Table_Content_temp = xmlR.Table_Content_temp;
            //总表名
            //string Table_Content_ceshi = xmlR.Table_Content_Final;
            string Table_Content_Final = xmlR.Table_Content_Final;
            string XmlName1 = TableName1.Text;
            string XmlName2 = TableName2.Text;

            //FieldReverse(Table_Content, "pagen desc, sn");
            FieldReverse(Table_Content_temp, "datetime");
            //获取更新列表
            DataTable dt_update = GetUpdateVul(Table_Content_Final, Table_Content_temp);
            int test1 = dt_update.Rows.Count;
            DataTable dt_new = GetNewVul(Table_Content_Final, Table_Content_temp);
            int test2 = dt_new.Rows.Count;
            //设定flag为update和new
            if (dt_update.Rows.Count > 0 || dt_new.Rows.Count > 0)
            {
                DBManager.OpSQLBackupMyNow(Table_Content_Final);
                DBManager.OpSQLUpdateField(Table_Content_Final, "UpdateNew", "old");
                DBManager.OpSQLUpdateField(Table_Content_temp, "UpdateNew", "update", dt_update);
                DBManager.OpSQLUpdateField(Table_Content_temp, "UpdateNew", "new", dt_new);
                //存入总库
                DBManager.OpSQLInsertInto(dt_update, Table_Content_Final, Table_Content_temp);
                DBManager.OpSQLInsertInto(dt_new, Table_Content_Final, Table_Content_temp);
                //单独存放 更新的漏洞 和 新加的漏洞
                string Table_Content_UpdateVul = Table_Content_temp + "UpdateVul";
                string Table_Content_NewVul = Table_Content_temp + "NewVul";
                DBManager.OpSQLClearTable(Table_Content_UpdateVul, true);
                DBManager.OpSQLClearTable(Table_Content_NewVul, true);
                DBManager.OpSQLInsertInto(dt_update, Table_Content_UpdateVul, Table_Content_temp);
                DBManager.OpSQLInsertInto(dt_new, Table_Content_NewVul, Table_Content_temp);
                //删除被更新的条目
                string Table_Content_UpdateVul_Old = Table_Content_temp + "UpdateVulOld";
                DBManager.OpSQLClearTable(Table_Content_UpdateVul_Old, true);
                DBManager.OpSQLInsertInto(dt_update, Table_Content_UpdateVul_Old, Table_Content_Final);
                DBManager.OpSQLDelete(Table_Content_Final, dt_update, "updatenew = 'old'");
            }
        }

        public void MyNaviget(Uri url, string lab, string flag_content, int subpage, int page)
        {
            //string test1 = webBrowser1.GetDocumentStr();
            //MessageBox.Show(webBrowser1.GetDocumentStr());
            //webBrowser1.Navigate("http://www.baidu.com");
            //Thread.Sleep(20);
            //MessageBox.Show(webBrowser1.GetDocumentStr());
            VolOverAll.documentText = "";
            //string test2 = webBrowser1.GetDocumentStr();

            closewindow_btn.Enabled = false;
            bool flag = false;
            bool flag_issame = false;
            //int waittime = 10;
            int waittime = System.Int32.Parse(textBox_xunhuanlunshu.Text);
            int counter = 0;
            int counter_ifsame = 0;
            for (int k = 0; k < waittime && flag == false; k++)
            {
                try
                {
                    webBrowser1.Navigate(url);
                }
                catch (Exception ex) { }

                WebBrowserReadyState loadStatus;
                //int waittime1 = 2000;
                int waittime1 = System.Int32.Parse(textBox_dancixunhuamiao1.Text) * 1000;
                //int waittime2 = 10000;
                int waittime2 = System.Int32.Parse(textBox_dancixunhuamiao.Text) * 1000;
                int counter1 = 1;
                int counter2 = 1;
                bool flagInter = false;
                while (true)
                {
                    Application.DoEvents();
                    //while (VolOverAll.PauseString_Naviget == "pause")
                    //{
                    //    Application.DoEvents();
                    //    Thread.Sleep(100);
                    //}

                    loadStatus = webBrowser1.ReadyState;

                    if ((loadStatus == WebBrowserReadyState.Loading) ||
                        (loadStatus == WebBrowserReadyState.Interactive))       //控制項已載入文件足夠多的部分，可進行有限的使用者互動，例如按一下已顯示的超連結。
                    {
                        //flag = true;
                        flagInter = true;
                        break;
                    }
                    else if (counter1 > waittime1)
                    {
                        break;
                    }

                    if (counter1 % 1000 == 0)
                    {
                        counter++;
                        OutTimeLabel.Text = string.Format("{0} 正在打开：{1}秒, counter1:{2}, k:{3}", lab, counter, counter1, k);
                    }
                    counter1++;
                    Thread.Sleep(1);
                }

                while (flagInter)
                {
                    Application.DoEvents();
                    //while (VolOverAll.PauseString_Naviget == "pause")
                    //{
                    //    Application.DoEvents();
                    //    Thread.Sleep(100);
                    //}

                    loadStatus = webBrowser1.ReadyState;
                    if (loadStatus == WebBrowserReadyState.Complete ||
                        loadStatus == WebBrowserReadyState.Loaded)
                    {
                        flag = true;
                        break;
                    }
                    else if (counter2 > waittime2)
                    {
                        break;
                    }

                    if (counter2 % 1000 == 0)
                    {
                        counter++;
                        OutTimeLabel.Text = string.Format("{0} 正在打开：{1}秒, counter1:{2}, counter2:{3}, k:{4}", lab, counter, counter1, counter2, k);
                    }
                    counter2++;
                    Thread.Sleep(1);
                }

                flag_issame = IfSame(webBrowser1.GetDocumentStr());
                if (flag_issame)
                {
                    if (flag == false && chb_zidongpanduanxiazaiwanbi.Checked)
                    {
                        string documentText = webBrowser1.GetDocumentStr();
                        List<int> num2 = new List<int>();

                        int num3 = System.Int32.Parse(textBox_tongziduan.Text);

                        if (flag_content == "list")
                        { num2 = IfComplete(documentText); }
                        else if (flag_content == "updatelist")
                        { num2 = IfComplete_UpdateList(documentText,page); }
                        else if (flag_content == "content")
                        { num2 = IfComplete_content(documentText,subpage); }

                        if (num2[1] >= System.Int32.Parse(textBox_tongziduan.Text))
                        {
                            flag = true;
                        }
                        //flag = IfComplete(documentText);
                        string str = string.Format("推测为打开正常");
                        StringHelper.MyMessagebox(str, 3);
                    }
                }
                else
                {
                    counter_ifsame = counter_ifsame + 1;
                    flag = false;
                    string str_temp = "null";
                    if (webBrowser1.GetDocumentStr() != null)
                    {
                        str_temp = webBrowser1.GetDocumentStr();
                        if (str_temp.Length > 150)
                        {
                            str_temp = str_temp.Substring(0,100);
                        }
                    }
                    IfErrorPage_txt.Text = string.Format("和上页相同，第{0}轮：{1}  document {2}", counter_ifsame,url, str_temp);
                    if (chb_jishishangyexiangtong.Checked && counter_ifsame > waittime)
                    {
                        flag = true;
                    }
                }

                if (flag == false)
                {
                    string str = string.Format("继续打开：count1:{0}, count2:{1}, k:{2}", counter1, counter2, k);
                    //MessageBox.Show(str);
                    StringHelper.MyMessagebox(str, 2);
                }
                else
                {
                    //string str = string.Format("打开正常：count1:{0}, count2:{1}, k:{2}", counter1, counter2, k);
                    //OutTimeLabel.Text = string.Format("{0} {1}", lab, str);
                    string str = string.Format("{0} 打开正常：共用时{1}秒, counter1:{2}, counter2:{3}, k:{4}", lab, counter, counter1, counter2, k);
                    OutTimeLabel.Text = str;
                    //MessageBox.Show(str);
                    StringHelper.MyMessagebox(str, 2);
                }
            }

            if (flag == false)
            {
                string str = string.Format("打开失败！count：{0}", counter);

                //MessageBox.Show(str);
                StringHelper.MyMessagebox(str, 1);

                VolOverAll.pause_redownload_nextdownload = 1;
                button_PauseNaviget.Text = "取消暂停";
                button_redownload.Enabled = true;
                button_downloadnext.Enabled = true;
            }

            closewindow_btn.Enabled = true;
        }
        //判断是否下载到了需要的内容
        public string last_str = "";
        public List<int> IfComplete(string documentText)
        {
            string str = "";
            //bool flag = false;
            int num = 0;
            int num2 = 0;
            int total = xmlR.ls_IfComplete.Count;

            for (int i = 0; i < xmlR.ls_IfComplete.Count; i++)
            {
                List<string> ls = HtmlReader.ExtractSection(documentText, xmlR.ls_IfComplete[i]);
                if (ls.Count > 0)
                {
                    //flag = true;
                    for (int j = 0; j < ls.Count; j++)
                    {
                        if (ls[j] != "")
                        {
                            //flag = false;
                            //break;
                            num = num + 1;
                        }
                        str = str + ls[j];
                    }
                    if (num > 0)
                    {
                        num2 = num2 + 1;
                        //if(num2 >= System.Int32.Parse(textBox_tongziduan.Text))
                        //{
                        //    break;
                        //}
                    }
                }
            }

            //判断是否和上一次一样，如果一样，说明没有打开新页面
            if (str == last_str)
            {
                num2 = 0;
            }
            else
            {
                last_str = str;
            }

            List<int> ls_int = new List<int>();
            ls_int.Add(total);
            ls_int.Add(num2);
            return ls_int;
        }

        public List<int> IfComplete_UpdateList(string documentText, int page)
        {
            string str = "";
            //bool flag = false;
            int num = 0;
            int num2 = 0;
            int total = xmlR.ls_IfComplete.Count;

            for (int i = 0; i < xmlR.ls_IfComplete.Count; i++)
            {
                num = 0;
                List<string> ls = HtmlReader.ExtractSection(documentText, xmlR.ls_IfComplete[i]);
                if (ls.Count > 0)
                {
                    //flag = true;
                    for (int j = 0; j < ls.Count; j++)
                    {
                        if (ls[j] != "")
                        {
                            //flag = false;
                            //break;
                            num = num + 1;
                        }
                        str = str + ls[j];
                    }

                    //最后一页
                    if(page == xmlR.Table_MaxPage_int - xmlR.StartPage_buchong_int && num > 0)
                    {
                        num2 = num2 + 30;
                    }
                    else if (num == xmlR.EachPage2_int)
                    {
                        num2 = num2 + 30;
                    }
                }
            }

            //判断是否和上一次一样，如果一样，说明没有打开新页面
            if (str == last_str)
            {
                num2 = 0;
            }
            else
            {
                last_str = str;
            }

            List<int> ls_int = new List<int>();
            ls_int.Add(total);
            ls_int.Add(num2);
            return ls_int;
        }

        public List<int> IfComplete_content(string documentText,int subpage)
        {
            string str = "";
            //bool flag = false;
            int num = 0;
            int num2 = 0;
            //int total = xmlR.ls_IfComplete.Count;
            int total = xmlrcs[subpage].ls_sessionpath.Count;

            for (int i = 0; i < xmlrcs[subpage].ls_sessionpath.Count; i++)
            {
                if (xmlrcs[subpage].ls_sessionComplete[i] != "neednot")
                {
                    List<string> ls = HtmlReader.ExtractSection(documentText, xmlrcs[subpage].ls_sessionpath[i]);
                    if (ls.Count > 0)
                    {
                        //flag = true;
                        for (int j = 0; j < ls.Count; j++)
                        {
                            if (ls[j] != "")
                            {
                                //flag = false;
                                //break;
                                num = num + 1;
                            }
                            str = str + ls[j];
                        }
                        if (num > 0)
                        {
                            num2 = num2 + 1;
                            if (num2 >= System.Int32.Parse(textBox_tongziduan.Text))
                            {
                                break;
                            }
                        }
                    }
                }
            }

            //判断是否和上一次一样，如果一样，说明没有打开新页面
            //if (str == last_str)
            //{
            //    num2 = 0;
            //}

            last_str = str;

            List<int> ls_int = new List<int>();
            ls_int.Add(total);
            ls_int.Add(num2);
            return ls_int;
        }

        string last_str2 = "";
        public bool IfSame2(string documentText)
        {
            string str = "";
            bool ifsame = false;

            //判断是否和上一次一样，如果一样，说明没有打开新页面
            if (str == last_str2)
            {
                ifsame = false;
            }
            else
            {
                ifsame = true;
            }
            last_str2 = str;

            return ifsame;
        }

        public bool IfSame(string documentText)
        {
            bool ifsame = false;

            //判断是否和上一次一样，如果一样，说明没有打开新页面
            if (documentText == last_str2)
            {
                ifsame = false;
            }
            else
            {
                ifsame = true;
            }
            last_str2 = documentText;

            return ifsame;
        }

        //判断是否更新到最新
        public bool IfNewest(int topnum, string TableContentCeshi, string TableContent)
        {
            bool ifexist = DBManager.OpSQLIfExist(TableContentCeshi);
            if (ifexist == false)
            {
                DBManager.OpSQLCreateTable_Delete_Src(TableContentCeshi, TableContent);                
            }

            SQLSentence = string.Format("select count(*) from {0} as a left join {1} as b", TableContentCeshi, TableContent)
                + string.Format(" on a.id = b.id and a.md5 = b.md5")
                + string.Format(" where a.id in (select top {0} id from {1} order by datetime desc)", topnum, TableContent)
                + string.Format(" and b.id is not null");
            int num = DBManager.OpSQLGetInt(SQLSentence);
            bool flag = false;
            if (num == topnum)
            {
                MessageBox.Show("num = '{0}'", num.ToString());
                flag = true;
            }
            return flag;
        }

        public DataTable GetUpdateVul(string TableContentCeshi, string TableContent)
        {
            SQLSentence = string.Format("select a.id from {0} as a left join {1} as b", TableContentCeshi, TableContent)
                + string.Format(" on a.id = b.id and a.md5 <> b.md5")
                + string.Format(" where a.id in (select top 10000 id from {0} order by datetime)", TableContent)
                + string.Format(" and b.id is not null");
            DataSet ds = DBManager.OpSQLGetTable(SQLSentence);

            DataTable dt = new DataTable();
            if(ds.Tables[0] != null)
                dt = ds.Tables[0];

            return dt;
        }

        public DataTable GetNewVul(string TableContentCeshi, string TableContent)
        {
            SQLSentence = string.Format("select id from {0}", TableContent)
                + string.Format(" where id not in (select id from {0})", TableContentCeshi)
                + string.Format(" order by datetime");
            DataSet ds = DBManager.OpSQLGetTable(SQLSentence);

            DataTable dt = new DataTable();
            if (ds.Tables[0] != null)
                dt = ds.Tables[0];

            return dt;
        }

        //将所有漏洞信息写入数据库中 ls_sp是漏洞列表 Table_Content是要写入的表，如果表不存在，会重新生成
        string over_str_names_lengh = "";

        public void WriteVulContent(List<SessionPage> ls_sp, string Table_Content)
        {
            string str_names = "id, url";
            string str_names_lengh = "id nvarchar(50), url nvarchar(max)";
            for (int i = 0; i < ls_sp[0].ls_name.Count; i++)
            {
                str_names = str_names + ", " + ls_sp[0].ls_name[i];
                //str_names_lengh = str_names_lengh + ", " + ls_sp[0].ls_name[i] + " " + ls_sp[0].ls_lengh[i];
                str_names_lengh = str_names_lengh + ", " + ls_sp[0].ls_name[i] + " " + "nvarchar(max)";
            }
            str_names = str_names + ", content, md5";
            str_names_lengh = str_names_lengh + ", content nvarchar(max), md5 nvarchar(max)";

            over_str_names_lengh = str_names_lengh;
            DBManager.OpSQLCreateTable(Table_Content, over_str_names_lengh, "");

            for (int page = 0; page < ls_sp.Count; page++)
            {
                WriteVulContent_single(ls_sp[page], Table_Content, str_names);
            }
        }


        //将一个漏洞信息写入数据库中 sp是一个漏洞的对象
        public void WriteVulContent_single(SessionPage sp, string Table_Content, string str_names)
        {
            List<string> ls_content = new List<string>();
            for (int i = 0; i < sp.ls_name.Count; i++ )
            {
                List<string> ls = sp.lls_content[i];
                ls_content.Add("");
                for(int j=0; j<ls.Count; j++)
                {                    
                    ls[j].Replace("[*]",VolOverAll.replace2);
                    if(ls_content[i] == "")
                        ls_content[i] = ls[j];
                    else
                        ls_content[i] = ls_content[i] + "[*]" + ls[j];
                }
            }

            string str_contents = "'" + sp.id + "', '" + sp.url + "'";
            string content = sp.id + "[***]" + sp.url;
            for (int i = 0; i < ls_content.Count; i++ )
            {
                ls_content[i] = ls_content[i].Replace("'","''");
                str_contents = str_contents + ", '" + ls_content[i] + "'";
                if(sp.ls_md5[i] == "")
                {
                    content = content + "[***]" + ls_content[i];
                }                
            }
            str_contents = str_contents + ", '" + content + "'";
            string md5 = StringHelper.Encrypt(content);
            str_contents = str_contents + ", '" + md5 + "'";

            //DBManager.OpSQLCreateTable_AfterSave(Table_Content, str_names, "");
            SQLSentence = string.Format("insert into {0}({1}) values({2})", Table_Content, str_names, str_contents);
            DBManager.OpSQLWrite(SQLSentence);
        }

        //单个网页的内容，每个字段，字段名为ls_name，字段内容lls_content
        public struct SessionPage
        {
            public string id;
            public string url;
            public List<string> ls_name;
            public List<string> ls_lengh;
            public List<string> ls_md5;
            public List<List<string>> lls_content;
        }

        //XmlReader_Content xmlrc = null;
        List<XmlReader_Content> xmlrcs = new List<XmlReader_Content>();
        //获取漏洞网页内容
        //
        //
        //

        public void DoSomethingKill()
        {
            string str = "str：线程超时，已被强行关闭";
            //MessageBox.Show(str);
            StringHelper.MyMessagebox(str, 1);
        }

        //dataset 转 list
        public List<string> DatasetToListString(DataSet ds, int col)
        {
            List<string> ls = new List<string>();
            int total = ds.Tables[0].Rows.Count;
            for (int i = 0; i < total;i++ )
            {
                ls.Add(ds.Tables[0].Rows[i][col].ToString());
            }
            return ls;
        }

        //将获取到的漏洞列表保存到临时表
        public void WriteVulListToTempTable(List<List<string>> lls, string TempTable)
        {
            string str_names_length = "id int, vul_url nvarchar(MAX), vul_id nvarchar(50), datetime nvarchar(50), vul_url_integ nvarchar(MAX), Url_Relation nvarchar(MAX)";
            DBManager.OpSQLCreateTable_AfterSave(TempTable, str_names_length, "clear");
            //CreateTableAfterSave(TempTable, str_names_length);
            for (int i = 0; i < lls[0].Count; i++)
            {
                //从url中提取id
                string vul_id = "";
                if (xmlR.EndUrl_int == 0)
                {
                    vul_id = lls[0][i].Substring(xmlR.StartUrl_int, lls[0][i].Length - xmlR.StartUrl_int);
                }
                else
                {
                    vul_id = lls[0][i].Substring(xmlR.StartUrl_int, xmlR.EndUrl_int - xmlR.StartUrl_int);
                }

                //提取相关信息
                string Url_Relation = "";
                for (int j = 1; j < lls.Count; j++ )
                {
                    if (Url_Relation != "")
                        Url_Relation = Url_Relation + "[***]";
                    Url_Relation = Url_Relation + lls[j][i];
                }

                string vul_url_integ = xmlR.url3 + lls[0][i];
                SQLSentence = string.Format("insert into {0} (id,vul_url,vul_id,datetime,vul_url_integ,Url_Relation) values('{1}','{2}','{3}','{4}','{5}','{6}')", TempTable, i.ToString(), lls[0][i].ToString(), vul_id, StringHelper.MyNow(), vul_url_integ, Url_Relation);
                DBManager.OpSQLWrite(SQLSentence);
            }
        }

        public void GetVulList(string TableName_Temp)
        {
            //xmlR = new XmlReader(filename, dir);
            string url_temp = "";
            //List<string> ls_AllNewList = new List<string>();
            string str_names_length = "sn int, pagen int, vul_url nvarchar(MAX), vul_id nvarchar(50), datetime nvarchar(50), vul_url_integ nvarchar(MAX), Url_Relation nvarchar(MAX)";
            DBManager.OpSQLCreateTable_AfterSave(TableName_Temp, str_names_length, "clear");

            for (int page = xmlR.StartPage_int; page + xmlR.StartPage_buchong_int <= xmlR.PageNumber_int; page++)
            {
                List<List<string>> lls = new List<List<string>>();
                List<string> ls_NewList = new List<string>();
                int page2 = page * xmlR.EachPage_int;

                //url_temp = xmlR.url1 + xmlR.url2 + page2.ToString();
                url_temp = xmlR.url1.Replace("{***}", page2.ToString());
                url_temp = url_temp.Replace("amp;", "&");
                textBox_url.Text = url_temp;
                textBox_url.Refresh();
                textBox_num.Text = string.Format("当前站点第{0}个，当前站点共{1}个 【{0}|{1}】", (page + xmlR.StartPage_buchong_int).ToString(), xmlR.PageNumber_int.ToString());
                textBox_num.Refresh();

                Uri url = new Uri(url_temp);
                MyNaviget(url, "", "updatelist",0,0);
                if (textBox_delay.Text != "" && textBox_delay.Text != "0")
                {
                    int delay_second = System.Int32.Parse(textBox_delay.Text);
                    StringHelper.MySleep(delay_second);
                }
                string documentText = webBrowser1.GetDocumentStr();
                VolOverAll.documentText = documentText;
                StringHelper.MyMessagebox("success", 2);

                string flag_pause = IfWebContent(VolOverAll.documentText, false);
                if (flag_pause != "")
                {
                    //VolOverAll.PauseString_Naviget = true;
                    VolOverAll.pause_redownload_nextdownload = 1;
                    button_PauseNaviget.Text = "取消暂停";
                    button_redownload.Enabled = true;
                    button_downloadnext.Enabled = true;
                    StringHelper.MyMessagebox("由于页面存在设定的字符串，导致暂停：{" + flag_pause + "}", 1);

                    if (chk_PauseContiune2.Checked)
                    {
                        StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                        //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                        //重新下载本页             ：不保存暂停前下载的页面，重新下载
                        //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                        button_redownload.Enabled = false;
                        button_downloadnext.Enabled = false;
                        VolOverAll.pause_redownload_nextdownload = 3;
                        button_PauseNaviget.Text = "暂停下载";
                        //flag_ifcontinue = true;
                    }
                    //重新下载该页，不暂停
                    else if (chk_PauseContiune.Checked)
                    {
                        StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                        //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                        //重新下载本页             ：不保存暂停前下载的页面，重新下载
                        //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                        button_redownload.Enabled = false;
                        button_downloadnext.Enabled = false;
                        VolOverAll.pause_redownload_nextdownload = 2;
                        button_PauseNaviget.Text = "暂停下载";
                        //flag_ifcontinue = true;
                    }
                    IfErrorPage_txt.Text = page.ToString() + ":由于页面存在设定的字符串，导致暂停：{ " + flag_pause + " }";
                }

                //留1秒点暂停的时间
                //判断是否已经暂停
                StringHelper.MyPause();
                if (VolOverAll.pause_redownload_nextdownload == 2)
                {
                    page = page - 1;
                    VolOverAll.pause_redownload_nextdownload = 0;
                    continue;
                }
                else if (VolOverAll.pause_redownload_nextdownload == 3)
                {
                    VolOverAll.pause_redownload_nextdownload = 0;
                    continue;
                }
                
                //添加url列表的配套信息，例如edb中的platform
                List<string> ls = HtmlReader.ExtractSection(documentText, xmlR.ls_sessionpath[0]);
                lls.Add(ls);

                for (int i = 0; i < xmlR.ls_Url_Relation.Count; i++ )
                {
                    List<string> ls_temp = HtmlReader.ExtractSection(documentText, xmlR.ls_Url_Relation[i]);
                    lls.Add(ls_temp);
                }

                //for (int i = 0; i < ls.Count; i++)
                //{
                //    ls_AllNewList.Add(ls[i]);
                //}
                for (int i = 0; i < ls.Count; i++)
                {
                    //提取相关信息
                    string Url_Relation = "";

                    for (int j = 1; j < lls.Count; j++)
                    {
                        if (lls[0].Count == lls[j].Count)
                        {
                            if (Url_Relation != "")
                                Url_Relation = Url_Relation + "[***]";
                            Url_Relation = Url_Relation + lls[j][i];
                        }
                        else
                        {
                            StringHelper.MyMessagebox("信息不全", 1);
                            VolOverAll.pause_redownload_nextdownload = 1;

                            button_PauseNaviget.Text = "取消暂停";
                            button_redownload.Enabled = true;
                            button_downloadnext.Enabled = true;
                        }
                    }

                    //page + 1 - xmlR.StartPage_int，当StartPage = 0时，page = page + 1
                    WriteVulList_forDownload(ls[i], Url_Relation, TableName_Temp, i, (page + xmlR.StartPage_buchong_int));
                }
            }

            //return lls;
            //return page2;
        }//这里应当是6，7有问题，重新测试

        public List<SessionPage> GetVulContent(string filename, string dir, string TableName_Temp)
        {
            SQLSentence = string.Format("select vul_id, vul_url_integ from {0} order by pagen, sn", TableName_Temp);
            DataSet ds_vul = DBManager.OpSQLGetTable(SQLSentence);
            List<string> ls_vul_id = DatasetToListString(ds_vul, 0);
            List<string> ls_vul_url_integ = DatasetToListString(ds_vul, 1);
            string vul_url_integ = "";

            List<SessionPage> ls_sp = new List<SessionPage>();
            for (int page = 0; page < ls_vul_id.Count; page++)
            {
                //检测窗口是否关闭
                if (VolOverAll.closewindow == true)
                {
                    break;
                }

                SessionPage sp = new SessionPage();
                sp.id = ls_vul_id[page];
                sp.url = ls_vul_url_integ[page];
                sp.ls_name = new List<string>();
                sp.lls_content = new List<List<string>>();
                sp.ls_lengh = new List<string>();
                sp.ls_md5 = new List<string>();

                textBox_url.Text = ls_vul_url_integ[page];
                textBox_url.Refresh();
                textBox_num.Text = string.Format("当前站点第{0}个，当前站点共{1}个，第{2}轮；已经完成{3}个", (page + 1).ToString(), ls_vul_id.Count.ToString(), VolOverAll.over_maxCishu, YiJingWanChengUrl);
                YiJingWanChengUrl = YiJingWanChengUrl + 1;
                textBox_num.Refresh();

                bool flag_break = false;
                for (int subpage = 0; subpage < xmlR.ls_subpage.Count; subpage++)
                {
                    textBox_zongziduan.Text = xmlrcs[subpage].ls_sessionpath.Count.ToString();
                    textBox_zongziduan.Refresh();
                    textBox_tongziduan.Text = xmlR.ls_tongziduan[0];
                    textBox_tongziduan.Refresh();
                    //#################
                    vul_url_integ = ls_vul_url_integ[page] + xmlR.ls_subpage[subpage].ToString(); //#############
                    Uri url = new Uri(vul_url_integ);
                    OutTimeLabel.Text = string.Format("{0}准备打开", ls_vul_id[page]);
                    MyNaviget(url, ls_vul_id[page], "content",subpage,0);
                    if (textBox_delay.Text != "" && textBox_delay.Text != "0")
                    {
                        int delay_second = System.Int32.Parse(textBox_delay.Text);
                        StringHelper.MySleep(delay_second);
                    }
                    string documentText = webBrowser1.GetDocumentStr();
                    VolOverAll.documentText = documentText;

                    //******************************************************************************
                    //暂停
                    string flag_pause = IfWebContent(VolOverAll.documentText, true);
                    //bool flag_ifcontinue = false;
                    if (flag_pause != "")
                    {
                        //flag_ifcontinue = true;
                        //VolOverAll.PauseString_Naviget = true;
                        VolOverAll.pause_redownload_nextdownload = 1;
                        button_PauseNaviget.Text = "取消暂停";
                        button_redownload.Enabled = true;
                        button_downloadnext.Enabled = true;
                        StringHelper.MyMessagebox("由于页面存在设定的字符串，导致暂停：{" + flag_pause + "}", 1);

                        //如果页面为空，不重新下载被选中，则pause为3，跳过该也继续下载
                        if (chk_PauseContiune2.Checked)
                        {
                            StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                            //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                            //重新下载本页             ：不保存暂停前下载的页面，重新下载
                            //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                            button_redownload.Enabled = false;
                            button_downloadnext.Enabled = false;
                            VolOverAll.pause_redownload_nextdownload = 3;
                            button_PauseNaviget.Text = "暂停下载";
                            //flag_ifcontinue = true;
                        }
                        //重新下载该页，不暂停
                        else if (chk_PauseContiune.Checked)
                        {
                            StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                            //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                            //重新下载本页             ：不保存暂停前下载的页面，重新下载
                            //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                            button_redownload.Enabled = false;
                            button_downloadnext.Enabled = false;
                            VolOverAll.pause_redownload_nextdownload = 2;
                            button_PauseNaviget.Text = "暂停下载";
                            //flag_ifcontinue = true;
                        }
                        IfErrorPage_txt.Text = page.ToString() + ":由于页面存在设定的字符串，导致暂停：{ " + flag_pause + " }";
                    }

                    //留1秒点暂停的时间
                    //判断是否已经暂停
                    //参数等于2，重新下载本页，参数等于3，跳过该页，继续下载
                    StringHelper.MyPause();
                    //if (flag_ifcontinue == false)
                    if (VolOverAll.pause_redownload_nextdownload == 0)
                    {
                        string subpage_temp = "";
                        if (xmlR.ls_subpage[subpage] != "")
                        {
                            subpage_temp = xmlR.ls_subpage[subpage].Replace("/", "") + "_";
                        }
                        for (int subpage_i = 0; subpage_i < xmlrcs[subpage].ls_sessionname.Count; subpage_i++)
                        {
                            if (subpage == 0)
                            {
                                sp.ls_name.Add(xmlrcs[subpage].ls_sessionname[subpage_i].ToString());
                            }
                            else
                            {
                                sp.ls_name.Add(subpage_temp + xmlrcs[subpage].ls_sessionname[subpage_i].ToString());
                            }                           
                            sp.ls_lengh.Add(xmlrcs[subpage].ls_sessionlengh[subpage_i].ToString());
                            sp.ls_md5.Add(xmlrcs[subpage].ls_sessionmd5[subpage_i].ToString());
                        }

                        //第1个path为updatenew
                        List<string> ls_updatenew = new List<string>();
                        ls_updatenew.Add("");
                        sp.lls_content.Add(ls_updatenew);
                        //第2个path为datetime
                        List<string> ls_datetime = new List<string>();
                        ls_datetime.Add(StringHelper.MyNow());
                        sp.lls_content.Add(ls_datetime);
                        //****************//
                        //****************//
                        //****************//

                        VolOverAll.documentText = VolOverAll.documentText.Replace("<br>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<br />", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<br/>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</ br>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</br>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<BR>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<BR />", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<BR/>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</ BR>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</BR>", VolOverAll.replace_br);

                        for (int i = 2; i < xmlrcs[subpage].ls_sessionpath.Count; i++)
                        {
                            OutTimeLabel.Text = string.Format("{0} 正在解析", ls_vul_id[page]);
                            OutTimeLabel.Refresh();
                            //*************************************************************解析存在问题
                            //List<string> ls_path_temp = HtmlReader.ExtractSection(documentText, xmlrc.ls_sessionpath[i]);
                            //时间限定
                            int timeout_count =
                                //CThreadHelper.ThreadExe_string(HtmlReader.ExtractSection_thread, HtmlReader.ExtractSection_kill, documentText, xmlrc.ls_sessionpath[i], 3);
                                CThreadHelper.ThreadExe_string(HtmlReader.ExtractSection_thread, HtmlReader.ExtractSection_kill, VolOverAll.documentText, xmlrcs[subpage].ls_sessionpath[i], 3);
                            List<string> ls_path_temp = VolOverAll.ls_path_temp;

                            OutTimeLabel.Text = string.Format("{0} 解析完毕, 用时：{1} 秒 {2} 毫秒", ls_vul_id[page], timeout_count / 1000, timeout_count % 1000);
                            OutTimeLabel.Refresh();
                            if (ls_path_temp.Count == 0)
                            {
                                sp.lls_content.Add(new List<string>());
                            }
                            else
                            {
                                (sp.lls_content).Add(ls_path_temp);
                            }
                        }
                    }

                    if (VolOverAll.pause_redownload_nextdownload == 2)
                    {
                        page = page - 1;
                        VolOverAll.pause_redownload_nextdownload = 0;
                        flag_break = true;
                        break;
                    }
                    else if (VolOverAll.pause_redownload_nextdownload == 3)
                    {
                        VolOverAll.pause_redownload_nextdownload = 0;
                        flag_break = true;
                        break;
                    }
                }

                if (flag_break == true)
                {
                    flag_break = false;
                    continue;
                }
                //******************************************************************************
                ls_sp.Add(sp);
            }
            return ls_sp;
        }

        public void GetVulContent_WithSave(string filename, string dir, string TableName_Temp)
        {
            //TableName_Temp = xmlR.Table_List_ListDownload;

            SQLSentence = string.Format("select vul_id, vul_url_integ from {0} order by pagen desc, sn desc", TableName_Temp);
            DataSet ds_vul = DBManager.OpSQLGetTable(SQLSentence);
            List<string> ls_vul_id = DatasetToListString(ds_vul, 0);
            List<string> ls_vul_url_integ = DatasetToListString(ds_vul, 1);
            string vul_url_integ = "";

            //xmlrc = new XmlReader_Content(filename, dir);
            List<SessionPage> ls_sp = new List<SessionPage>();
            for (int page = xmlR.DownloadContentWithList_int - 1; page < ls_vul_id.Count; page++)
            {
                //检测窗口是否关闭
                if (VolOverAll.closewindow == true)
                {
                    break;
                }

                SessionPage sp = new SessionPage();
                sp.id = ls_vul_id[page];
                sp.url = ls_vul_url_integ[page];
                sp.ls_name = new List<string>();
                sp.lls_content = new List<List<string>>();
                sp.ls_lengh = new List<string>();
                sp.ls_md5 = new List<string>();

                textBox_url.Text = ls_vul_url_integ[page];
                textBox_url.Refresh();
                textBox_num.Text = string.Format("当前站点第{0}个，当前站点共{1}个；已经完成200个，所有站点共1000个 【{0}|{1}; 100|1000】第{2}轮", (page + 1).ToString(), ls_vul_id.Count.ToString(), VolOverAll.over_maxCishu);
                textBox_num.Refresh();

                bool flag_break = false;
                for (int subpage = 0; subpage < xmlR.ls_subpage.Count; subpage++)
                {
                    textBox_zongziduan.Text = xmlrcs[subpage].ls_sessionpath.Count.ToString();
                    textBox_zongziduan.Refresh();
                    textBox_tongziduan.Text = xmlR.ls_tongziduan[0];
                    textBox_tongziduan.Refresh();
                    //#################
                    vul_url_integ = ls_vul_url_integ[page] + xmlR.ls_subpage[subpage].ToString(); //#############
                    Uri url = new Uri(vul_url_integ);
                    OutTimeLabel.Text = string.Format("{0}准备打开", ls_vul_id[page]);
                    MyNaviget(url, ls_vul_id[page], "content",subpage,0);
                    if (textBox_delay.Text != "" && textBox_delay.Text != "0")
                    {
                        int delay_second = System.Int32.Parse(textBox_delay.Text);
                        StringHelper.MySleep(delay_second);
                    }
                    string documentText = webBrowser1.GetDocumentStr();
                    VolOverAll.documentText = documentText;

                    //******************************************************************************
                    //暂停
                    string flag_pause = IfWebContent(VolOverAll.documentText, true);
                    if (flag_pause != "")
                    {
                        //flag_ifcontinue = true;
                        //VolOverAll.PauseString_Naviget = true;
                        VolOverAll.pause_redownload_nextdownload = 1;
                        button_PauseNaviget.Text = "取消暂停";
                        button_redownload.Enabled = true;
                        button_downloadnext.Enabled = true;
                        StringHelper.MyMessagebox("由于页面存在设定的字符串，导致暂停：{" + flag_pause + "}", 1);

                        //如果页面为空，不重新下载被选中，则pause为3，跳过该也继续下载
                        if (chk_PauseContiune2.Checked)
                        {
                            StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                            //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                            //重新下载本页             ：不保存暂停前下载的页面，重新下载
                            //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                            button_redownload.Enabled = false;
                            button_downloadnext.Enabled = false;
                            VolOverAll.pause_redownload_nextdownload = 3;
                            button_PauseNaviget.Text = "暂停下载";
                            //flag_ifcontinue = true;
                        }
                        //重新下载该页，不暂停
                        else if (chk_PauseContiune.Checked)
                        {
                            StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                            //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                            //重新下载本页             ：不保存暂停前下载的页面，重新下载
                            //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                            button_redownload.Enabled = false;
                            button_downloadnext.Enabled = false;
                            VolOverAll.pause_redownload_nextdownload = 2;
                            button_PauseNaviget.Text = "暂停下载";
                            //flag_ifcontinue = true;
                        }
                        IfErrorPage_txt.Text = page.ToString() + ":由于页面存在设定的字符串，导致暂停：{ " + flag_pause + " }";
                    }

                    //留1秒点暂停的时间
                    //判断是否已经暂停
                    //参数等于2，重新下载本页，参数等于3，跳过该页，继续下载
                    StringHelper.MyPause();
                    if (VolOverAll.pause_redownload_nextdownload == 0)
                    {
                        string subpage_temp = "";
                        if (xmlR.ls_subpage[subpage] != "")
                        {
                            subpage_temp = xmlR.ls_subpage[subpage].Replace("/", "") + "_";
                        }
                        for (int subpage_i = 0; subpage_i < xmlrcs[subpage].ls_sessionname.Count; subpage_i++)
                        {
                            if (subpage == 0)
                            {
                                sp.ls_name.Add(xmlrcs[subpage].ls_sessionname[subpage_i].ToString());
                            }
                            else
                            {
                                sp.ls_name.Add(subpage_temp + xmlrcs[subpage].ls_sessionname[subpage_i].ToString());
                            }    
                            sp.ls_lengh.Add(xmlrcs[subpage].ls_sessionlengh[subpage_i].ToString());
                            sp.ls_md5.Add(xmlrcs[subpage].ls_sessionmd5[subpage_i].ToString());
                        }

                        //第1个path为updatenew
                        List<string> ls_updatenew = new List<string>();
                        ls_updatenew.Add("");
                        sp.lls_content.Add(ls_updatenew);
                        //第2个path为datetime
                        List<string> ls_datetime = new List<string>();
                        ls_datetime.Add(StringHelper.MyNow());
                        sp.lls_content.Add(ls_datetime);
                        //****************//
                        //****************//
                        //****************//

                        VolOverAll.documentText = VolOverAll.documentText.Replace("<br>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<br />", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<br/>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</ br>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</br>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<BR>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<BR />", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("<BR/>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</ BR>", VolOverAll.replace_br);
                        VolOverAll.documentText = VolOverAll.documentText.Replace("</BR>", VolOverAll.replace_br);

                        for (int i = 2; i < xmlrcs[subpage].ls_sessionpath.Count; i++)
                        {
                            OutTimeLabel.Text = string.Format("{0} 正在解析", ls_vul_id[page]);
                            OutTimeLabel.Refresh();
                            //*************************************************************解析存在问题
                            //List<string> ls_path_temp = HtmlReader.ExtractSection(documentText, xmlrc.ls_sessionpath[i]);
                            //时间限定
                            int timeout_count =
                                CThreadHelper.ThreadExe_string(HtmlReader.ExtractSection_thread, HtmlReader.ExtractSection_kill, VolOverAll.documentText, xmlrcs[subpage].ls_sessionpath[i], 3);
                            List<string> ls_path_temp = VolOverAll.ls_path_temp;

                            OutTimeLabel.Text = string.Format("{0} 解析完毕, 用时：{1} 秒 {2} 毫秒", ls_vul_id[page], timeout_count / 1000, timeout_count % 1000);
                            OutTimeLabel.Refresh();
                            if (ls_path_temp.Count == 0)
                            {
                                sp.lls_content.Add(new List<string>());
                            }
                            else
                            {
                                (sp.lls_content).Add(ls_path_temp);
                            }
                        }
                    }

                    if (VolOverAll.pause_redownload_nextdownload == 2)
                    {
                        page = page - 1;
                        VolOverAll.pause_redownload_nextdownload = 0;
                        flag_break = true;
                        break;
                    }
                    else if (VolOverAll.pause_redownload_nextdownload == 3)
                    {
                        VolOverAll.pause_redownload_nextdownload = 0;
                        flag_break = true;
                        break;
                    }
                }

                if (flag_break == true)
                {
                    flag_break = false;
                    continue;
                }
                ls_sp.Clear();
                ls_sp.Add(sp);
                WriteVulContent(ls_sp, xmlR.Table_Content_ListDownload);
            }
        }

        public void GetAndWriteVulList_forDownload(string TableName_Temp, int StartPage, int PageNumber)
        {
            string url_temp = "";
            string str_names_length = "sn int, pagen int, vul_url nvarchar(MAX), vul_id nvarchar(50), datetime nvarchar(50), vul_url_integ nvarchar(MAX), Url_Relation nvarchar(MAX)";
            //CreateTableAfterSave(TableName_Temp, str_names_length);
            DBManager.OpSQLCreateTable_AfterSave(TableName_Temp, str_names_length, "");

            for (int page = StartPage; page < PageNumber; page++)
            {
                List<List<string>> lls = new List<List<string>>();
                //List<string> ls_NewList = new List<string>();
                int page2 = page * xmlR.EachPage_int;

                //url_temp = xmlR.url1 + xmlR.url2 + page2.ToString();
                url_temp = xmlR.url1.Replace("{***}", page2.ToString());
                url_temp = url_temp.Replace("amp;", "&");
                textBox_url.Text = url_temp;
                textBox_url.Refresh();
                //page + 1 - xmlR.StartPage_int，当StartPage = 0时，page = page + 1
                textBox_num.Text = string.Format("当前站点第{0}个，当前站点共{1}个", (page + xmlR.StartPage_buchong_int).ToString(), PageNumber.ToString());
                textBox_num.Refresh();

                Uri url = new Uri(url_temp);
                MyNaviget(url, "", "updatelist", 0, page);
                if (textBox_delay.Text != "" && textBox_delay.Text != "0")
                {
                    int delay_second = System.Int32.Parse(textBox_delay.Text);
                    StringHelper.MySleep(delay_second);
                }
                string documentText = webBrowser1.GetDocumentStr();
                VolOverAll.documentText = documentText;
                //MessageBox.Show("success");
                StringHelper.MyMessagebox("success", 2);

                string flag_pause = IfWebContent(VolOverAll.documentText, false);
                if (flag_pause != "")
                {
                    //VolOverAll.PauseString_Naviget = true;
                    VolOverAll.pause_redownload_nextdownload = 1;
                    button_PauseNaviget.Text = "取消暂停";
                    button_redownload.Enabled = true;
                    button_downloadnext.Enabled = true;
                    StringHelper.MyMessagebox("由于页面存在设定的字符串，导致暂停：{" + flag_pause + "}", 1);

                    //如果页面为空，不重新下载被选中，则pause为3，跳过该也继续下载
                    if (chk_PauseContiune2.Checked)
                    {
                        StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                        //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                        //重新下载本页             ：不保存暂停前下载的页面，重新下载
                        //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                        button_redownload.Enabled = false;
                        button_downloadnext.Enabled = false;
                        VolOverAll.pause_redownload_nextdownload = 3;
                        button_PauseNaviget.Text = "暂停下载";
                        //flag_ifcontinue = true;
                    }
                    //重新下载该页，不暂停
                    else if (chk_PauseContiune.Checked)
                    {
                        StringHelper.MyPause(System.Int32.Parse(textBox_PauseSecond.Text));
                        //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                        //重新下载本页             ：不保存暂停前下载的页面，重新下载
                        //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                        button_redownload.Enabled = false;
                        button_downloadnext.Enabled = false;
                        VolOverAll.pause_redownload_nextdownload = 2;
                        button_PauseNaviget.Text = "暂停下载";
                        //flag_ifcontinue = true;
                    }
                    IfErrorPage_txt.Text = page.ToString() + ":由于页面存在设定的字符串，导致暂停：{ " + flag_pause + " }";
                }

                //留1秒点暂停的时间
                //判断是否已经暂停
                StringHelper.MyPause();//暂停后将进入此函数做死循环，直到取消暂停
                //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
                //重新下载本页             ：不保存暂停前下载的页面，重新下载
                //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
                if (VolOverAll.pause_redownload_nextdownload == 2)
                {
                    page = page - 1;
                    VolOverAll.pause_redownload_nextdownload = 0;
                    continue;
                }
                else if (VolOverAll.pause_redownload_nextdownload == 3)
                {
                    VolOverAll.pause_redownload_nextdownload = 0;
                    continue;
                }

                //添加url列表的配套信息，例如edb中的platform
                List<string> ls = HtmlReader.ExtractSection(documentText, xmlR.ls_sessionpath[0]);
                lls.Add(ls);

                for (int i = 0; i < xmlR.ls_Url_Relation.Count; i++)
                {
                    List<string> ls_temp = HtmlReader.ExtractSection(documentText, xmlR.ls_Url_Relation[i]);
                    lls.Add(ls_temp);
                }

                for (int i = 0; i < ls.Count; i++)
                {
                    //提取相关信息
                    string Url_Relation = "";

                    for (int j = 1; j < lls.Count; j++)
                    {
                        if (lls[0].Count == lls[j].Count)
                        {
                            if (Url_Relation != "")
                                Url_Relation = Url_Relation + "[***]";
                            Url_Relation = Url_Relation + lls[j][i];
                        }
                        else
                        {
                            StringHelper.MyMessagebox("信息不全", 1);
                            VolOverAll.pause_redownload_nextdownload = 1;

                            button_PauseNaviget.Text = "取消暂停";
                            button_redownload.Enabled = true;
                            button_downloadnext.Enabled = true;
                        }
                    }

                    //page + 1 - xmlR.StartPage_int，当StartPage = 0时，page = page + 1
                    WriteVulList_forDownload(ls[i], Url_Relation, TableName_Temp, i, (page + xmlR.StartPage_buchong_int));
                }
            }

        }

        public void WriteVulList_forDownload(string str, string Url_Relation, string TempTable, int sn, int pagen)
        {
            string vul_id = "";
            if (xmlR.EndUrl_int == 0)
            {
                vul_id = str.Substring(xmlR.StartUrl_int, str.Length - xmlR.StartUrl_int);
            }
            else
            {
                //vul_id = str.Substring(xmlR.StartUrl_int, xmlR.EndUrl_int - xmlR.StartUrl_int);
                vul_id = GetIDFromUrl(str, xmlR.StartUrl_int);
            }
            string vul_url_integ = xmlR.url3 + str;
            SQLSentence = string.Format("insert into {0} (sn, pagen, vul_url,vul_id,datetime,vul_url_integ,Url_Relation) values('{1}','{2}','{3}','{4}','{5}','{6}','{7}')", TempTable, (sn + 1).ToString(), pagen.ToString(), str, vul_id, StringHelper.MyNow(), vul_url_integ, Url_Relation);
            DBManager.OpSQLWrite(SQLSentence);

            SQLSentence = string.Format("select count(distinct pagen) from {0}", xmlR.Table_List_ListDownload);
            int a = DBManager.OpSQLGetInt(SQLSentence);
            SQLSentence = string.Format("select max(pagen) from {0}", xmlR.Table_List_ListDownload);
            int b = DBManager.OpSQLGetInt(SQLSentence);
            if (a != b)
            {
                MessageBox.Show("a != b");
            }
        }

        public string IfWebContent(string document, bool flag_content)
        {
            if (document == "")
            {
                return "内容为空";
            }
            else if (document == null)
            {
                return "document is null";
            }
            else
            {
                //List<string> ls_pause_ifExist = xmlR.ls_pause;
                //List<string> ls_pause_ifNotExist = xmlR.ls_pause_ifNotExist;
                string flag = "";
                for (int i = 0; i < xmlR.ls_pause.Count(); i++)
                {
                    if (document.Contains(xmlR.ls_pause[i]))
                    {
                        flag = xmlR.ls_pause[i];
                        return flag;
                    }
                }

                if (flag_content)
                {
                    for (int i = 0; i < xmlR.ls_pause_ifNotExist_Content.Count(); i++)
                    {
                        if (!document.Contains(xmlR.ls_pause_ifNotExist[i]))
                        {
                            flag = "不存在：" + xmlR.ls_pause_ifNotExist[i];
                            return flag;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < xmlR.ls_pause_ifNotExist.Count(); i++)
                    {
                        if (!document.Contains(xmlR.ls_pause_ifNotExist[i]))
                        {
                            flag = "不存在：" + xmlR.ls_pause_ifNotExist[i];
                            return flag;
                        }
                    }
                }
                return flag;
            }
        }

        public void FieldReverse(string TableName, string field)
        //public void FieldReverse(string TableName,string field, bool IfBackup = false)
        {
            //DBManager.OpSQLSaveTable(TableName);
            SQLSentence = string.Format("select * from {0} order by {1}", TableName, field);
            DataSet ds = DBManager.OpSQLGetTable(SQLSentence);
            //DataSet ds_re = ds;
            DataSet ds_re = DBManager.OpSQLGetTable(SQLSentence);
            int total = ds.Tables[0].Rows.Count;
            for (int i = 0; i < total && total > 0; i++)
            {
                //ds_re.Tables[0].Rows[i]["datetime"] = ds.Tables[total - i - 1].Rows[i]["datetime"];
                ds_re.Tables[0].Rows[i][field] = ds.Tables[0].Rows[total - 1 - i][field];
            }
            //DBManager.OpSQLClearTable_must(TableName);
            int test = ds_re.Tables[0].Rows.Count;
            DBManager.OpSQLUpdate(TableName, ds_re, true);
        }

        private void button_tool_Click(object sender, EventArgs e)
        {
            //弹出
            MessageBox.Show(this.webBrowser1.Version.ToString());
            minitool ghs = new minitool();
            ghs.Show();

        }

        private void button_go_Click(object sender, EventArgs e)
        {
            url_txt.Refresh();
            Uri url = new Uri(url_txt.Text);
            MyNaviget(url,"","",0,0);
            string documentText = webBrowser1.GetDocumentStr();
            VolOverAll.documentText = documentText;
        }

        private void button_PauseNaviget_Click(object sender, EventArgs e)
        {
            if (button_PauseNaviget.Text == "暂停下载")
            {
                //VolOverAll.DownloadString_Re = false;
                //VolOverAll.DownloadString_next = false;
                //VolOverAll.PauseString_Naviget = true;
                VolOverAll.pause_redownload_nextdownload = 1;

                button_PauseNaviget.Text = "取消暂停";
                button_redownload.Enabled = true;
                button_downloadnext.Enabled = true;
            }
            else
            {
                //VolOverAll.DownloadString_Re = false;
                //VolOverAll.DownloadString_next = false;
                //VolOverAll.PauseString_Naviget = false;
                VolOverAll.pause_redownload_nextdownload = 0;

                button_PauseNaviget.Text = "暂停下载";
                button_redownload.Enabled = false;
                button_downloadnext.Enabled = false;
            }
        }

        //重新下载
        private void button_redownload_Click(object sender, EventArgs e)
        {
            //取消暂停                 ：保存暂停前下载的页面，然后继续下载下一页 
            //重新下载本页             ：不保存暂停前下载的页面，重新下载
            //下载下一页，不保存本页   ：不保存暂停前下载的页面，继续下载下一页
            button_redownload.Enabled = false;
            button_downloadnext.Enabled = false;
            //VolOverAll.DownloadString_Re = true;
            //VolOverAll.DownloadString_next = false;
            //VolOverAll.PauseString_Naviget = false;
            VolOverAll.pause_redownload_nextdownload = 2;
            button_PauseNaviget.Text = "暂停下载";
        }

        //下载下一页 不保存本页
        private void button_downloadnext_Click(object sender, EventArgs e)
        {
            button_redownload.Enabled = false;
            button_downloadnext.Enabled = false;
            //VolOverAll.DownloadString_Re = false;
            //VolOverAll.DownloadString_next = true;
            //VolOverAll.PauseString_Naviget = false;
            VolOverAll.pause_redownload_nextdownload = 3;
            button_PauseNaviget.Text = "暂停下载";
        }

        private void checkBox_display_prompt_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_display_prompt.Checked == true)
                VolOverAll.Display_Messagebox = "checked";
            else
                VolOverAll.Display_Messagebox = "";
            //MessageBox.Show(VolOverAll.Display_Messagebox);
        }

        private void checkBox_display_prompt2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_display_prompt2.Checked == true)
                VolOverAll.Display_Messagebox2 = "checked";
            else
                VolOverAll.Display_Messagebox2 = "";
        }

        private void checkBox_display_prompt3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_display_prompt3.Checked == true)
                VolOverAll.Display_Messagebox3 = "checked";
            else
                VolOverAll.Display_Messagebox3 = "";
        }

        private void checkBox_display_prompt4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_display_prompt4.Checked == true)
                VolOverAll.Display_Messagebox4 = "checked";
            else
                VolOverAll.Display_Messagebox4 = "";
        }

        private void delete_tbl_btn_Click(object sender, EventArgs e)
        {
            //string delete_tablename = "XXXSecurityFocus_XXX";
            string delete_tablename = textBox_deletetable.Text;// "PacketStorm_Advisory_Content_ListDownload";
            //string name_db = "NIPC20150120";
            string name_db = VolOverAll.DataBaseName;
            if (delete_tablename != "")
            {
                SQLSentence = string.Format("SELECT Name FROM [{0}]..SysObjects Where XType='U' ORDER BY Name", name_db);
                DataSet ds = DBManager.OpSQLGetTable(SQLSentence);
                List<string> ls = StringHelper.DsToList(ds);
                int count = 0;
                for (int i = 0; i < ls.Count; i++)
                {
                    if (ls[i].Contains(delete_tablename))
                    {
                        SQLSentence = string.Format("drop table [{0}]", ls[i]);
                        count = count + 1;
                        //StringHelper.MyMessagebox(count.ToString() + ": " + ls[i], 1);
                        if (MessageBox.Show(count.ToString() + ": " + ls[i], "", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            DBManager.OpSQLWrite(SQLSentence);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("delete table 不能为空");
            }
        }

        private void sf_poc_btn_Click(object sender, EventArgs e)
        {
            for (int i = 50031; i < 51000; )
            {
                Application.DoEvents(); 

                if(VolOverAll.pause_redownload_nextdownload == 0)
                {
                    string url_temp = string.Format("http://www.securityfocus.com/bid/{0}/exploit", i.ToString());
                    textBox_url.Text = url_temp;
                    textBox_url.Refresh();
                    Uri url = new Uri(url_temp);
                    MyNaviget(url, "", "",0,0);
                    //Thread.Sleep(3000);
                    MessageBox.Show(i.ToString());

                    i++;
                }
                else
                {
                    Thread.Sleep(1000);
                }
            }
        }

        private void download_Click(object sender, EventArgs e)
        {
            if (TableName1.Text != "")
            {
                string path = VolOverAll.datacode + TableName1.Text + ".xml";
                //if (File.Exists("d://datacode//nsfocus.xml"))
                if (File.Exists(path))
                {
                    //string XmlName1 = TableName1.Text + ".xml";
                    //xmlR = new XmlReader(XmlName1, VolOverAll.datacode);
                    //getInterface(xmlR);

                    textBox_zongziduan.Text = xmlR.ls_IfComplete.Count.ToString();
                    string TableName_Temp = xmlR.Table_List_ListDownload;

                    GetAndWriteVulList_forDownload(TableName_Temp, xmlR.StartPage_int, xmlR.Table_MaxPage_int + 1);
                    //GetAndWriteVulList_forDownload(TableName_Temp, 1322, xmlR.Table_MaxPage_int + 1);
                }
                else
                {
                    MessageBox.Show("该文件不存在");
                }
            }
            else
            {
                MessageBox.Show("xml文件名不能为空");
            }         
        }

        public string GetIDFromUrl(string url, int start)
        {
            string vul_id = "";
            for (int i = start; i < url.Length;i++ )
            {
                string temp = url[i].ToString();
                if (temp != "/")
                {
                    vul_id = vul_id + temp;
                }
                else
                    break;
            }
            return vul_id;
        }

        private void DownloadWithList_btn_Click(object sender, EventArgs e)
        {
            //string XmlName1 = "CXSecurity1.xml";
            //string XmlName2 = "CXSecurity2.xml";
            //string XmlName1 = "PacketStorm_Advisory1.xml";
            //string XmlName2 = "PacketStorm_Advisory2.xml";

            if (TableName1.Text == "")
            {
                MessageBox.Show("xml文件名不能为空");
            }
            else
            {
                string XmlName1 = TableName1.Text + ".xml";
                string XmlName2 = TableName2.Text + ".xml";
                //xmlR = new XmlReader(XmlName1, VolOverAll.datacode);
                //getInterface(xmlR);
                //xmlrc = new XmlReader_Content(XmlName2, VolOverAll.datacode);
                textBox_zongziduan.Text = xmlrcs[0].ls_sessionpath.Count.ToString();

//                DBManager.OpSQLSaveTable(xmlR.Table_Content_ListDownload);
                GetVulContent_WithSave(XmlName2, VolOverAll.datacode, xmlR.Table_List_ListDownload);
            }
        }

        private void closewindow_btn_Click(object sender, EventArgs e)
        {
            VolOverAll.closewindow = true;
            VolOverAll.pause_redownload_nextdownload = 3;
            this.Close();
        }

        private void getName_Click(object sender, EventArgs e)
        {
            GetNameDlg gnd = new GetNameDlg();
            gnd.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TableName1.Text = VolOverAll.ls_filename_chk[0].Substring(0, VolOverAll.ls_filename_chk[0].Length - 4);
            //TableName2.Text = VolOverAll.ls_filename_chk[1].Substring(0, VolOverAll.ls_filename_chk[1].Length - 4);
            TableName1.Refresh();
            //TableName2.Refresh();

            xmlR = new XmlReader(TableName1.Text + ".xml", VolOverAll.datacode);
            getInterface(xmlR);
            for (int subpage = 0; subpage < xmlR.ls_subpage.Count; subpage++)
            {
                string str_temp = xmlR.ls_subpage[subpage].Replace("/", "");
                if (xmlR.ls_subpage[subpage] == "")
                {
                    str_temp = "Content";
                }

                string str_temp2 = TableName1.Text + "_" + str_temp + ".xml";
                xmlrcs.Add(new XmlReader_Content(str_temp2, VolOverAll.datacode));
            }
            //xmlrc = new XmlReader_Content(TableName2.Text + ".xml", VolOverAll.datacode);
        }

        private void DownFile_btn_Click(object sender, EventArgs e)
        {
            ////下载文件
            ////string URLAddress = @"http://www.exploit-db.com/download/36053";
            ////string URLAddress = @"http://www.wulateqq1988.com";
            //string URLAddress = @"https://exchange.xforce.ibmcloud.com/vulnerabilities/82656";
            //bool re = StringHelper.DownloadFile(URLAddress, VolOverAll.receivePath);
            //if (re == true)
            //    MessageBox.Show("下载完成");

            //SQLSentence = "insert into temp2 (id,name) values('1','1')";
            //for (int i = 0; i < 10000; i++)
            //{
            //    DBManager.OpSQLWrite(SQLSentence);
            //    textBox_url.Text = i.ToString();
            //    textBox_url.Refresh();
            //}                

            //FieldReverse("edb_remote_Content_temp", "datetime");

            //select id,'old' as updatenew into cxs_UpdateToRemote from cxs_Content_final order by datetime desc
            //update cxs_UpdateToRemote set updatenew = 'new' where id in (select id from cxs_Content_tempUpdateVul)
            //insert into cxs_UpdateToRemote (id,updatenew) select id,'new' from cxs_Content_tempNewVul
        }

        public void crewler_to_remote()
        {
            if (!DBManager.OpSQLIfExist(xmlR.Table_UpdateToRemote))
            {
                SQLSentence = string.Format("select id,'old' as updatenew into {0} from {1} order by datetime desc", xmlR.Table_UpdateToRemote, xmlR.Table_Content_Final);
                DBManager.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("update {0} set updatenew = 'new' where id in (select id from {1})", xmlR.Table_UpdateToRemote, xmlR.Table_Content_tempUpdateVul);
                DBManager.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("update {0} set updatenew = 'new' where id in (select id from {1})", xmlR.Table_UpdateToRemote, xmlR.Table_Content_tempNewVul);
                DBManager.OpSQLWrite(SQLSentence);
            }
            else
            {
                SQLSentence = string.Format("update {0} set updatenew = 'new' where id in (select id from {1})", xmlR.Table_UpdateToRemote, xmlR.Table_Content_tempUpdateVul);
                DBManager.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("insert into {0} (id,updatenew) select id,'new' from {1}", xmlR.Table_UpdateToRemote, xmlR.Table_Content_tempNewVul);
                DBManager.OpSQLWrite(SQLSentence);
            }
        }

        private void edb_poc_btn_Click(object sender, EventArgs e)
        {
            string dir = @"D:\exploit-database-master\exploit-database-master\platforms";
            List<string> ls1 = StringHelper.getSubDirs(dir);
            List<string> ls2 = new List<string>();
            ls2.Add("dos");
            ls2.Add("local");
            ls2.Add("remote");
            ls2.Add("shellcode");
            ls2.Add("webapps");

            List<string> ls3 = new List<string>();
            List<string> ls3_id = new List<string>();
            for (int i = 0; i < ls1.Count; i++ )
            {
                for (int j = 0; j < ls2.Count; j++ )
                {
                    string str_temp1 = ls1[i] + @"\" + ls2[j];
                    if (Directory.Exists(str_temp1))
                    {
                        List<string> ls4 = StringHelper.getDirFile(str_temp1);
                        for (int k = 0; k < ls4.Count; k++)
                        {
                            string str_temp2 = str_temp1 + @"\" + ls4[k];
                            ls3.Add(str_temp2);
                            string str_temp3 = ls4[k].Substring(0, ls4[k].IndexOf('.'));
                            ls3_id.Add(str_temp3);
                        }
                    }
                }
            }

            SQLSentence = string.Format("delete from edb_test");
            DBManager.OpSQLWrite(SQLSentence);
            for (int i = 0; i < ls3.Count; i++)
            {
                Application.DoEvents();
                textBox_num.Text = string.Format("{0}/{1}",i.ToString(),ls3.Count.ToString());
                textBox_num.Refresh();
                SQLSentence = string.Format("insert into edb_test (id,url) values('{0}','{1}')", ls3_id[i], ls3[i]);
                DBManager.OpSQLWrite(SQLSentence);
                string str = StringHelper.get_txt_zheng(ls3[i]);
                str = str.Replace("'", "''");
                SQLSentence = string.Format("update edb set poc = '{0}' where id = '{1}'", str, ls3_id[i]);
                DBManager.OpSQLWrite(SQLSentence);
            }
        }
    }
}
