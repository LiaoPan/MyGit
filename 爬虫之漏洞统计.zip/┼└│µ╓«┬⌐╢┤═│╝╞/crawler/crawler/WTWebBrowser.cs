﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Threading;
//using VulDownLoad2.UI;
namespace crawler
{
    public class WTWebBrowser : WebBrowser
    {
        public string HtmlStr = "";

        public string GetDocumentStr()
        {
            try {
                string str = Document.Body.InnerHtml;
                return str;
            }
            catch(Exception ex)
            {
                return "";
            }
        }
    }
}
