﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace crawler
{
    class XmlReader
    {
        public List<string> ls_sessionname = new List<string>();
        public List<string> ls_sessionpath = new List<string>();
        public List<string> ls_pause = new List<string>();
        public List<string> ls_pause_ifNotExist = new List<string>();
        public List<string> ls_pause_ifNotExist_Content = new List<string>();
        
        public string sitename = "";
        public string url1 = "";
        public string url2 = "";
        public string url3 = "";
        public string StartPage = "";
        public string StartPage_buchong = "";
        public string EachPage = "";
        public string EachPage2 = "";
        public string PageNumber = "";
        public string StartUrl = "";
        public string EndUrl = "";
        public int StartPage_int = 0;
        public int StartPage_buchong_int = 0;
        public int EachPage_int = 0;
        public int EachPage2_int = 0;
        public int PageNumber_int = 0;
        public int StartUrl_int = 0;
        public int EndUrl_int = 0;
        public List<string> ls_subpage = new List<string>();
        public List<string> ls_tongziduan = new List<string>();
        public string maxCishu_total = "";
        public int maxCishu_total_int = 3;
        public string IfNewest = "";
        public int IfNewest_int = 60;

        public string DanCiXunHuanMiaoShu1 = "";
        public string DanCiXunHuanMiaoShu2 = "";
        public string XunHuanLunShu = "";
        //public string TongZiDuan = "";
        public string ZanTingMiaoShu = "";
        public string YanShi = "";
        public int DanCiXunHuanMiaoShu1_int = 2;
        public int DanCiXunHuanMiaoShu2_int = 2;
        public int XunHuanLunShu_int = 30;
        //public int TongZiDuan_int = 2;
        public int ZanTingMiaoShu_int = 2;
        public int YanShi_int = 0;

        public string Table_List_temp = "";
        public string Table_Content_temp = "";
        public string Table_Content_Final = "";
        public string Table_List_ListDownload = "";
        public string Table_Content_ListDownload = "";
        public string Table_UpdateToRemote = "";
        public string Table_Content_tempNewVul = "";
        public string Table_Content_tempUpdateVul = "";
        public string Table_Content_tempUpdateVulOld = "";

        public string Table_MaxPage = "1";
        public int Table_MaxPage_int = 1;
        public string DownloadContentWithList = "0";
        public int DownloadContentWithList_int = 0;

        public List<string> ls_Url_Relation = new List<string>();
        public List<string> ls_IfComplete = new List<string>();

        public string Pause = "";

        public XmlReader(string filename, string dir)
        {
            //解析url，session name，session path
            if (dir == "")
            {
                dir = VolOverAll.datacode;
            }
            IniXml(filename, dir);
        }

        //解析url，session name，session path
        public void IniXml(string filename, string dir)
        {
            XmlDocument doc = new XmlDocument();
            //doc.Load("d://datacode//test.xml");    //加载Xml文件  
            try
            {
                doc.Load(dir + filename);
                XmlElement rootElem = doc.DocumentElement;   //获取根节点  
                XmlNodeList titleNodes = rootElem.GetElementsByTagName("title");
                XmlNodeList sitenameNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("sitename");

                //XmlNodeList bodyNodes = rootElem.GetElementsByTagName("body"); //获取person子节点集合  
                XmlNodeList url1Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("url1");
                XmlNodeList url2Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("url2");
                XmlNodeList url3Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("url3");
                XmlNodeList StartPageNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("StartPage");
                XmlNodeList StartPagebuchongNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("StartPage_buchong");
                XmlNodeList EachPageNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("EachPage");
                XmlNodeList EachPage2Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("EachPage2");
                XmlNodeList PageNumberNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("PageNumber");
                XmlNodeList StartUrlNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("StartUrl");
                XmlNodeList EndUrlNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("EndUrl");
                XmlNodeList PauseNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Pause");
                XmlNodeList PauseIfNotExistNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("PauseIfNotExist");
                XmlNodeList PauseIfNotExist_Content_Notes = ((XmlElement)titleNodes[0]).GetElementsByTagName("PauseIfNotExist_Content");
                
                XmlNodeList SubPageNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("SubPage");

                XmlNodeList Table_List_temp_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Table_List_temp");
                XmlNodeList Table_Content_temp_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Table_Content_temp");
                XmlNodeList Table_Content_Final_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Table_Content_Final");
                XmlNodeList Table_List_ListDownload_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Table_List_ListDownload");
                XmlNodeList Table_Content_ListDownload_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Table_Content_ListDownload");
                //XmlNodeList UpdateToRemote_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("UpdateToRemote");

                XmlNodeList Table_MaxPage_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Table_MaxPage");

                XmlNodeList ls_Url_Relation_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("Url_Relation");
                XmlNodeList ls_IfComplete_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("IfComplete");
                XmlNodeList ls_tongziduan_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("tongziduan");

                XmlNodeList DownloadContentWithList_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("DownloadContentWithList");
                XmlNodeList maxCishu_total_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("maxCishu_total");
                XmlNodeList IfNewest_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("IfNewest");

                XmlNodeList DanCiXunHuanMiaoShu1_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("DanCiXunHuanMiaoShu1");
                XmlNodeList DanCiXunHuanMiaoShu2_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("DanCiXunHuanMiaoShu2");
                XmlNodeList XunHuanLunShu_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("XunHuanLunShu");
                XmlNodeList TongZiDuan_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("TongZiDuan");
                XmlNodeList ZanTingMiaoShu_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("ZanTingMiaoShu");
                XmlNodeList YanShi_Nodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("YanShi");  


                //string类型的
                sitename = sitenameNodes[0].InnerText;
                url1 = url1Nodes[0].InnerText;
                url2 = url2Nodes[0].InnerText;
                url3 = url3Nodes[0].InnerText;
                StartPage = StartPageNodes[0].InnerText;
                StartPage_buchong = StartPagebuchongNodes[0].InnerText;
                EachPage = EachPageNodes[0].InnerText;
                EachPage2 = EachPage2Nodes[0].InnerText;
                PageNumber = PageNumberNodes[0].InnerText;
                maxCishu_total = maxCishu_total_Nodes[0].InnerText;
                IfNewest = IfNewest_Nodes[0].InnerText;
                StartUrl = StartUrlNodes[0].InnerText;
                EndUrl = EndUrlNodes[0].InnerText;

                //Table_List_temp = Table_List_temp_Nodes[0].InnerText;
                //Table_Content_temp = Table_Content_temp_Nodes[0].InnerText;
                //Table_Content_Final = Table_Content_Final_Nodes[0].InnerText;
                //Table_List_ListDownload = Table_List_ListDownload_Nodes[0].InnerText;
                //Table_Content_ListDownload = Table_Content_ListDownload_Nodes[0].InnerText;
                //UpdateToRemote = UpdateToRemote_Nodes[0].InnerText;
                Table_List_temp = sitename + "_List_temp";
                Table_Content_temp = sitename + "_Content_temp";
                Table_Content_Final = sitename + "_Content_Final";
                Table_List_ListDownload = sitename + "_List_ListDownload";
                Table_Content_ListDownload = sitename + "_Content_ListDownload";
                Table_Content_tempNewVul = sitename + "_Content_tempNewVul";
                Table_Content_tempUpdateVul = sitename + "_Content_tempUpdateVul";
                Table_Content_tempUpdateVulOld = sitename + "_Content_tempUpdateVulOld";
                Table_UpdateToRemote = sitename + "_UpdateToRemote";

                Table_MaxPage = Table_MaxPage_Nodes[0].InnerText;

                DownloadContentWithList = DownloadContentWithList_Nodes[0].InnerText;

                DanCiXunHuanMiaoShu1 = DanCiXunHuanMiaoShu1_Nodes[0].InnerText;
                DanCiXunHuanMiaoShu2 = DanCiXunHuanMiaoShu2_Nodes[0].InnerText;
                XunHuanLunShu = XunHuanLunShu_Nodes[0].InnerText;
                //TongZiDuan = TongZiDuan_Nodes[0].InnerText;
                ZanTingMiaoShu = ZanTingMiaoShu_Nodes[0].InnerText;
                YanShi = YanShi_Nodes[0].InnerText;
                

                //list类型的
                for (int i = 0; i < PauseNodes.Count; i++)
                {
                    ls_pause.Add(PauseNodes[i].InnerText);
                }
                for (int i = 0; i < PauseIfNotExistNodes.Count; i++)
                {
                    ls_pause_ifNotExist.Add(PauseIfNotExistNodes[i].InnerText);
                }
                for (int i = 0; i < PauseIfNotExist_Content_Notes.Count; i++)
                {
                    ls_pause_ifNotExist_Content.Add(PauseIfNotExist_Content_Notes[i].InnerText);
                }
                for (int i = 0; i < SubPageNodes.Count; i++)
                {
                    ls_subpage.Add(SubPageNodes[i].InnerText);
                }
                for (int i = 0; i < ls_Url_Relation_Nodes.Count; i++)
                {
                    ls_Url_Relation.Add(ls_Url_Relation_Nodes[i].InnerText);
                }
                for (int i = 0; i < ls_IfComplete_Nodes.Count; i++)
                {
                    ls_IfComplete.Add(ls_IfComplete_Nodes[i].InnerText);
                }
                for (int i = 0; i < ls_tongziduan_Nodes.Count; i++)
                {
                    ls_tongziduan.Add(ls_tongziduan_Nodes[i].InnerText);
                }

                //int类型的
                if (StartPage.Length > 0)
                {
                    StartPage_int = System.Int32.Parse(StartPage);
                }
                if (StartPage_buchong.Length > 0)
                {
                    StartPage_buchong_int = System.Int32.Parse(StartPage_buchong);
                }
                if (EachPage.Length > 0)
                {
                    EachPage_int = System.Int32.Parse(EachPage);
                }
                if (EachPage2.Length > 0)
                {
                    EachPage2_int = System.Int32.Parse(EachPage2);
                }
                if (PageNumber.Length > 0)
                {
                    PageNumber_int = System.Int32.Parse(PageNumber);
                }
                if (StartUrl.Length > 0)
                {
                    StartUrl_int = System.Int32.Parse(StartUrl);
                }
                if (EndUrl.Length > 0)
                {
                    EndUrl_int = System.Int32.Parse(EndUrl);
                }
                if (EndUrl.Length > 0)
                {
                    EndUrl_int = System.Int32.Parse(EndUrl);
                }
                if (Table_MaxPage.Length > 0)
                {
                    Table_MaxPage_int = System.Int32.Parse(Table_MaxPage);
                }
                if (DownloadContentWithList.Length > 0)
                {
                    DownloadContentWithList_int = System.Int32.Parse(DownloadContentWithList);
                }
                if (maxCishu_total.Length > 0)
                {
                    maxCishu_total_int = System.Int32.Parse(maxCishu_total);
                }
                if (IfNewest.Length > 0)
                {
                    IfNewest_int = System.Int32.Parse(IfNewest);
                }

                if (DanCiXunHuanMiaoShu1.Length > 0)
                {
                    DanCiXunHuanMiaoShu1_int = System.Int32.Parse(DanCiXunHuanMiaoShu1);
                }
                if (DanCiXunHuanMiaoShu2.Length > 0)
                {
                    DanCiXunHuanMiaoShu2_int = System.Int32.Parse(DanCiXunHuanMiaoShu2);
                }
                if (XunHuanLunShu.Length > 0)
                {
                    XunHuanLunShu_int = System.Int32.Parse(XunHuanLunShu);
                }
                //if (TongZiDuan.Length > 0)
                //{
                //    TongZiDuan_int = System.Int32.Parse(TongZiDuan);
                //}
                if (ZanTingMiaoShu.Length > 0)
                {
                    ZanTingMiaoShu_int = System.Int32.Parse(ZanTingMiaoShu);
                }
                if (YanShi.Length > 0)
                {
                    YanShi_int = System.Int32.Parse(YanShi);
                }
                


                //处理body节点
                XmlNodeList bodyNodes = rootElem.GetElementsByTagName("body"); //获取person子节点集合  
                if (bodyNodes.Count == 1)
                {
                    XmlNodeList sessionnameNodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("sessionname");  //获取age子XmlElement集合 
                    //List<string> ls_sessionname = new List<string>();
                    for (int i = 0; i < sessionnameNodes.Count; i++)
                    {
                        ls_sessionname.Add(sessionnameNodes[i].InnerText);
                    }
                    XmlNodeList sessionpathNodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("sessionpath");
                    //List<string> ls_sessionpath = new List<string>();
                    for (int i = 0; i < sessionpathNodes.Count; i++)
                    {
                        ls_sessionpath.Add(sessionpathNodes[i].InnerText);
                    }
                } 
            }
            catch(Exception e)
            {
                MessageBox.Show("xml文件错误");
            }
        }
    }
}
