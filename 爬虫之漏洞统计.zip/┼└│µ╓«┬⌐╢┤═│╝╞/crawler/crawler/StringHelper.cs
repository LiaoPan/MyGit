﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crawler
{
    class StringHelper
    {
        //删除两个空格
        public static string space_delete(string str)
        {
            while (str.Contains("  "))
            {
                str = str.Replace("  ", " ");
            }
            return str;
        }

        public static string MyNow()
        {
            string NowYear = DateTime.Now.Year.ToString();
            string NowMonth = DateTime.Now.Month.ToString();
            if (NowMonth.Count() < 2)
                NowMonth = "0" + NowMonth;
            string NowDay = DateTime.Now.Day.ToString();
            if (NowDay.Count() < 2)
                NowDay = "0" + NowDay;
            string NowHour = DateTime.Now.Hour.ToString();
            if (NowHour.Count() < 2)
                NowHour = "0" + NowHour;
            string NowMinute = DateTime.Now.Minute.ToString();
            if (NowMinute.Count() < 2)
                NowMinute = "0" + NowMinute;
            string NowSecond = DateTime.Now.Second.ToString();
            if (NowSecond.Count() < 2)
                NowSecond = "0" + NowSecond;
            string strNow = NowYear + "/" + NowMonth + "/" + NowDay + " " + NowHour + ":" + NowMinute + ":" + NowSecond;

            return strNow;
        }

        public List<string> myTrim(List<string> ls_id)
        {
            for (int h = 0; h < ls_id.Count(); h++)
            {
                while (ls_id[h].Contains("\r\n\r\n"))
                {
                    ls_id[h] = ls_id[h].Replace("\r\n\r\n", "\r\n");
                }
                ls_id[h] = ls_id[h].Trim();
                //ls_id[h] = ls_id[h].Replace("*",VolOverAll.replace);
                //ls_id[h] = ls_id[h].Replace("\r\n", "*");
            }

            return ls_id;
        }

        //相关系数
        public static double MyXiangGuanDu_n_small(string str1, string str2, int n)
        {
            str1 = tristr(str1);
            str2 = tristr(str2);
            str1 = str1.Replace(" ", "");
            str2 = str2.Replace(" ", "");

            string smallstr = "";
            string bigstr = "";

            if (str1.Length > str2.Length)
            {
                bigstr = str1;
                smallstr = str2;
            }
            else
            {
                bigstr = str2;
                smallstr = str1;
            }

            double lengh = smallstr.Length - n + 1;
            double point = 0;
            for (int h = 0; h < lengh; h++)
            {
                string temp = smallstr.Substring(h, n);
                if (bigstr.Contains(temp))
                {
                    point = point + 1;
                }
            }

            return (double)point / (double)lengh;
        }

        public static double MyXiangGuanDu_n_big(string str1, string str2, int n)
        {
            str1 = tristr(str1);
            str2 = tristr(str2);
            str1 = str1.Replace(" ", "");
            str2 = str2.Replace(" ", "");

            string smallstr = "";
            string bigstr = "";

            if (str1.Length > str2.Length)
            {
                bigstr = str2;
                smallstr = str1;
            }
            else
            {
                bigstr = str1;
                smallstr = str2;
            }

            double lengh = smallstr.Length - n + 1;
            double point = 0;
            for (int h = 0; h < lengh; h++)
            {
                string temp = smallstr.Substring(h, n);
                if (bigstr.Contains(temp))
                {
                    point = point + 1;
                }
            }

            return (double)point / (double)lengh;
        }

        public static double MyXiangGuanDu_n_changdu(string str1, string str2)
        {
            //str1 = tristr(str1);
            //str2 = tristr(str2);
            //str1 = str1.Replace(" ", "");
            //str2 = str2.Replace(" ", "");

            string smallstr = "";
            string bigstr = "";

            if (str1.Length > str2.Length)
            {
                bigstr = str1;
                smallstr = str2;
            }
            else
            {
                bigstr = str2;
                smallstr = str1;
            }

            for (int n = smallstr.Length; n > 0; n--)
            {
                double lengh = smallstr.Length - n + 1;
                int flag_changdu = 0;
                for (int h = 0; h < lengh; h++)
                {
                    string temp = smallstr.Substring(h, n);
                    if (bigstr.Contains(temp))
                    {
                        flag_changdu = n;
                        break;
                    }
                }
                if (flag_changdu > 0)
                    return flag_changdu;
            }

            return 0;
        }

        public static string tristr(string str)
        {
            string[] strs = str.Split(' ');
            str = "";
            for (int h = 0; h < strs.Count(); h++)
            {
                if (strs[h].Trim() != "")
                {
                    str = str + " " + strs[h] + strs[h] + strs[h];
                }
            }
            str = str + " ";
            return str;
        }

        //求方差
        public static double Var(List<double> nums)
        {
            double sum = 0;
            for (int i = 0; i < nums.Count(); i++)
            {
                sum += nums[i];
            }//求和
            double avg = sum / nums.Count();//求平均数
            double variance = 0;
            for (int i = 0; i < nums.Count(); i++)
            {
                variance += Math.Pow(nums[i] - avg, 2);
            }//求方差
            variance = variance / nums.Count();
            double sd = Math.Pow(variance, 0.5);//求标准差
            return sd;
        }

        //md5
        public static string Encrypt(string strPwd)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] data = System.Text.Encoding.Default.GetBytes(strPwd);//将字符编码为一个字节序列 
            byte[] md5data = md5.ComputeHash(data);//计算data字节数组的哈希值 
            md5.Clear();
            string str = "";
            for (int i = 0; i < md5data.Length - 1; i++)
            {
                str += md5data[i].ToString("x").PadLeft(2, '0');
            }
            return str;
        }

        public static void MyPause(int second = 0)
        {
            //留1秒点暂停的时间
            for (int i = 0; i < 100 && VolOverAll.pause_redownload_nextdownload == 1; i++)
            {
                Application.DoEvents();
                Thread.Sleep(10);
            }

            int second_temp = -1;
            //判断是否已经暂停
            while (VolOverAll.pause_redownload_nextdownload == 1 && second_temp < second * 10)
            {
                Application.DoEvents();
                Thread.Sleep(100);
                if (second > 0)
                {
                    second_temp = second_temp + 1;
                }
            }
        }

        public static void MySleep(int second)
        {
            int second_temp = -1;
            //判断是否已经暂停
            while (second_temp < second * 10)
            {
                Application.DoEvents();
                Thread.Sleep(100);
                if (second > 0)
                {
                    second_temp = second_temp + 1;
                }
            }
        }

        public static List<string> MySplit(string str, string VeriCode)
        {
            str = str.Replace("^", VolOverAll.replace);
            str = str.Replace(VeriCode, "^");
            string[] strs = str.Split('^');
            List<string> ls = new List<string>();
            for (int i = 0; i < strs.Count(); i++ )
            {
                string str_temp = strs[i].Replace(VolOverAll.replace, "^");
                ls.Add(str_temp);
            }
            return ls;
        }

        public static void MyMessagebox(string str, int n)
        {
            if (n == 1 && VolOverAll.Display_Messagebox == "checked")
            {
                MessageBox.Show(str);
            }
            else if(n == 2 && VolOverAll.Display_Messagebox2 == "checked")
            {
                MessageBox.Show(str);
            }
            else if (n == 3 && VolOverAll.Display_Messagebox3 == "checked")
            {
                MessageBox.Show(str);
            }
            else if (n == 4 && VolOverAll.Display_Messagebox4 == "checked")
            {
                MessageBox.Show(str);
            }
        }

        //读取txt
        public static List<string> get_txt(string filename)
        {
            StreamReader sr = new StreamReader(filename, Encoding.Default);
            string s;
            List<string> ls = new List<string>();
            while ((s = sr.ReadLine()) != null)
            {
                ls.Add(s);
            }
            return ls;
        }

        //读取txt
        public static string get_txt_zheng(string filename)
        {
            StreamReader sr = new StreamReader(filename, Encoding.Default);
            string s;
            string str = "";
            while ((s = sr.ReadLine()) != null)
            {
                str = str + System.Environment.NewLine + s;
            }

            return str;
        }

        //写txt
        public static void write_txt(string filename, string str)
        {
            StreamWriter sw = new StreamWriter(filename);
            string w = str;
            sw.Write(w);
            sw.Close();
        }

        public static List<string> DsToList(DataSet ds, int n = 0)
        {
            int total = ds.Tables[0].Rows.Count;
            List<string> ls = new List<string>();
            for (int i = 0; i < total; i++ )
            {
                ls.Add(ds.Tables[0].Rows[i][n].ToString());
            }

            return ls;
        }

        //str_url下载网页的url地址，path为保存的路径
        //string URLAddress = @"http://gr.xidian.edu.cn/upload/1421486319766硕博连读（直接攻博）研究生申请硕士答辩审批表-2015年版..doc";
        //string URLAddress = @"http://www.exploit-db.com/download/36053";
        //string receivePath = @"d:\";
        public static bool DownloadFile(string str_url, string path)
        {
            string filename = "";
            try
            {
                WebClient client = new WebClient();                
                client.DownloadFile(str_url, path + "temp");
                filename = client.ResponseHeaders["Content-Disposition"];//获取文件名
                if (filename == null)
                {
                    filename = path + System.IO.Path.GetFileName(str_url);
                }
                else
                {
                    filename = path + filename;
                }
            }
            catch(Exception e)
            {
                MessageBox.Show("下载失败");
                return false;
            }


            try
            {
                bool flag = false;
                string filename_backup = filename;
                //判断该文件是否存在，若存在则加(2)
                for (int i = 2; i < 1000000;i++ )
                {
                    if (System.IO.File.Exists(filename))
                    {
                        filename = filename_backup + "(" + i.ToString() + ")";
                    }
                    else
                    {
                        flag = true;
                        break;
                    }
                }
                
                //重命名 初始名字为temp
                System.IO.File.Move(path + "temp", filename);
            }
            catch(Exception e)
            {
                MessageBox.Show("重命名失败");
                return false;
            }

            return true;
        }

        //获取目录下所有文件名
        public static List<string> getDirFile(string path)
        {
            DirectoryInfo parentdi = new DirectoryInfo(path);
            FileInfo[] files = parentdi.GetFiles();
            List<string> ls_filename = new List<string>();
            for (int i = 0; i < files.Length; i++)//访问当前目录的文件
            {
                ls_filename.Add(files[i].Name);
            }
            return ls_filename;
        }

        //获取目录下所有子目录名
        public static List<string> getSubDirs(string directory, int maxCount = 10000)
        {
            List<string> subDirectories = new List<string>();
            if (string.IsNullOrEmpty(directory))
            {
                return subDirectories;
            }
            if (maxCount <= 0)
            {
                return subDirectories;
            }
            string[] directories = Directory.GetDirectories(directory);
            foreach (string subDirectory in directories)
            {
                if (subDirectories.Count == maxCount)
                {
                    break;
                }
                subDirectories.Add(subDirectory);
            }
            return subDirectories;
        }

    }
}
