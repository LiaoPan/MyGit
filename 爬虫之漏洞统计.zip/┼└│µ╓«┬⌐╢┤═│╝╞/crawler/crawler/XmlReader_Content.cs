﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace crawler
{
    class XmlReader_Content
    {
        public List<string> ls_sessionname = new List<string>();
        public List<string> ls_sessionpath = new List<string>();
        public List<string> ls_sessionlengh = new List<string>();
        public List<string> ls_sessionmd5 = new List<string>();
        public List<string> ls_sessionComplete = new List<string>();
        public string sitename = "";

        public XmlReader_Content(string filename, string dir)
        {
            //解析url，session name，session path
            if (dir == "")
            {
                dir = VolOverAll.datacode;
            }
            IniXml(filename, dir);
        }

        //解析url，session name，session path
        public void IniXml(string filename, string dir)
        {
            XmlDocument doc = new XmlDocument();
            //doc.Load("d://datacode//test.xml");    //加载Xml文件  
            doc.Load(dir + filename);
            XmlElement rootElem = doc.DocumentElement;   //获取根节点  
            XmlNodeList titleNodes = rootElem.GetElementsByTagName("title");
            XmlNodeList sitenameNodes = ((XmlElement)titleNodes[0]).GetElementsByTagName("sitename");
            sitename = sitenameNodes[0].InnerText;

            XmlNodeList bodyNodes = rootElem.GetElementsByTagName("body"); //获取person子节点集合  
            if (bodyNodes.Count == 1)
            {
                XmlNodeList sessionnameNodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("sessionname");  //获取age子XmlElement集合 
                //List<string> ls_sessionname = new List<string>();
                for (int i = 0; i < sessionnameNodes.Count; i++)
                {
                    ls_sessionname.Add(sessionnameNodes[i].InnerText);
                }
                XmlNodeList sessionpathNodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("sessionpath");
                //List<string> ls_sessionpath = new List<string>();
                for (int i = 0; i < sessionpathNodes.Count; i++)
                {
                    ls_sessionpath.Add(sessionpathNodes[i].InnerText);
                }
                XmlNodeList sessionlenghNodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("sessionlengh");
                //List<string> ls_sessionpath = new List<string>();
                for (int i = 0; i < sessionlenghNodes.Count; i++)
                {
                    ls_sessionlengh.Add(sessionlenghNodes[i].InnerText);
                }
                XmlNodeList sessionmd5Nodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("md5");
                for (int i = 0; i < sessionmd5Nodes.Count; i++)
                {
                    ls_sessionmd5.Add(sessionmd5Nodes[i].InnerText);
                }
                XmlNodeList sessionCompleteNodes = ((XmlElement)bodyNodes[0]).GetElementsByTagName("sessionComplete");
                for (int i = 0; i < sessionCompleteNodes.Count; i++)
                {
                    ls_sessionComplete.Add(sessionCompleteNodes[i].InnerText);
                }
            } 
        }
    }
}
