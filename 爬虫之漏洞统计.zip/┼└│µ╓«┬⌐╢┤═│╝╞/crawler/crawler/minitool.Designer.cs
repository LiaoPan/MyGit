﻿namespace crawler
{
    partial class minitool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_getstring = new System.Windows.Forms.Button();
            this.button_getxpath = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_getstring
            // 
            this.button_getstring.Location = new System.Drawing.Point(13, 13);
            this.button_getstring.Name = "button_getstring";
            this.button_getstring.Size = new System.Drawing.Size(111, 32);
            this.button_getstring.TabIndex = 0;
            this.button_getstring.Text = "获取string";
            this.button_getstring.UseVisualStyleBackColor = true;
            this.button_getstring.Click += new System.EventHandler(this.button_getstring_Click);
            // 
            // button_getxpath
            // 
            this.button_getxpath.Location = new System.Drawing.Point(12, 51);
            this.button_getxpath.Name = "button_getxpath";
            this.button_getxpath.Size = new System.Drawing.Size(112, 30);
            this.button_getxpath.TabIndex = 1;
            this.button_getxpath.Text = "获取xpath";
            this.button_getxpath.UseVisualStyleBackColor = true;
            this.button_getxpath.Click += new System.EventHandler(this.button_getxpath_Click);
            // 
            // minitool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 244);
            this.Controls.Add(this.button_getxpath);
            this.Controls.Add(this.button_getstring);
            this.Name = "minitool";
            this.Text = "minitool";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_getstring;
        private System.Windows.Forms.Button button_getxpath;
    }
}