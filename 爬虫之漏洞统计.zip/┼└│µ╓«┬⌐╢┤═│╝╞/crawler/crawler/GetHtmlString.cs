﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crawler
{
    public partial class GetHtmlString : Form
    {
        public GetHtmlString()
        {
            InitializeComponent();
            textBox1.Text = VolOverAll.documentText;
            textBox1.Refresh();
        }
 
        private void GetHtmlString_Load(object sender, EventArgs e)
        {

        }
    }
}
