﻿namespace crawler
{
    partial class CrawlerDlg
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.GetXML = new System.Windows.Forms.Button();
            this.url_txt = new System.Windows.Forms.TextBox();
            this.OutTimeLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.webBrowser1 = new crawler.WTWebBrowser();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.button_go = new System.Windows.Forms.Button();
            this.textBox_num = new System.Windows.Forms.TextBox();
            this.textBox_url = new System.Windows.Forms.TextBox();
            this.button_tool = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.IfErrorPage_txt = new System.Windows.Forms.TextBox();
            this.button_PauseNaviget = new System.Windows.Forms.Button();
            this.checkBox_display_prompt = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.edb_poc_btn = new System.Windows.Forms.Button();
            this.DownFile_btn = new System.Windows.Forms.Button();
            this.textBox_deletetable = new System.Windows.Forms.TextBox();
            this.DownloadWithList_btn = new System.Windows.Forms.Button();
            this.download = new System.Windows.Forms.Button();
            this.sf_poc_btn = new System.Windows.Forms.Button();
            this.delete_tbl_btn = new System.Windows.Forms.Button();
            this.button_downloadnext = new System.Windows.Forms.Button();
            this.button_redownload = new System.Windows.Forms.Button();
            this.checkBox_display_prompt2 = new System.Windows.Forms.CheckBox();
            this.checkBox_display_prompt3 = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.closewindow_btn = new System.Windows.Forms.Button();
            this.checkBox_display_prompt4 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_dancixunhuamiao = new System.Windows.Forms.TextBox();
            this.textBox_xunhuanlunshu = new System.Windows.Forms.TextBox();
            this.chb_zidongpanduanxiazaiwanbi = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.chb_jishishangyexiangtong = new System.Windows.Forms.CheckBox();
            this.textBox_dancixunhuamiao1 = new System.Windows.Forms.TextBox();
            this.textBox_zongziduan = new System.Windows.Forms.TextBox();
            this.textBox_tongziduan = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.chk_PauseContiune2 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_PauseSecond = new System.Windows.Forms.TextBox();
            this.chk_PauseContiune = new System.Windows.Forms.CheckBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.getName = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_delay = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TableName2 = new System.Windows.Forms.TextBox();
            this.TableName1 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // GetXML
            // 
            this.GetXML.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.GetXML.Location = new System.Drawing.Point(5, 5);
            this.GetXML.Margin = new System.Windows.Forms.Padding(2);
            this.GetXML.Name = "GetXML";
            this.GetXML.Size = new System.Drawing.Size(75, 23);
            this.GetXML.TabIndex = 0;
            this.GetXML.Text = "更新";
            this.GetXML.UseVisualStyleBackColor = true;
            this.GetXML.Click += new System.EventHandler(this.GetXML_Click);
            // 
            // url_txt
            // 
            this.url_txt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.url_txt.Location = new System.Drawing.Point(64, 7);
            this.url_txt.Margin = new System.Windows.Forms.Padding(2);
            this.url_txt.Name = "url_txt";
            this.url_txt.Size = new System.Drawing.Size(604, 21);
            this.url_txt.TabIndex = 2;
            // 
            // OutTimeLabel
            // 
            this.OutTimeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.OutTimeLabel.AutoSize = true;
            this.OutTimeLabel.Location = new System.Drawing.Point(3, 13);
            this.OutTimeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.OutTimeLabel.Name = "OutTimeLabel";
            this.OutTimeLabel.Size = new System.Drawing.Size(53, 12);
            this.OutTimeLabel.TabIndex = 3;
            this.OutTimeLabel.Text = "网页状态";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.webBrowser1);
            this.panel1.Location = new System.Drawing.Point(8, 42);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(3);
            this.panel1.Size = new System.Drawing.Size(1102, 225);
            this.panel1.TabIndex = 4;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(3, 3);
            this.webBrowser1.Margin = new System.Windows.Forms.Padding(2);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(13, 13);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1094, 217);
            this.webBrowser1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.url_txt);
            this.panel2.Controls.Add(this.button_go);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3);
            this.panel2.Size = new System.Drawing.Size(1117, 34);
            this.panel2.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 11;
            this.label10.Text = "地址栏：";
            // 
            // button_go
            // 
            this.button_go.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_go.Location = new System.Drawing.Point(672, 5);
            this.button_go.Margin = new System.Windows.Forms.Padding(2);
            this.button_go.Name = "button_go";
            this.button_go.Size = new System.Drawing.Size(50, 24);
            this.button_go.TabIndex = 10;
            this.button_go.Text = ">>go";
            this.button_go.UseVisualStyleBackColor = true;
            this.button_go.Click += new System.EventHandler(this.button_go_Click);
            // 
            // textBox_num
            // 
            this.textBox_num.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_num.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox_num.Location = new System.Drawing.Point(3, 29);
            this.textBox_num.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_num.Name = "textBox_num";
            this.textBox_num.Size = new System.Drawing.Size(1094, 21);
            this.textBox_num.TabIndex = 6;
            // 
            // textBox_url
            // 
            this.textBox_url.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_url.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox_url.Location = new System.Drawing.Point(85, 54);
            this.textBox_url.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_url.Name = "textBox_url";
            this.textBox_url.Size = new System.Drawing.Size(1012, 21);
            this.textBox_url.TabIndex = 7;
            // 
            // button_tool
            // 
            this.button_tool.Location = new System.Drawing.Point(5, 32);
            this.button_tool.Margin = new System.Windows.Forms.Padding(2);
            this.button_tool.Name = "button_tool";
            this.button_tool.Size = new System.Drawing.Size(75, 23);
            this.button_tool.TabIndex = 9;
            this.button_tool.Text = "工具";
            this.button_tool.UseVisualStyleBackColor = true;
            this.button_tool.Click += new System.EventHandler(this.button_tool_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "当前下载页面:";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.IfErrorPage_txt);
            this.panel3.Controls.Add(this.OutTimeLabel);
            this.panel3.Controls.Add(this.textBox_num);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.textBox_url);
            this.panel3.Location = new System.Drawing.Point(8, 273);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1102, 106);
            this.panel3.TabIndex = 10;
            // 
            // IfErrorPage_txt
            // 
            this.IfErrorPage_txt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IfErrorPage_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.IfErrorPage_txt.Location = new System.Drawing.Point(4, 80);
            this.IfErrorPage_txt.Margin = new System.Windows.Forms.Padding(2);
            this.IfErrorPage_txt.Name = "IfErrorPage_txt";
            this.IfErrorPage_txt.Size = new System.Drawing.Size(1093, 21);
            this.IfErrorPage_txt.TabIndex = 9;
            // 
            // button_PauseNaviget
            // 
            this.button_PauseNaviget.Location = new System.Drawing.Point(87, 5);
            this.button_PauseNaviget.Name = "button_PauseNaviget";
            this.button_PauseNaviget.Size = new System.Drawing.Size(90, 23);
            this.button_PauseNaviget.TabIndex = 11;
            this.button_PauseNaviget.Text = "暂停下载";
            this.button_PauseNaviget.UseVisualStyleBackColor = true;
            this.button_PauseNaviget.Click += new System.EventHandler(this.button_PauseNaviget_Click);
            // 
            // checkBox_display_prompt
            // 
            this.checkBox_display_prompt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox_display_prompt.AutoSize = true;
            this.checkBox_display_prompt.Location = new System.Drawing.Point(13, 12);
            this.checkBox_display_prompt.Name = "checkBox_display_prompt";
            this.checkBox_display_prompt.Size = new System.Drawing.Size(72, 16);
            this.checkBox_display_prompt.TabIndex = 11;
            this.checkBox_display_prompt.Text = "显示提示";
            this.checkBox_display_prompt.UseVisualStyleBackColor = true;
            this.checkBox_display_prompt.CheckedChanged += new System.EventHandler(this.checkBox_display_prompt_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel4.BackColor = System.Drawing.Color.LightCoral;
            this.panel4.Controls.Add(this.edb_poc_btn);
            this.panel4.Controls.Add(this.DownFile_btn);
            this.panel4.Controls.Add(this.textBox_deletetable);
            this.panel4.Controls.Add(this.DownloadWithList_btn);
            this.panel4.Controls.Add(this.download);
            this.panel4.Controls.Add(this.sf_poc_btn);
            this.panel4.Controls.Add(this.delete_tbl_btn);
            this.panel4.Controls.Add(this.button_downloadnext);
            this.panel4.Controls.Add(this.button_redownload);
            this.panel4.Controls.Add(this.GetXML);
            this.panel4.Controls.Add(this.button_PauseNaviget);
            this.panel4.Controls.Add(this.button_tool);
            this.panel4.Location = new System.Drawing.Point(8, 386);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(274, 156);
            this.panel4.TabIndex = 12;
            // 
            // edb_poc_btn
            // 
            this.edb_poc_btn.Location = new System.Drawing.Point(187, 89);
            this.edb_poc_btn.Name = "edb_poc_btn";
            this.edb_poc_btn.Size = new System.Drawing.Size(75, 23);
            this.edb_poc_btn.TabIndex = 19;
            this.edb_poc_btn.Text = "edb_poc";
            this.edb_poc_btn.UseVisualStyleBackColor = true;
            this.edb_poc_btn.Click += new System.EventHandler(this.edb_poc_btn_Click);
            // 
            // DownFile_btn
            // 
            this.DownFile_btn.Location = new System.Drawing.Point(187, 61);
            this.DownFile_btn.Name = "DownFile_btn";
            this.DownFile_btn.Size = new System.Drawing.Size(75, 23);
            this.DownFile_btn.TabIndex = 18;
            this.DownFile_btn.Text = "下载文件";
            this.DownFile_btn.UseVisualStyleBackColor = true;
            this.DownFile_btn.Click += new System.EventHandler(this.DownFile_btn_Click);
            // 
            // textBox_deletetable
            // 
            this.textBox_deletetable.Location = new System.Drawing.Point(6, 123);
            this.textBox_deletetable.Name = "textBox_deletetable";
            this.textBox_deletetable.Size = new System.Drawing.Size(171, 21);
            this.textBox_deletetable.TabIndex = 17;
            // 
            // DownloadWithList_btn
            // 
            this.DownloadWithList_btn.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DownloadWithList_btn.Location = new System.Drawing.Point(187, 5);
            this.DownloadWithList_btn.Name = "DownloadWithList_btn";
            this.DownloadWithList_btn.Size = new System.Drawing.Size(75, 23);
            this.DownloadWithList_btn.TabIndex = 16;
            this.DownloadWithList_btn.Text = "用列表下载";
            this.DownloadWithList_btn.UseVisualStyleBackColor = true;
            this.DownloadWithList_btn.Click += new System.EventHandler(this.DownloadWithList_btn_Click);
            // 
            // download
            // 
            this.download.Location = new System.Drawing.Point(187, 32);
            this.download.Name = "download";
            this.download.Size = new System.Drawing.Size(75, 23);
            this.download.TabIndex = 15;
            this.download.Text = "下载列表";
            this.download.UseVisualStyleBackColor = true;
            this.download.Click += new System.EventHandler(this.download_Click);
            // 
            // sf_poc_btn
            // 
            this.sf_poc_btn.Location = new System.Drawing.Point(87, 89);
            this.sf_poc_btn.Name = "sf_poc_btn";
            this.sf_poc_btn.Size = new System.Drawing.Size(90, 23);
            this.sf_poc_btn.TabIndex = 14;
            this.sf_poc_btn.Text = "sf_poc";
            this.sf_poc_btn.UseVisualStyleBackColor = true;
            this.sf_poc_btn.Click += new System.EventHandler(this.sf_poc_btn_Click);
            // 
            // delete_tbl_btn
            // 
            this.delete_tbl_btn.Location = new System.Drawing.Point(6, 89);
            this.delete_tbl_btn.Name = "delete_tbl_btn";
            this.delete_tbl_btn.Size = new System.Drawing.Size(75, 23);
            this.delete_tbl_btn.TabIndex = 14;
            this.delete_tbl_btn.Text = "删除备份表";
            this.delete_tbl_btn.UseVisualStyleBackColor = true;
            this.delete_tbl_btn.Click += new System.EventHandler(this.delete_tbl_btn_Click);
            // 
            // button_downloadnext
            // 
            this.button_downloadnext.Location = new System.Drawing.Point(5, 61);
            this.button_downloadnext.Name = "button_downloadnext";
            this.button_downloadnext.Size = new System.Drawing.Size(172, 23);
            this.button_downloadnext.TabIndex = 13;
            this.button_downloadnext.Text = "下载下一页 不保存本页";
            this.button_downloadnext.UseVisualStyleBackColor = true;
            this.button_downloadnext.Click += new System.EventHandler(this.button_downloadnext_Click);
            // 
            // button_redownload
            // 
            this.button_redownload.Location = new System.Drawing.Point(87, 32);
            this.button_redownload.Name = "button_redownload";
            this.button_redownload.Size = new System.Drawing.Size(90, 23);
            this.button_redownload.TabIndex = 12;
            this.button_redownload.Text = "重新下载本页";
            this.button_redownload.UseVisualStyleBackColor = true;
            this.button_redownload.Click += new System.EventHandler(this.button_redownload_Click);
            // 
            // checkBox_display_prompt2
            // 
            this.checkBox_display_prompt2.AutoSize = true;
            this.checkBox_display_prompt2.Location = new System.Drawing.Point(13, 36);
            this.checkBox_display_prompt2.Name = "checkBox_display_prompt2";
            this.checkBox_display_prompt2.Size = new System.Drawing.Size(78, 16);
            this.checkBox_display_prompt2.TabIndex = 13;
            this.checkBox_display_prompt2.Text = "显示提示2";
            this.checkBox_display_prompt2.UseVisualStyleBackColor = true;
            this.checkBox_display_prompt2.CheckedChanged += new System.EventHandler(this.checkBox_display_prompt2_CheckedChanged);
            // 
            // checkBox_display_prompt3
            // 
            this.checkBox_display_prompt3.AutoSize = true;
            this.checkBox_display_prompt3.Location = new System.Drawing.Point(13, 60);
            this.checkBox_display_prompt3.Name = "checkBox_display_prompt3";
            this.checkBox_display_prompt3.Size = new System.Drawing.Size(78, 16);
            this.checkBox_display_prompt3.TabIndex = 14;
            this.checkBox_display_prompt3.Text = "提示3 sql";
            this.checkBox_display_prompt3.UseVisualStyleBackColor = true;
            this.checkBox_display_prompt3.CheckedChanged += new System.EventHandler(this.checkBox_display_prompt3_CheckedChanged);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel5.Controls.Add(this.closewindow_btn);
            this.panel5.Controls.Add(this.checkBox_display_prompt4);
            this.panel5.Controls.Add(this.checkBox_display_prompt3);
            this.panel5.Controls.Add(this.checkBox_display_prompt);
            this.panel5.Controls.Add(this.checkBox_display_prompt2);
            this.panel5.Location = new System.Drawing.Point(288, 386);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(105, 156);
            this.panel5.TabIndex = 13;
            // 
            // closewindow_btn
            // 
            this.closewindow_btn.Location = new System.Drawing.Point(13, 105);
            this.closewindow_btn.Name = "closewindow_btn";
            this.closewindow_btn.Size = new System.Drawing.Size(75, 23);
            this.closewindow_btn.TabIndex = 16;
            this.closewindow_btn.Text = "关闭窗口";
            this.closewindow_btn.UseVisualStyleBackColor = true;
            this.closewindow_btn.Click += new System.EventHandler(this.closewindow_btn_Click);
            // 
            // checkBox_display_prompt4
            // 
            this.checkBox_display_prompt4.AutoSize = true;
            this.checkBox_display_prompt4.Location = new System.Drawing.Point(13, 81);
            this.checkBox_display_prompt4.Name = "checkBox_display_prompt4";
            this.checkBox_display_prompt4.Size = new System.Drawing.Size(84, 16);
            this.checkBox_display_prompt4.TabIndex = 15;
            this.checkBox_display_prompt4.Text = "提示4 线程";
            this.checkBox_display_prompt4.UseVisualStyleBackColor = true;
            this.checkBox_display_prompt4.CheckedChanged += new System.EventHandler(this.checkBox_display_prompt4_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "单词循环秒：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 15;
            this.label3.Text = "循环轮数：";
            // 
            // textBox_dancixunhuamiao
            // 
            this.textBox_dancixunhuamiao.Location = new System.Drawing.Point(119, 5);
            this.textBox_dancixunhuamiao.Name = "textBox_dancixunhuamiao";
            this.textBox_dancixunhuamiao.Size = new System.Drawing.Size(26, 21);
            this.textBox_dancixunhuamiao.TabIndex = 16;
            this.textBox_dancixunhuamiao.Text = "2";
            // 
            // textBox_xunhuanlunshu
            // 
            this.textBox_xunhuanlunshu.Location = new System.Drawing.Point(89, 26);
            this.textBox_xunhuanlunshu.Name = "textBox_xunhuanlunshu";
            this.textBox_xunhuanlunshu.Size = new System.Drawing.Size(56, 21);
            this.textBox_xunhuanlunshu.TabIndex = 17;
            this.textBox_xunhuanlunshu.Text = "30";
            // 
            // chb_zidongpanduanxiazaiwanbi
            // 
            this.chb_zidongpanduanxiazaiwanbi.AutoSize = true;
            this.chb_zidongpanduanxiazaiwanbi.Checked = true;
            this.chb_zidongpanduanxiazaiwanbi.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_zidongpanduanxiazaiwanbi.Location = new System.Drawing.Point(17, 50);
            this.chb_zidongpanduanxiazaiwanbi.Name = "chb_zidongpanduanxiazaiwanbi";
            this.chb_zidongpanduanxiazaiwanbi.Size = new System.Drawing.Size(144, 16);
            this.chb_zidongpanduanxiazaiwanbi.TabIndex = 18;
            this.chb_zidongpanduanxiazaiwanbi.Text = "是否自动判断下载完毕";
            this.chb_zidongpanduanxiazaiwanbi.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel6.Controls.Add(this.chb_jishishangyexiangtong);
            this.panel6.Controls.Add(this.textBox_dancixunhuamiao1);
            this.panel6.Controls.Add(this.textBox_zongziduan);
            this.panel6.Controls.Add(this.textBox_tongziduan);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.chk_PauseContiune2);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.textBox_PauseSecond);
            this.panel6.Controls.Add(this.chk_PauseContiune);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.chb_zidongpanduanxiazaiwanbi);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.textBox_xunhuanlunshu);
            this.panel6.Controls.Add(this.textBox_dancixunhuamiao);
            this.panel6.Location = new System.Drawing.Point(399, 385);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(272, 157);
            this.panel6.TabIndex = 19;
            // 
            // chb_jishishangyexiangtong
            // 
            this.chb_jishishangyexiangtong.AutoSize = true;
            this.chb_jishishangyexiangtong.Location = new System.Drawing.Point(168, 105);
            this.chb_jishishangyexiangtong.Name = "chb_jishishangyexiangtong";
            this.chb_jishishangyexiangtong.Size = new System.Drawing.Size(96, 16);
            this.chb_jishishangyexiangtong.TabIndex = 28;
            this.chb_jishishangyexiangtong.Text = "即使上页相同";
            this.chb_jishishangyexiangtong.UseVisualStyleBackColor = true;
            // 
            // textBox_dancixunhuamiao1
            // 
            this.textBox_dancixunhuamiao1.Location = new System.Drawing.Point(90, 5);
            this.textBox_dancixunhuamiao1.Name = "textBox_dancixunhuamiao1";
            this.textBox_dancixunhuamiao1.Size = new System.Drawing.Size(23, 21);
            this.textBox_dancixunhuamiao1.TabIndex = 27;
            this.textBox_dancixunhuamiao1.Text = "2";
            // 
            // textBox_zongziduan
            // 
            this.textBox_zongziduan.Location = new System.Drawing.Point(200, 3);
            this.textBox_zongziduan.Name = "textBox_zongziduan";
            this.textBox_zongziduan.Size = new System.Drawing.Size(56, 21);
            this.textBox_zongziduan.TabIndex = 26;
            this.textBox_zongziduan.Text = "10";
            // 
            // textBox_tongziduan
            // 
            this.textBox_tongziduan.Location = new System.Drawing.Point(200, 25);
            this.textBox_tongziduan.Name = "textBox_tongziduan";
            this.textBox_tongziduan.Size = new System.Drawing.Size(56, 21);
            this.textBox_tongziduan.TabIndex = 25;
            this.textBox_tongziduan.Text = "2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(152, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 24;
            this.label8.Text = "同字段：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(152, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "总字段：";
            // 
            // chk_PauseContiune2
            // 
            this.chk_PauseContiune2.AutoSize = true;
            this.chk_PauseContiune2.Location = new System.Drawing.Point(17, 127);
            this.chk_PauseContiune2.Name = "chk_PauseContiune2";
            this.chk_PauseContiune2.Size = new System.Drawing.Size(186, 16);
            this.chk_PauseContiune2.TabIndex = 22;
            this.chk_PauseContiune2.Text = "暂停若干秒后继续下载 不重下";
            this.chk_PauseContiune2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 21;
            this.label4.Text = "暂停秒数：";
            // 
            // textBox_PauseSecond
            // 
            this.textBox_PauseSecond.Location = new System.Drawing.Point(89, 76);
            this.textBox_PauseSecond.Name = "textBox_PauseSecond";
            this.textBox_PauseSecond.Size = new System.Drawing.Size(56, 21);
            this.textBox_PauseSecond.TabIndex = 20;
            this.textBox_PauseSecond.Text = "2";
            // 
            // chk_PauseContiune
            // 
            this.chk_PauseContiune.AutoSize = true;
            this.chk_PauseContiune.Location = new System.Drawing.Point(17, 105);
            this.chk_PauseContiune.Name = "chk_PauseContiune";
            this.chk_PauseContiune.Size = new System.Drawing.Size(144, 16);
            this.chk_PauseContiune.TabIndex = 19;
            this.chk_PauseContiune.Text = "暂停若干秒后继续下载";
            this.chk_PauseContiune.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel7.Controls.Add(this.button1);
            this.panel7.Controls.Add(this.getName);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.textBox_delay);
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.TableName2);
            this.panel7.Controls.Add(this.TableName1);
            this.panel7.Location = new System.Drawing.Point(677, 385);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(200, 157);
            this.panel7.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(121, 121);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "刷新";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // getName
            // 
            this.getName.Location = new System.Drawing.Point(121, 99);
            this.getName.Name = "getName";
            this.getName.Size = new System.Drawing.Size(75, 23);
            this.getName.TabIndex = 6;
            this.getName.Text = "getName";
            this.getName.UseVisualStyleBackColor = true;
            this.getName.Click += new System.EventHandler(this.getName_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 5;
            this.label9.Text = "延时：";
            // 
            // textBox_delay
            // 
            this.textBox_delay.Location = new System.Drawing.Point(4, 121);
            this.textBox_delay.Name = "textBox_delay";
            this.textBox_delay.Size = new System.Drawing.Size(100, 21);
            this.textBox_delay.TabIndex = 4;
            this.textBox_delay.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "xml文件名2：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "xml文件名1：";
            // 
            // TableName2
            // 
            this.TableName2.Location = new System.Drawing.Point(3, 72);
            this.TableName2.Name = "TableName2";
            this.TableName2.Size = new System.Drawing.Size(193, 21);
            this.TableName2.TabIndex = 1;
            // 
            // TableName1
            // 
            this.TableName1.Location = new System.Drawing.Point(4, 27);
            this.TableName1.Name = "TableName1";
            this.TableName1.Size = new System.Drawing.Size(193, 21);
            this.TableName1.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel8.Location = new System.Drawing.Point(883, 386);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(229, 157);
            this.panel8.TabIndex = 21;
            // 
            // CrawlerDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1117, 548);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CrawlerDlg";
            this.Text = "Crawler";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button GetXML;
        private WTWebBrowser webBrowser1;
        private System.Windows.Forms.TextBox url_txt;
        private System.Windows.Forms.Label OutTimeLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_num;
        private System.Windows.Forms.TextBox textBox_url;
        private System.Windows.Forms.Button button_tool;
        private System.Windows.Forms.Button button_go;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_PauseNaviget;
        private System.Windows.Forms.CheckBox checkBox_display_prompt;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.CheckBox checkBox_display_prompt2;
        private System.Windows.Forms.CheckBox checkBox_display_prompt3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox checkBox_display_prompt4;
        private System.Windows.Forms.Button button_downloadnext;
        private System.Windows.Forms.Button button_redownload;
        private System.Windows.Forms.Button delete_tbl_btn;
        private System.Windows.Forms.Button sf_poc_btn;
        private System.Windows.Forms.Button download;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_dancixunhuamiao;
        private System.Windows.Forms.TextBox textBox_xunhuanlunshu;
        private System.Windows.Forms.CheckBox chb_zidongpanduanxiazaiwanbi;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button DownloadWithList_btn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_PauseSecond;
        private System.Windows.Forms.CheckBox chk_PauseContiune;
        private System.Windows.Forms.TextBox IfErrorPage_txt;
        private System.Windows.Forms.CheckBox chk_PauseContiune2;
        private System.Windows.Forms.Button closewindow_btn;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TableName2;
        private System.Windows.Forms.TextBox TableName1;
        private System.Windows.Forms.TextBox textBox_delay;
        private System.Windows.Forms.TextBox textBox_zongziduan;
        private System.Windows.Forms.TextBox textBox_tongziduan;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_dancixunhuamiao1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox_deletetable;
        private System.Windows.Forms.Button getName;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chb_jishishangyexiangtong;
        private System.Windows.Forms.Button DownFile_btn;
        private System.Windows.Forms.Button edb_poc_btn;
        private System.Windows.Forms.Label label10;
    }
}

