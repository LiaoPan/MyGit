﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crawler
{
    public partial class Crawler2 : Form
    {
        public Crawler2()
        {
            InitializeComponent();
        }


    }
}
