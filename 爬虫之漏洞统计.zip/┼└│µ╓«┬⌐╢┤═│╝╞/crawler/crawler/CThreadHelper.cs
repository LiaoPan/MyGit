﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crawler
{
    class CThreadHelper
    {
        public delegate void delegateTimeout(int timeout);
        public delegate void delegateTimeoutKill();
        public static void ThreadExe_Int(delegateTimeout dosomething, delegateTimeoutKill dosomethingkill, int timeout_dosomething, int timeout)
        {
            //Thread t = new Thread(new ThreadStart(dosomething));
            Thread t = new Thread(() => dosomething(timeout_dosomething));
            t.Start();
            Thread.Sleep(timeout);
            if (t.IsAlive == true)
            {
                t.Abort();
                dosomethingkill();
                StringHelper.MyMessagebox("线程超时", 1);
            }
            else
            {
                //MessageBox.Show("线程没有超时");
                StringHelper.MyMessagebox("线程没有超时", 4);
            }
        }

        //调用实例
        //CThreadHelper.ThreadExe_string(HtmlReader.ExtractSection_thread, DoSomethingKill, documentText, xmlrc.ls_sessionpath[i], 10);
        //List<string> ls_path_temp = VolOverAll.ls_path_temp;
        public delegate void delegateTimeout_string(string documentText, string body_str);
        public static void ThreadExe_string_ceshi(delegateTimeout_string dosomething, delegateTimeoutKill dosomethingkill, string documentText, string body_str, int timeout)
        {
            //Thread t = new Thread(new ThreadStart(dosomething));
            Thread t = new Thread(() => dosomething(documentText, body_str));
            t.Start();
            Thread.Sleep(timeout);
            if (t.IsAlive == true)
            {
                t.Abort();
                dosomethingkill();
            }
            else
            {
                //MessageBox.Show("线程没有超时");
                StringHelper.MyMessagebox("线程没有超时", 4);
            }
        }

        public static int ThreadExe_string(delegateTimeout_string dosomething, delegateTimeoutKill dosomethingkill, string documentText, string body_str, int timeout)
        {
            //Thread t = new Thread(new ThreadStart(dosomething));
            Thread t = new Thread(() => dosomething(documentText, body_str));
            t.Start();
            //Thread.Sleep(timeout);
            int timeout_count = 0;
            while (t.IsAlive == true && timeout_count < timeout * 1000)
            {
                Thread.Sleep(1);
                timeout_count++;
            }
            //MessageBox.Show(timeout_count.ToString());
            StringHelper.MyMessagebox(timeout_count.ToString(), 4);
            if (t.IsAlive == true)
            {
                t.Abort();
                dosomethingkill();
            }
            else
            {
                //MessageBox.Show("线程没有超时");
                StringHelper.MyMessagebox("线程没有超时", 4);
            }
            return timeout_count;
        }
    }
}
