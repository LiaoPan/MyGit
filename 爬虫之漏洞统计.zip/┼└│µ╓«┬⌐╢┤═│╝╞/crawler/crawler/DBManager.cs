﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

//using Microsoft.ApplicationBlocks.Data;

//using VulDownLoad2.Util;

namespace crawler
{
    public class DBManager
    {

        public static DataSet OpSQLWrite(string SQLSentence)
        {
            DataSet ds = new DataSet();

            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    //SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    com.ExecuteNonQuery();
                    
                    //SqlDataAdapter da = new SqlDataAdapter(com);
                    ////DataSet dscl = new DataSet();
                    //da.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("写入错误");
                StringHelper.MyMessagebox("OpSQLWrite 错误", 3);
                int a = 0;
            }
            finally
            {
                com.Dispose();
                con.Close();
            }

            return ds;
        }

        public static int OpSQLGetInt(string SQLSentence)
        {
            DataSet ds = new DataSet();
            int urlnum = -1;
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    
                    com.CommandType = CommandType.Text;
                    //string SQLSentence = "select count(*) from cvd_osvdb2";
                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    //com.ExecuteNonQuery();

                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    urlnum = dr.GetInt32(0);
                    //urlnum = dr.GetInt64(0);
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("OpSQLGetInt 错误");
                StringHelper.MyMessagebox("OpSQLGetInt 错误", 3);
            }
            finally
            {
                com.Dispose();
                con.Close();
            }

            return urlnum;
        }

        public static Double OpSQLGetInt64(string SQLSentence)
        {
            DataSet ds = new DataSet();
            Double urlnum = -1;
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    
                    com.CommandType = CommandType.Text;
                    //string SQLSentence = "select count(*) from cvd_osvdb2";
                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    //com.ExecuteNonQuery();

                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    urlnum = dr.GetInt64(0);
                    //urlnum = dr.GetInt64(0);
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("OpSQLGetInt64 错误");
                StringHelper.MyMessagebox("OpSQLGetInt64 错误", 3);
            }
            finally
            {
                com.Dispose();
                con.Close();
            }

            return urlnum;
        }

        public static string OpSQLGetString(string SQLSentence)
        {
            //List<Uri> urlIndex = new List<Uri>();
            string urlnum = "";
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dscl);
                    urlnum = (string)dscl.Tables[0].Rows[0][0];
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("OpSQLGetString 错误");
                StringHelper.MyMessagebox("OpSQLGetString 错误", 3);
            }
            finally
            {
                com.Dispose();
                con.Close();
            }

            return urlnum;
        }

        public static DataSet OpSQLGetTable(string SQLSentence)
        {
            //List<Uri> urlIndex = new List<Uri>();
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    if(da != null)
                        da.Fill(dscl);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("OpSQLGetTable 错误");
                StringHelper.MyMessagebox("OpSQLGetTable 错误", 3);
                DataTable dt = new DataTable();
                dscl.Tables.Add(dt);
            }
            finally
            {
                com.Dispose();
                con.Close();
            }

            return dscl;
        }

        public static bool OpSQLUpdate(string TableName, DataSet ds, bool IfBackup = false)
        {
            bool flag = false;
            string SQLSentence = "";
            OpSQLClearTable(TableName, IfBackup);
            DataTable dt = ds.Tables[0];
            int totalRows = dt.Rows.Count;
            int totalCol = dt.Columns.Count;

            string caption = "";
            caption = caption + dt.Columns[0].Caption;
            for(int i=1; i<totalCol; i++)
            {
                caption = caption + ", " + dt.Columns[i].Caption;
            }

            for (int i = 0; i < totalRows; i++)
            {
                string replace = dt.Rows[i][0].ToString();
                replace = replace.Replace("'", "''");
                string col = "'" + replace + "'";
                for (int j = 1; j < totalCol; j++)
                {
                    replace = dt.Rows[i][j].ToString();
                    replace = replace.Replace("'", "''");
                    col = col + ", '" + replace + "'";
                }
                SQLSentence = string.Format("insert into {0}({1}) values({2})", TableName, caption, col);
                OpSQLWrite(SQLSentence);
            }           

            return flag;
        }

        //public static bool OpSQLUpdate(string TableName, DataSet ds)
        //{
        //    DataSet dscl = new DataSet();
        //    SqlConnection con = new SqlConnection();
        //    SqlCommand com = new SqlCommand();
        //    bool flag = true;
        //    con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
        //    try
        //    {
        //        con.Open();
        //        if (con.State == ConnectionState.Open)
        //        {
        //            com.CommandType = CommandType.Text;
        //            //com.CommandText = SQLSentence;
        //            com.CommandText = string.Format("select * from {0}", TableName);
        //            com.Connection = con;

        //            SqlDataAdapter da = new SqlDataAdapter(com);
        //            da.Fill(ds);
        //            da.Update(ds.GetChanges());
        //            //if (da != null)
        //            //    da.Fill(dscl);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("OpSQLGetTable 错误");
        //        flag = false;
        //    }
        //    finally
        //    {
        //        com.Dispose();
        //        con.Close();
        //    }

        //    return flag;
        //}

        public static bool OpSQLIfExist(string Table_Content)
        {
            string SQLSentence = string.Format("select top 10 * from {0}", Table_Content);
            //List<Uri> urlIndex = new List<Uri>();
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            bool flag = false;
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    if (da != null)
                        da.Fill(dscl);
                }

                flag = true;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                com.Dispose();
                con.Close();                
            }
            return flag;
        }

        //将dt存放id列表，srctable筛选，添加到destable中
        public static void OpSQLInsertInto(DataTable dt, string DesTable, string SrcTable)
        {
            string SQLSentence = "";
            bool flag = OpSQLIfExist(DesTable);
            int total = dt.Rows.Count;
            if(flag == true)
            {
                for (int i = 0; i < total; i++)
                {
                    SQLSentence = string.Format("insert into {0} ", DesTable)
                        + string.Format(" select * from {0} where id = '{1}'", SrcTable, dt.Rows[i][0].ToString());
                    DBManager.OpSQLWrite(SQLSentence);
                }
            }
            else
            {
                SQLSentence = string.Format("select * into {0} from {1} where id = '###$$$'", DesTable, SrcTable);
                DBManager.OpSQLWrite(SQLSentence);
                for (int i = 0; i < total; i++)
                {
                    SQLSentence = string.Format("insert into {0} ", DesTable)
                        + string.Format(" select * from {0} where id = '{1}'", SrcTable, dt.Rows[i][0].ToString());
                    DBManager.OpSQLWrite(SQLSentence);
                }
            }
        }

        public static void OpSQLInsertInto_n(DataTable dt, List<string> ls_src, List<string> ls_des, int n, string Table)
        {
            string SQLSentence = "";
            string cols = "";
            for (int i = 0; i < ls_des.Count; i++)
            {
                if (cols != "")
                {
                    cols = cols + ", ";
                }
                cols = cols + ls_des[i].ToString();
            }

            int total = dt.Rows.Count;
            string str = "";
            for (int j = 0; j < total; j++)
            {
                Application.DoEvents();
                //VolOverAll.text_display = VolOverAll.text_display + 1;
                string content = "";
                for (int i = 0; i < ls_src.Count; i++)
                {
                    if (content != "")
                    {
                        content = content + ", ";
                    }
                    content = content + "'" + dt.Rows[j][ls_src[i]].ToString() + "'";
                }

                if (str != "")
                {
                    str = str + ", ";
                }
                str = str + "(" + content + ")";

                if (j % n == 0)
                {
                    SQLSentence = string.Format("insert into {0}({1}) values{2}", Table, cols, str);
                    DBManager.OpSQLWrite(SQLSentence);
                    str = "";
                }
            }

            if (str != "")
            {
                SQLSentence = string.Format("insert into {0}({1}) values{2}", Table, cols, str);
                DBManager.OpSQLWrite(SQLSentence);
            }
        }

        //更新数据库某个字段，dt为id列表
        public static void OpSQLUpdateField(string DesTable, string field_name, string field_content,DataTable dt = null)
        {
            string SQLSentence = "";
            bool flag = OpSQLIfExist(DesTable);

            if (dt == null)
            {
                if (flag == true)
                {
                    SQLSentence = string.Format("update {0} ", DesTable)
                        + string.Format(" set {0} = '{1}'", field_name, field_content);
                    DBManager.OpSQLWrite(SQLSentence);
                }
                else
                { }
            }
            else
            {
                int total = dt.Rows.Count;
                if (flag == true)
                {
                    for (int i = 0; i < total; i++)
                    {
                        SQLSentence = string.Format("update {0} ", DesTable)
                            + string.Format(" set {0} = '{1}' where id = '{2}'", field_name, field_content, dt.Rows[i][0].ToString());
                        DBManager.OpSQLWrite(SQLSentence);
                    }
                }
                else
                { }
            }
        }

        public static void OpSQLDelete(string DesTable, DataTable dt, string field = "")
        {
            string SQLSentence = "";
            bool flag = OpSQLIfExist(DesTable);
            string str_and = "and";
            if (field == "")
                str_and = "";

            int total = dt.Rows.Count;
            if (flag == true)
            {
                for (int i = 0; i < total; i++)
                {
                    SQLSentence = string.Format("delete {0} ", DesTable)
                        + string.Format(" where id = '{0}' {1} {2}", dt.Rows[i][0].ToString(), str_and, field);
                    DBManager.OpSQLWrite(SQLSentence);
                }
            }
            else
            { }
        }

        public static void OpSQLBackupMyNow(string TableName)
        {
            string TableName2 = TableName + "_" + StringHelper.MyNow();
            string SQLSentence = string.Format("select * into [{0}] from {1}",TableName2,TableName);
            OpSQLWrite(SQLSentence);
        }

        //删除后重新新建
        public static void OpSQLCreateTable_Delete(string TableName, string str_col)
        {
            bool flag = false;
            string SQLSentence = "";
            flag = OpSQLIfExist(TableName);
            if (flag == true)
            {
                SQLSentence = string.Format("drop table {0}", TableName);
                OpSQLWrite(SQLSentence);
            }

            SQLSentence = string.Format("create table {0} ({1})", TableName, str_col);
            OpSQLWrite(SQLSentence);
        }

        //删除原表，以指定表的形式新建
        public static void OpSQLCreateTable_Delete_Src(string TableName, string SrcTable)
        {
            bool flag = false;
            string SQLSentence = "";
            flag = OpSQLIfExist(TableName);
            if (flag == true)
            {
                SQLSentence = string.Format("drop table {0}", TableName);
                OpSQLWrite(SQLSentence);
            }

            SQLSentence = string.Format("select top 1 * into {0} from {1}", TableName, SrcTable);
            OpSQLWrite(SQLSentence);
            SQLSentence = string.Format("delete from {0}", TableName);
            OpSQLWrite(SQLSentence);
        }

        //如果不存在则新建
        public static void OpSQLCreateTable(string TableName, string str_col, string flag_clear = "")
        {
            bool flag = false;
            string SQLSentence = "";
            flag = OpSQLIfExist(TableName);
            if (flag == false)
            {
                SQLSentence = string.Format("create table {0} ({1})", TableName, str_col);
                OpSQLWrite(SQLSentence);
            }
            else
            {
                if (flag_clear == "clear")
                {
                    SQLSentence = string.Format("delete from {0}", TableName);
                    DBManager.OpSQLWrite(SQLSentence);
                }
            }
        }

        //保存后，删除原有数据，flag_clear == "clear" 则删除，否则不删除
        public static void OpSQLCreateTable_AfterSave(string Table_Content, string str_names_lengh, string flag_clear = "")
        {
            string SQLSentence = "";
            bool flag = DBManager.OpSQLIfExist(Table_Content);
            if (flag == false)
            {
                SQLSentence = string.Format("create table {0}({1})", Table_Content, str_names_lengh);
                DBManager.OpSQLWrite(SQLSentence);
            }
            else
            {
                SQLSentence = string.Format("select * into [{0}_{1}] from {0}", Table_Content, StringHelper.MyNow());
                DBManager.OpSQLWrite(SQLSentence);
                if (flag_clear == "clear")
                {
                    SQLSentence = string.Format("delete from {0}", Table_Content);
                    DBManager.OpSQLWrite(SQLSentence);
                }
            }
        }

        public static bool OpSQLClearTable_must(string TableName, bool IfBackup = false)
        {
            bool flag = false;
            string SQLSentence = "";
            while (flag == false)
            {
                flag = DBManager.OpSQLIfExist(TableName);
                if (flag == false)
                {
                    //MessageBox.Show("表 {0} 不存在", TableName);
                    string str_temp = string.Format("表 {0} 不存在", TableName);
                    StringHelper.MyMessagebox(str_temp, 3);
                }
                else
                {
                    if (IfBackup == true)
                    {
                        SQLSentence = string.Format("select * into [{0}_{1}] from {0}", TableName, StringHelper.MyNow());
                        DBManager.OpSQLWrite(SQLSentence);
                    }
                    SQLSentence = string.Format("delete from {0}", TableName);
                    DBManager.OpSQLWrite(SQLSentence);
                    flag = true;
                }
            }
            return flag;
        }

        public static bool OpSQLClearTable(string TableName, bool IfBackup = false)
        {
            bool flag = false;
            string SQLSentence = "";

            flag = DBManager.OpSQLIfExist(TableName);
            if (flag == false)
            {
                //MessageBox.Show("表 {0} 不存在", TableName);
                string str_temp = string.Format("表 {0} 不存在", TableName);
                StringHelper.MyMessagebox(str_temp, 3);
            }
            else
            {
                if (IfBackup == true)
                {
                    SQLSentence = string.Format("select * into [{0}_{1}] from {0}", TableName, StringHelper.MyNow());
                    DBManager.OpSQLWrite(SQLSentence);
                }
                SQLSentence = string.Format("delete from {0}", TableName);
                DBManager.OpSQLWrite(SQLSentence);
                flag = true;
            }
            return flag;
        }

        public static void OpSQLSaveTable(string Table_Content)
        {
            if(OpSQLIfExist(Table_Content))
            {
                string SQLSentence = "";
                SQLSentence = string.Format("select * into [{0}_{1}] from {0}", Table_Content, StringHelper.MyNow());
                DBManager.OpSQLWrite(SQLSentence);
            }
        }
    }
}
