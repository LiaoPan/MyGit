﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crawler
{
    public partial class GetNameDlg : Form
    {
        public GetNameDlg()
        {
            InitializeComponent();

            List<CheckBox> ls_chb = new List<CheckBox>();
            checkedListBox1.Items.Clear();
            List<string> ls_filename = getDirFile(VolOverAll.datacode);
            for (int i = 0; i < ls_filename.Count; i++)
            {
                checkedListBox1.Items.Add(ls_filename[i]);
            }
        }

        public List<string> getDirFile(string path)
        {
            DirectoryInfo parentdi = new DirectoryInfo(path);
            FileInfo[] files = parentdi.GetFiles();
            List<string> ls_filename = new List<string>();
            for (int i = 0; i < files.Length; i++)//访问当前目录的文件
            {
                ls_filename.Add(files[i].Name);
            }
            return ls_filename;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<string> ls_filename = getDirFile(VolOverAll.datacode);
            List<string> ls_filename_chk = new List<string>();
            for (int i = 0; i < ls_filename.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i))
                {
                    ls_filename_chk.Add(checkedListBox1.GetItemText(checkedListBox1.Items[i]));
                }
            }

            VolOverAll.ls_filename_chk = ls_filename_chk;
        }
    }
}
