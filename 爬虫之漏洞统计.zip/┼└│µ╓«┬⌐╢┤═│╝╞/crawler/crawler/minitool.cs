﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crawler
{
    public partial class minitool : Form
    {
        public minitool()
        {
            InitializeComponent();
        }

        private void button_getstring_Click(object sender, EventArgs e)
        {
            GetHtmlString ghs = new GetHtmlString();
            ghs.Show();
        }

        private void button_getxpath_Click(object sender, EventArgs e)
        {
            //string path = VolOverAll.datacode + "01.xml";
            //DataTable dt = CXmlToDatatable.CXmlToDataTable("d://dataset//01.html");

        }
    }
}
