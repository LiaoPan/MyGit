﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HtmlAgilityPack;
using System.Xml.XPath;
using System.IO;

namespace crawler
{
    public class HtmlReader
    {
        //从字符串中提取字段
        public static List<string> ExtractSection(string documentText, string body_str)
        {
            HtmlAgilityPack.HtmlDocument document = GetHtmlDocument(documentText);
            List<string> ls = new List<string>();
            LinkedList<HtmlNode> bodyNodes = null;
            bodyNodes = GetBodyNodes(document, body_str);
            foreach (HtmlNode node in bodyNodes)
            {
                //string nodeText = HttpUtility.HtmlDecode(node.InnerText);
                try
                {
                    string nodeText = node.InnerText;
                    ls.Add(nodeText);
                }
                catch (Exception ex)
                { }
            }
            return ls;
        }

        public static void ExtractSection_thread(string documentText, string body_str)
        {
            HtmlAgilityPack.HtmlDocument document = GetHtmlDocument(documentText);
            List<string> ls = new List<string>();
            LinkedList<HtmlNode> bodyNodes = null;
            bodyNodes = GetBodyNodes(document, body_str);
            foreach (HtmlNode node in bodyNodes)
            {
                //string nodeText = HttpUtility.HtmlDecode(node.InnerText);
                try
                {
                    string nodeText = node.InnerText;
                    ls.Add(nodeText);
                }
                catch (Exception ex)
                { }
            }
            VolOverAll.ls_path_temp = ls;
        }

        public static void ExtractSection_kill()
        {
            List<string> ls = new List<string>();
            ls.Add("");
            VolOverAll.ls_path_temp = ls;
        }

        public static XPathExpression _body;

        public static HtmlAgilityPack.HtmlDocument GetHtmlDocument(string documentText)
        {
            HtmlAgilityPack.HtmlDocument document = new HtmlAgilityPack.HtmlDocument();

            document.OptionFixNestedTags = true;
            try
            {
                document.Load(new StringReader(documentText));
            }
            catch (Exception e)
            {
                document.Load(new StringReader(""));
            }

            return document;
        }

        private static LinkedList<HtmlNode> GetBodyNodes(HtmlAgilityPack.HtmlDocument document, string body_str)
        {
            LinkedList<HtmlNode> bodyNodes = new LinkedList<HtmlNode>();
            _body = XPathExpression.Compile(body_str);
            XPathNavigator nav = document.CreateNavigator();

            XPathNodeIterator iterator;
            try
            {
                iterator = nav.Select(_body);

                foreach (HtmlNodeNavigator tempNav in iterator)
                {
                    if (tempNav.NodeType == XPathNodeType.Attribute)
                    {
                        string attribValue = tempNav.Value;
                        HtmlNode attribNode = HtmlNode.CreateNode(attribValue);
                        bodyNodes.AddLast(attribNode);
                    }
                    else
                        bodyNodes.AddLast(tempNav.CurrentNode);
                }

                return bodyNodes;
            }
            catch (Exception ex)
            {
                return bodyNodes;
            }
        }
    }
}
