﻿using System;
using System.Data;
using System.Configuration;


/// <summary>
///BookMarks 的摘要说明
/// </summary>
public class BookMarks
{
    //日期书签
    public static string StartYear = "StartYear";
    public static string StartMonth = "StartMonth";
    public static string StartDay = "StartDay";
    public static string EndYear = "EndYear";
    public static string EndMonth = "EndMonth";
    public static string EndDay = "EndDay";
    public static string ReportYear = "ReportYear";
    public static string ReportMonth = "ReportMonth";
    public static string ReportDay = "ReportDay";

    //漏洞情况摘要书签
    public static string TotalNum = "TotalNum";
    public static string HighNum = "HighNum";
    public static string MiddleNum = "MiddleNum";
    public static string LowNum = "LowNum";
    public static string TotalNumLast = "TotalNumLast";
    public static string HighNumLast = "HighNumLast";
    public static string MiddleNumLast = "MiddleNumLast";
    public static string LowNumLast = "LowNumLast";
    public static string Atention = "Atention";
    public static string TotalNum_2 = "TotalNum_2";
    public static string HighNum_2 = "HighNum_2";


    //漏洞列表书签
    public static string[] volname = { "volname1", "volname2", "volname3", "volname4", "volname5", "volname6", "volname7", "volname8", "volname9", "volname10" };
    public static string[] cve = { "cve1", "cve2", "cve3", "cve4", "cve5", "cve6", "cve7", "cve8", "cve9", "cve10" };
    public static string[] volclass = { "volclass1", "volclass2", "volclass3", "volclass4", "volclass5", "volclass6", "volclass7", "volclass8", "volclass9", "volclass10" };
    public static string[] severity_cve = { "severity_cve1", "severity_cve2", "severity_cve3", "severity_cve4", "severity_cve5", "severity_cve6", "severity_cve7", "severity_cve8", "severity_cve9", "severity_cve10" };
    public static string[] volcause = { "volcause1", "volcause2", "volcause3", "volcause4", "volcause5", "volcause6", "volcause7", "volcause8", "volcause9", "volcause10" };
    public static string[] impact = { "impact1", "impact2", "impact3", "impact4", "impact5", "impact6", "impact7", "impact8", "impact9", "impact10" };
    public static string[] volref = { "volref1", "volref2", "volref3", "volref4", "volref5", "volref6", "volref7", "volref8", "volref9", "volref10" };
    public static string[] volname_2 = { "volname_2_1", "volname_2_2", "volname_2_3", "volname_2_4", "volname_2_5", "volname_2_6", "volname_2_7", "volname_2_8", "volname_2_9", "volname_2_10" };
    public static string[] affact = { "affact1", "affact2", "affact3", "affact4", "affact5", "affact6", "affact7", "affact8", "affact9", "affact10" };
    public static string[] translations = { "translations1", "translations2", "translations3", "translations4", "translations5", "translations6", "translations7", "translations8", "translations9", "translations10" };
}
