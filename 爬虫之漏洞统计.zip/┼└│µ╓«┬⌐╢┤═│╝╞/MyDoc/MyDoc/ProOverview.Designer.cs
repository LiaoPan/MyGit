﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

using System.IO;
using System.Data.SqlClient;

//using WeifenLuo.WinFormsUI.Docking;
using System.Web;
using System.Configuration;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.HttpContext;

namespace MyDoc
{
    partial class ProOverview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.overview = new System.Windows.Forms.TextBox();
            this.pro = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtSentence = new System.Windows.Forms.TextBox();
            this.txtVendor = new System.Windows.Forms.TextBox();
            this.txtVersion = new System.Windows.Forms.TextBox();
            this.txtBecause = new System.Windows.Forms.TextBox();
            this.txtCause = new System.Windows.Forms.TextBox();
            this.txtAllow = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtVia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtVul = new System.Windows.Forms.TextBox();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.note = new System.Windows.Forms.Label();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.phraseBtn = new System.Windows.Forms.Button();
            this.AddPhraseBtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtFinal = new System.Windows.Forms.TextBox();
            this.CreateFinalBtn = new System.Windows.Forms.Button();
            this.AddVol = new System.Windows.Forms.Button();
            this.success_final_btn = new System.Windows.Forms.Button();
            this.txtTital = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // overview
            // 
            this.overview.Location = new System.Drawing.Point(78, 12);
            this.overview.Multiline = true;
            this.overview.Name = "overview";
            this.overview.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.overview.Size = new System.Drawing.Size(1204, 150);
            this.overview.TabIndex = 0;
            // 
            // pro
            // 
            this.pro.Location = new System.Drawing.Point(838, 174);
            this.pro.Name = "pro";
            this.pro.Size = new System.Drawing.Size(75, 23);
            this.pro.TabIndex = 1;
            this.pro.Text = "处理";
            this.pro.UseVisualStyleBackColor = true;
            this.pro.Click += new System.EventHandler(this.pro_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(1005, 174);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(277, 199);
            this.dataGridView2.TabIndex = 4;
            // 
            // txtSentence
            // 
            this.txtSentence.Location = new System.Drawing.Point(12, 168);
            this.txtSentence.Multiline = true;
            this.txtSentence.Name = "txtSentence";
            this.txtSentence.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSentence.Size = new System.Drawing.Size(414, 356);
            this.txtSentence.TabIndex = 5;
            // 
            // txtVendor
            // 
            this.txtVendor.Location = new System.Drawing.Point(432, 250);
            this.txtVendor.Multiline = true;
            this.txtVendor.Name = "txtVendor";
            this.txtVendor.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtVendor.Size = new System.Drawing.Size(405, 43);
            this.txtVendor.TabIndex = 6;
            // 
            // txtVersion
            // 
            this.txtVersion.Location = new System.Drawing.Point(432, 359);
            this.txtVersion.Multiline = true;
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtVersion.Size = new System.Drawing.Size(405, 99);
            this.txtVersion.TabIndex = 7;
            // 
            // txtBecause
            // 
            this.txtBecause.Location = new System.Drawing.Point(433, 476);
            this.txtBecause.Multiline = true;
            this.txtBecause.Name = "txtBecause";
            this.txtBecause.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtBecause.Size = new System.Drawing.Size(405, 48);
            this.txtBecause.TabIndex = 8;
            // 
            // txtCause
            // 
            this.txtCause.Location = new System.Drawing.Point(432, 550);
            this.txtCause.Multiline = true;
            this.txtCause.Name = "txtCause";
            this.txtCause.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtCause.Size = new System.Drawing.Size(405, 61);
            this.txtCause.TabIndex = 9;
            // 
            // txtAllow
            // 
            this.txtAllow.Location = new System.Drawing.Point(12, 550);
            this.txtAllow.Multiline = true;
            this.txtAllow.Name = "txtAllow";
            this.txtAllow.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAllow.Size = new System.Drawing.Size(414, 61);
            this.txtAllow.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(432, 235);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "2 vendor：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(432, 344);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 12;
            this.label2.Text = "4 version：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(432, 461);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "5 because：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(433, 535);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 14;
            this.label4.Text = "7 cause：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 535);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "6 allow：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 614);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 19;
            this.label6.Text = "8 via：";
            // 
            // txtVia
            // 
            this.txtVia.Location = new System.Drawing.Point(14, 629);
            this.txtVia.Multiline = true;
            this.txtVia.Name = "txtVia";
            this.txtVia.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtVia.Size = new System.Drawing.Size(412, 109);
            this.txtVia.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(431, 296);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 21;
            this.label7.Text = "3 desc：";
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(432, 311);
            this.txtDesc.Multiline = true;
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDesc.Size = new System.Drawing.Size(405, 30);
            this.txtDesc.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(432, 174);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 23;
            this.label8.Text = "1 vul：";
            // 
            // txtVul
            // 
            this.txtVul.Location = new System.Drawing.Point(432, 189);
            this.txtVul.Multiline = true;
            this.txtVul.Name = "txtVul";
            this.txtVul.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtVul.Size = new System.Drawing.Size(405, 43);
            this.txtVul.TabIndex = 22;
            // 
            // ClearBtn
            // 
            this.ClearBtn.Location = new System.Drawing.Point(838, 232);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(37, 23);
            this.ClearBtn.TabIndex = 24;
            this.ClearBtn.Text = "清空";
            this.ClearBtn.UseVisualStyleBackColor = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(838, 203);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "分段处理";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // note
            // 
            this.note.AutoSize = true;
            this.note.Location = new System.Drawing.Point(433, 614);
            this.note.Name = "note";
            this.note.Size = new System.Drawing.Size(53, 12);
            this.note.TabIndex = 27;
            this.note.Text = "9 note：";
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(432, 629);
            this.txtNote.Multiline = true;
            this.txtNote.Name = "txtNote";
            this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtNote.Size = new System.Drawing.Size(405, 109);
            this.txtNote.TabIndex = 26;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(839, 262);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 28;
            this.button3.Text = "处理介词";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // phraseBtn
            // 
            this.phraseBtn.Location = new System.Drawing.Point(839, 292);
            this.phraseBtn.Name = "phraseBtn";
            this.phraseBtn.Size = new System.Drawing.Size(75, 23);
            this.phraseBtn.TabIndex = 29;
            this.phraseBtn.Text = "词组替换";
            this.phraseBtn.UseVisualStyleBackColor = true;
            this.phraseBtn.Click += new System.EventHandler(this.phraseBtn_Click);
            // 
            // AddPhraseBtn
            // 
            this.AddPhraseBtn.Location = new System.Drawing.Point(839, 321);
            this.AddPhraseBtn.Name = "AddPhraseBtn";
            this.AddPhraseBtn.Size = new System.Drawing.Size(74, 23);
            this.AddPhraseBtn.TabIndex = 30;
            this.AddPhraseBtn.Text = "添加词组";
            this.AddPhraseBtn.UseVisualStyleBackColor = true;
            this.AddPhraseBtn.Click += new System.EventHandler(this.AddPhraseBtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 39;
            this.label9.Text = "9 note：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 12);
            this.label10.TabIndex = 38;
            this.label10.Text = "1 vul：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(0, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 37;
            this.label11.Text = "3 desc：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 12);
            this.label12.TabIndex = 36;
            this.label12.Text = "8 via：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1, 75);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 12);
            this.label13.TabIndex = 35;
            this.label13.Text = "6 allow：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 34;
            this.label14.Text = "7 cause：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1, 63);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 33;
            this.label15.Text = "5 because：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 12);
            this.label16.TabIndex = 32;
            this.label16.Text = "4 version：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(0, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 31;
            this.label17.Text = "2 vendor：";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(846, 379);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(436, 63);
            this.textBox1.TabIndex = 40;
            // 
            // txtFinal
            // 
            this.txtFinal.Location = new System.Drawing.Point(846, 519);
            this.txtFinal.Multiline = true;
            this.txtFinal.Name = "txtFinal";
            this.txtFinal.Size = new System.Drawing.Size(436, 212);
            this.txtFinal.TabIndex = 41;
            // 
            // CreateFinalBtn
            // 
            this.CreateFinalBtn.Location = new System.Drawing.Point(875, 232);
            this.CreateFinalBtn.Name = "CreateFinalBtn";
            this.CreateFinalBtn.Size = new System.Drawing.Size(38, 23);
            this.CreateFinalBtn.TabIndex = 42;
            this.CreateFinalBtn.Text = "生成";
            this.CreateFinalBtn.UseVisualStyleBackColor = true;
            this.CreateFinalBtn.Click += new System.EventHandler(this.CreateFinalBtn_Click);
            // 
            // AddVol
            // 
            this.AddVol.Location = new System.Drawing.Point(838, 350);
            this.AddVol.Name = "AddVol";
            this.AddVol.Size = new System.Drawing.Size(75, 23);
            this.AddVol.TabIndex = 43;
            this.AddVol.Text = "添加单词";
            this.AddVol.UseVisualStyleBackColor = true;
            this.AddVol.Click += new System.EventHandler(this.AddVol_Click);
            // 
            // success_final_btn
            // 
            this.success_final_btn.Location = new System.Drawing.Point(920, 174);
            this.success_final_btn.Name = "success_final_btn";
            this.success_final_btn.Size = new System.Drawing.Size(75, 23);
            this.success_final_btn.TabIndex = 44;
            this.success_final_btn.Text = "生成最终";
            this.success_final_btn.UseVisualStyleBackColor = true;
            this.success_final_btn.Click += new System.EventHandler(this.success_final_btn_Click);
            // 
            // txtTital
            // 
            this.txtTital.Location = new System.Drawing.Point(844, 448);
            this.txtTital.Multiline = true;
            this.txtTital.Name = "txtTital";
            this.txtTital.Size = new System.Drawing.Size(436, 65);
            this.txtTital.TabIndex = 45;
            // 
            // ProOverview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1294, 743);
            this.Controls.Add(this.txtTital);
            this.Controls.Add(this.success_final_btn);
            this.Controls.Add(this.AddVol);
            this.Controls.Add(this.CreateFinalBtn);
            this.Controls.Add(this.txtFinal);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.AddPhraseBtn);
            this.Controls.Add(this.phraseBtn);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.note);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtVul);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtVia);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAllow);
            this.Controls.Add(this.txtCause);
            this.Controls.Add(this.txtBecause);
            this.Controls.Add(this.txtVersion);
            this.Controls.Add(this.txtVendor);
            this.Controls.Add(this.txtSentence);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.pro);
            this.Controls.Add(this.overview);
            this.Name = "ProOverview";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProOverview";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox overview;
        private System.Windows.Forms.Button pro;
        private DataGridView dataGridView2;
        private System.Windows.Forms.TextBox txtSentence;
        private System.Windows.Forms.TextBox txtVendor;
        private System.Windows.Forms.TextBox txtVersion;
        private System.Windows.Forms.TextBox txtBecause;
        private System.Windows.Forms.TextBox txtCause;
        private System.Windows.Forms.TextBox txtAllow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtVia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtVul;
        private System.Windows.Forms.Button ClearBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label note;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button phraseBtn;
        private System.Windows.Forms.Button AddPhraseBtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtFinal;
        private System.Windows.Forms.Button CreateFinalBtn;
        private System.Windows.Forms.Button AddVol;
        private Button success_final_btn;
        private TextBox txtTital;
    }
}