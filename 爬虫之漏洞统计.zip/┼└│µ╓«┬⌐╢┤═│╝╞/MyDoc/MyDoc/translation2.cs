﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MyDoc
{
    public partial class translation2 : Form
    {
        public translation2()
        {
            InitializeComponent();
            MyRefresh();
        }

        public void MyRefresh()
        {
            if (DBManager.GridRow < DBManager.ds1.Tables[0].Rows.Count)
            {
                textCVE.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["cve"];
                textCVE.Refresh();
                textOverView.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["OverView"];
                textOverView.Refresh();
                textImpact.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["Impact_Type"];
                textImpact.Refresh();
                textAffect.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["affect"];
                textAffect.Refresh();
                textclass.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["volclass"];
                textclass.Refresh();
                textcause.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["volcause"];
                textcause.Refresh();
                textTrans2.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["translations"];
                textTrans2.Refresh();
                textRank.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["rank"];
                textRank.Refresh();
                textTital.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow]["volname"];
                textTital.Refresh();
            }
            else
            {
                MessageBox.Show("已经是最后一行");
            }
        }

        public void MySave()
        {
            if (DBManager.flagtods != 1)
            {
                MessageBox.Show("没有选中");
                return;
            }
            //if (textName.Text == "" || textImpact.Text == "" || texttrans.Text == "")
            if (textName.Text == "" || texttrans.Text == "")
            {
                MessageBox.Show("存在空值");
                return;
            }

            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][36] = textName.Text;
            //DBManager.ds1.Tables[0].Rows[DBManager.GridRow][28] = textImpact.Text;
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][28] = GetImpact();
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][27] = texttrans.Text;
            WriteIn();
            lab_Message.Text = VolOverAll.strMessage;
            lab_Message.Refresh();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            MySave();
        }

        public string GetImpact()
        {
            string renyi = "任意代码执行";
            string xinxi = "信息泄露";
            string quanxian = "权限提升";
            string jujue = "拒绝服务";
            string weizhistr = "未知";

            string ret = "";
            bool flag = false;
            if (renyidaimazhixing.Checked == true)
            {
                ret = ret + renyi;
                flag = true;
            }
            if (xinxixielu.Checked == true)
            {
                if (flag == true)
                    ret = ret + ", ";
                ret = ret + xinxi;
            }
            if (quanxiantisheng.Checked == true)
            {
                if (flag == true)
                    ret = ret + ", ";
                ret = ret + quanxian;
            }
            if (jujuefuwu.Checked == true)
            {
                if (flag == true)
                    ret = ret + ", ";
                ret = ret + jujue;
            }
            if (weizhi.Checked == true)
            {
                if (flag == true)
                    return ret;
                ret = ret + weizhistr;
            }

            return ret;

        }

        public void WriteIn()
        {
            //MessageBox.Show("1");
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = "select * from NVD2";
                    com.Connection = con;

                    //MessageBox.Show("2");
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    //MessageBox.Show("3");
                    //string str = ds.Tables[0].TableName;

                    //ds.Tables[0].Rows[0][1] = "aaa";
                    DataTable dtShow = new DataTable();
                    //dtShow = (DataTable)dataGridView1.DataSource;
                    dtShow = DBManager.ds1.Tables[0];
                    for (int k = 0; k < dtShow.Rows.Count; k++)
                    {
                        string str1 = (string)dtShow.Rows[k][4];
                        string str2 = (string)dtShow.Rows[k][8];
                        //dtShow.Rows[k][27] = str1 + "--" + str2;

                        string str3 = (string)dtShow.Rows[k][14];
                        //dtShow.Rows[k][28] = str1 + "--" + str3;
                    }
                    //MessageBox.Show("4");
                    ds.Tables[0].Rows.Clear();
                    for (int i = 0; i < dtShow.Rows.Count; i++)
                    {
                        ds.Tables[0].ImportRow(dtShow.Rows[i]);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Update(ds);
                    //MessageBox.Show("保存完成");
                    VolOverAll.strMessage = "保持完成";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("写入失败");
            }
            finally
            {
                con.Close();
            }
        }

        private void Previous_Click(object sender, EventArgs e)
        {
            lab_Message.Text = "消息:";
            lab_Message.Refresh();
            DBManager.GridRow = DBManager.GridRow - 1;
            MyRefresh();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            lab_Message.Text = "消息:";
            lab_Message.Refresh();
            DBManager.GridRow = DBManager.GridRow + 1;
            MyRefresh();
        }

        private void trans_Btn_Click(object sender, EventArgs e)
        {
            texttrans.Text = "";
            textName.Text = "";
            lab_Message.Text = "翻译中";
            VolOverAll.strOverview = textOverView.Text;
            VolOverAll.strCause = textcause.Text;

            ProOverview po = new ProOverview();
            VolOverAll.strOverview = textOverView.Text;
            VolOverAll.strTrans = "";
            VolOverAll.strTital = "";
            po.Show();
        }

        private void refresh_btn_Click(object sender, EventArgs e)
        {
            texttrans.Text = VolOverAll.strTrans;
            textName.Text = VolOverAll.strTital;

            renyidaimazhixing.Checked = false;
            quanxiantisheng.Checked = false;
            xinxixielu.Checked = false;
            jujuefuwu.Checked = false;
            weizhi.Checked = false;

            //******************************************* 任意代码执行
            if (texttrans.Text.Contains("任意代码"))
            {
                renyidaimazhixing.Checked = true;
            }
            if (texttrans.Text.Contains("执行任意"))
            {
                renyidaimazhixing.Checked = true;
            }
            if (texttrans.Text.Contains("任意代码"))
            {
                renyidaimazhixing.Checked = true;
            }
            if (texttrans.Text.Contains("完整性"))
            {
                renyidaimazhixing.Checked = true;
            }
            //******************************************* 权限提升
            if (texttrans.Text.Contains("绕过认证"))
            {
                quanxiantisheng.Checked = true;
            }
            if (texttrans.Text.Contains("获取管理员特权"))
            {
                quanxiantisheng.Checked = true;
            }
            if (texttrans.Text.Contains("获得特权"))
            {
                quanxiantisheng.Checked = true;
            }
            if (texttrans.Text.Contains("绕过"))
            {
                quanxiantisheng.Checked = true;
            }
            if (texttrans.Text.Contains("获取访问权限"))
            {
                quanxiantisheng.Checked = true;
            }
            if (texttrans.Text.Contains("删除任意"))
            {
                quanxiantisheng.Checked = true;
            }
            if (texttrans.Text.Contains("完整性"))
            {
                quanxiantisheng.Checked = true;
            }
            //******************************************* 信息泄露
            if (texttrans.Text.Contains("信息泄露"))
            {
                xinxixielu.Checked = true;
            }
            if (texttrans.Text.Contains("信息泄露"))
            {
                xinxixielu.Checked = true;
            }
            if (texttrans.Text.Contains("信息泄露"))
            {
                xinxixielu.Checked = true;
            }
            if (texttrans.Text.Contains("机密性"))
            {
                xinxixielu.Checked = true;
            }
            if (texttrans.Text.Contains("读任意文件"))
            {
                xinxixielu.Checked = true;
            }
            //******************************************* 拒绝服务
            if (texttrans.Text.Contains("拒绝服务"))
            {
                jujuefuwu.Checked = true;
            }
            if (texttrans.Text.Contains("拒绝服务"))
            {
                jujuefuwu.Checked = true;
            }
            if (texttrans.Text.Contains("拒绝服务"))
            {
                jujuefuwu.Checked = true;
            }
            if (texttrans.Text.Contains("可用性"))
            {
                jujuefuwu.Checked = true;
            }
            //******************************************* 未知
            if (texttrans.Text.Contains("未知的影响"))
            {
                weizhi.Checked = true;
            }
            if (texttrans.Text.Contains("aa"))
            {
                weizhi.Checked = true;
            }
            if (texttrans.Text.Contains("aa"))
            {
                weizhi.Checked = true;
            }

            texttrans.Refresh();
            textName.Refresh();

            MySave();
        }


    }
}
