﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;

namespace MyDoc
{
    class DataSubmit
    {
        //日期书签
        public int StartYear = 0;
        public int StartMonth = 0;
        public int StartDay = 0;
        public int EndYear = 0;
        public int EndMonth = 0;
        public int EndDay = 0;
        public int ReportYear = 0;
        public int ReportMonth = 0;
        public int ReportDay = 0;

        public string StatStartYear = "";
        public string StatStartMonth = "";
        public string StatStartDate = "";
        public string StatEndYear = "";
        public string StatEndMonth = "";
        public string StatEndDate = "";

        //漏洞情况摘要书签
        public string TotalNum = "TotalNum";
        public string HighNum = "HighNum";
        public string SevereNum = "SevereNum";
        public string SevereHighNum = "SevereHighNum";
        public string MiddleNum = "MiddleNum";
        public string LowNum = "LowNum";

        public string TotalNumLast = "TotalNumLast";
        public string HighNumLast = "HighNumLast";
        public string SevereNumLast = "SevereNumLast";
        public string MiddleNumLast = "MiddleNumLast";
        public string LowNumLast = "LowNumLast";

        public string SevereLast2 = "";
        public string HighLast2 = "";
        
        public string HighPercent = "HighPercent";
        public int TotalDiffer = 0;
        public string TotalDifferStr = "";

        public string NetWorkNum = "NetWorkNum";
        public string AdjectionNum = "AdjectionNum";
        public string LocalNum = "LocalNum";

        //public string Content = "Content";
        public string Summary = "Summary";
        public string Atention = "Atention";
        public string NameAtention = "NameAtention";
        public string MSSummary = "MSSummary";
        public string MSAtention = "MSAtention";
        public int period = 30;

        //漏洞列表书签
        public string[] volname = { "", "", "", "", "", "", "", "", "", "" };
        public string[] cve = { "", "", "", "", "", "", "", "", "", "" };
        public string[] volclass = { "", "", "", "", "", "", "", "", "", "" };
        public string[] severity_cve = { "", "", "", "", "", "", "", "", "", "" };
        public string[] volcause = { "", "", "", "", "", "", "", "", "", "" };
        public string[] impact = { "", "", "", "", "", "", "", "", "", "" };
        public string[] volref = { "", "", "", "", "", "", "", "", "", "" };
        //public string[] volname_2 = { "", "", "", "", "", "", "", "", "", "" };
        public string[] affact = { "", "", "", "", "", "", "", "", "", "" };
        public string[] translations = { "", "", "", "", "", "", "", "", "", "" };
        public string[] Original_release_date = { "", "", "", "", "", "", "", "", "", "" };

        //表内容
        public string Content = "Content";

    }
}
