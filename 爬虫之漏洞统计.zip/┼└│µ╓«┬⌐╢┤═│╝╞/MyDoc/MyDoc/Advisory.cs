﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MyDoc
{
	public class Advisory
	{
        //############################################################
        //############################################################
        public string[,] xmlSections = new string[100,3];     
        public int iSection = 0;
        //public string sitename = "";

		// 构造一个空的Advisory对象，其中只包含该漏洞信息的源站点和源URL
		// 构造完毕后，应在该对象上调用AddSection来添加具体的属性值
        public Advisory()
		{
			//this.@ref = new List<string>();
            //sitename = SiteName;
            for (int i = 0; i < 100; i++)
            {
                xmlSections[i, 0] = "";
                xmlSections[i, 1] = "";
                xmlSections[i, 2] = "";
            }
		}

		// 向Advisory对象中增加一条属性值
		public void AddSection(string sectionName, string value)
		{
            //############################################################
            //############################################################
            if (sectionName == "volcheck")
            {
                int i = 0;
                if (value == "An error has occurred")
                {
                    i = 1;
                    //this.GetType().GetField(sectionName).SetValue(this, i);
                    xmlSections[iSection, 1] = i.ToString();
                }
                else
                {
                    //this.GetType().GetField(sectionName).SetValue(this, i);
                    xmlSections[iSection, 1] = i.ToString();
                }

                xmlSections[iSection, 0] = sectionName;              
                iSection = iSection + 1;

                return;
            }
            //############################################################
            //############################################################
            xmlSections[iSection, 0] = sectionName;
            xmlSections[iSection, 1] = value;
            iSection = iSection + 1;

            return;
		}

        public void AddSection(string sectionName, string value, int iSection)
        {
            //############################################################
            //############################################################
            if (sectionName == "volcheck")
            {
                int i = 0;
                if (value == "An error has occurred")
                {
                    i = 1;
                    //this.GetType().GetField(sectionName).SetValue(this, i);
                    xmlSections[iSection, 1] = i.ToString();
                }
                else
                {
                    //this.GetType().GetField(sectionName).SetValue(this, i);
                    xmlSections[iSection, 1] = i.ToString();
                }

                xmlSections[iSection, 0] = sectionName;

                return;
            }
            //############################################################
            //############################################################
            xmlSections[iSection, 0] = sectionName;
            xmlSections[iSection, 1] = value;

            return;
        }
	}

	public class AdvisoryList : List<Advisory>
	{
		// AdvisoryList的唯一实例
		private static AdvisoryList _instance = new AdvisoryList();

		// 使用单例模式
		private AdvisoryList() { }

		public static AdvisoryList Instance
		{
			get { return _instance; }
		}
	}

    //与漏洞数据库漏洞重复，需要更新信息（补丁信息）的漏洞列表
    //修改后，更新的内容会补充其他网站对该漏洞的描述
    public class UpdateAdvisoryList : List<Advisory>
    {
        private static UpdateAdvisoryList _instance = new UpdateAdvisoryList();
        private UpdateAdvisoryList() { }
        public static UpdateAdvisoryList Instance
        {
            get { return _instance; }
        }
    }

  
}
