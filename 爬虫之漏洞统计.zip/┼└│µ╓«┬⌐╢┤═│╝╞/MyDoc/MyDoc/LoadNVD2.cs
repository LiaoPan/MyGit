﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace MyDoc
{
    public partial class LoadNVD2 : Form
    {
        public LoadNVD2()
        {
            InitializeComponent();
            //int MonthCurrent = DateTime.Now.Month;
            //switch (MonthCurrent)
            //{
            //    case
            //}
            textBox1_year.Text = DateTime.Now.Year.ToString();
        }

        private void load_Click(object sender, EventArgs e)
        {
            DBManager.severe = severe.Checked;
            DBManager.high = high.Checked;
            DBManager.middle = middle.Checked;
            DBManager.low = low.Checked;              

            DBManager.ds1 = DBManager.GetDataFromDB("NVD2");
            //DBManager.ds1.Tables[0].Rows.Clear();
            DBManager.ds1.Clear();
            //DBManager.ds1.AcceptChanges(); 
            DBManager.ds1 = DBManager.GetDataFromDB("NVD2");
            //DBManager.ds1.Tables[0].AcceptChanges(); 
            DBManager.ds1flag = true;
            this.Close();
        }

        private void DateProcess_Click(object sender, EventArgs e)
        {
            DataProcess dp = new DataProcess();
            dp.AdvisoryPro();


        }

        private void MSAdd_Click(object sender, EventArgs e)
        {
            IniMonth();
            int num = 0;
            DataSet dsMS2 = new DataSet();
            dsMS2 = DBManager.GetDataFromDBMS();
            for (int k = 0; k < dsMS2.Tables[0].Rows.Count; k++ )
            {
                string ms2_cve = (string)dsMS2.Tables[0].Rows[k]["cve"];
                string ms2_adid = "(" + (string)dsMS2.Tables[0].Rows[k]["adid"] + ")";

                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
                try
                {
                    con.Open();
                    if (con.State == ConnectionState.Open)
                    {
                        SqlCommand com = new SqlCommand();
                        com.CommandType = CommandType.Text;
                        com.CommandText = string.Format("select * from NVD2 where cve = '{0}'", ms2_cve);
                        com.Connection = con;

                        SqlDataAdapter da = new SqlDataAdapter(com);
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        string strCveName = (string)ds.Tables[0].Rows[0]["volname"];
                        if (!strCveName.Contains(ms2_adid))
                        {
                            strCveName = strCveName + ms2_adid;
                            num = num + 1;
                        }
                        ds.Tables[0].Rows[0]["volname"] = strCveName;

                        SqlCommandBuilder scb = new SqlCommandBuilder(da);
                        da.Update(ds);                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("MS2读取失败");
                }
                finally
                {
                    con.Close();
                }
            }
            string numstr = string.Format("MS名字添加完毕，共添加{0}个漏洞", num);
            MessageBox.Show(numstr);
        }

        public void IniMonth()
        {
            for (int k = 0; k < 12;k++ )
            {
                DBManager.month[k] = false;
            }

            if (this.month1.Checked)
            {
                DBManager.month[0] = true;
            }
            else if (this.month2.Checked)
            {
                DBManager.month[1] = true;
            }
            else if (this.month3.Checked)
            {
                DBManager.month[2] = true;
            }
            else if (this.month4.Checked)
            {
                DBManager.month[3] = true;
            }
            else if (this.month5.Checked)
            {
                DBManager.month[4] = true;
            }
            else if (this.month6.Checked)
            {
                DBManager.month[5] = true;
            }
            else if (this.month7.Checked)
            {
                DBManager.month[6] = true;
            }
            else if (this.month8.Checked)
            {
                DBManager.month[7] = true;
            }
            else if (this.month9.Checked)
            {
                DBManager.month[8] = true;
            }
            else if (this.month10.Checked)
            {
                DBManager.month[9] = true;
            }
            else if (this.month11.Checked)
            {
                DBManager.month[10] = true;
            }
            else if (this.month12.Checked)
            {
                DBManager.month[11] = true;
            }
        }

        public static DataSet OpSQLWrite(string SQLSentence)
        {
            DataSet ds = new DataSet();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + "127.0.0.1" + ";database=" + "nvd" + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    com.ExecuteNonQuery();

                    //SqlDataAdapter da = new SqlDataAdapter(com);
                    ////DataSet dscl = new DataSet();
                    //da.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return ds;
        }

        public string CheckSingle(string str)
        {
            if (str.Count() == 1)
            {
                str = "0" + str;
            }

            return str;
        }

        private void UniDatetime_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + "127.0.0.1" + ";database=" + "nvd" + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from nvd2 order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string datetime = dscl.Tables[0].Rows[k]["datetime"].ToString();
                        
                        string UniYear = "";
                        string UniMonth = "";
                        string UniDay = "";
                        string UniHour = "";
                        string UniMinute = "";
                        string UniSecond = "";
                        string substr = "";
                        int G1 = -1;
                        int G2 = -1;
                        int M1 = -1;
                        int M2 = -1;
                        int K1 = -1;

                        if (datetime.Count() >= 10)
                        {
                            //  2013/11/21 11:03:14
                            G1 = datetime.IndexOf("/");
                            substr = datetime.Substring(G1+1);
                            G2 = substr.IndexOf("/");
                            K1 = datetime.IndexOf(" ");
                            M1 = datetime.IndexOf(":");
                            substr = datetime.Substring(M1 + 1);
                            M2 = substr.IndexOf(":");

                            UniYear = datetime.Substring(0, 4);
                            UniMonth = datetime.Substring(G1 + 1, G2);
                            UniMonth = CheckSingle(UniMonth);
                            UniDay = datetime.Substring(G1+G2+2, K1-G1-G2-2);
                            UniDay = CheckSingle(UniDay);
                            UniHour = datetime.Substring(K1+1,M1-K1-1);
                            UniHour = CheckSingle(UniHour);
                            UniMinute = datetime.Substring(M1+1,M2);
                            UniMinute = CheckSingle(UniMinute);
                            UniSecond = datetime.Substring(M1+M2+2);
                            UniSecond = CheckSingle(UniSecond);

                            string UniDatetime = "UniDatetime = '" + UniYear + "/" + UniMonth + "/" + UniDay + " " + UniHour + ":" + UniMinute + ":" + UniSecond + "' ";

                            string where = UniDatetime;

                            string SQLSentence = string.Format("update nvd2 set {0} where {1}", where, idstr);
                            OpSQLWrite(SQLSentence);
                        }
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("UniDatetime完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public string getCurrentCNCVE()
        {
            SQLSentence = string.Format("select top 1 cncve from vul_cve where cve like 'CVE-{0}-%' order by cncve desc", textBox1_year.Text);
            string currentcncve = DBManager4.OpSQLGetString(SQLSentence);
            return currentcncve;
        }

        public int getCurrentCNCVE_year(int year)
        {
            SQLSentence = string.Format("select count(*) cncve from vul_cve where cve like 'CVE-{0}-%' order by cncve desc", year);
            int re_year = DBManager4.OpSQLGetInt(SQLSentence);
            return re_year;
        }

        string SQLSentence = "";
        DataSet ds = new DataSet();
        private void Import_BigDatabase_btn_Click(object sender, EventArgs e)
        {
            ImportBigDB_A("nvd2");
            //textBox1_year.Refresh();
            //int year_test = System.Int32.Parse(textBox1_year.Text);
            //SQLSentence = string.Format("select * from nvd2 where cve like 'CVE-{0}-%' order by datetime",textBox1_year.Text);
            //ds = DBManager3.OpSQLGetTable(SQLSentence);

            //string currentcncve = getCurrentCNCVE();
            //int cncve = 99999;
            //int flag = 0;
            //if (currentcncve.Contains("NIPC-") && currentcncve.Length == 14)
            //{
            //    string[] strs = currentcncve.Split('-');
            //    if (strs.Count() == 3)
            //    {
            //        cncve = System.Int32.Parse(strs[2]);
            //        cncve = cncve + 1;
            //        MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            //        DialogResult dr = MessageBox.Show(cncve.ToString(), "是否导入大库", messButton);
            //        if (dr == DialogResult.OK)
            //        {

            //        }
            //        else
            //        {
            //            //MessageBox.Show("没有保存");
            //            flag = 1;
            //        }
            //    }
            //}
            //else if (currentcncve == "")
            //{
            //    int year = System.Int32.Parse(textBox1_year.Text);
            //    int temp1 = getCurrentCNCVE_year(year);
            //    int temp2 = getCurrentCNCVE_year(year - 1);

            //    if (temp1 == 0 && temp2 > 0)
            //    {
            //        cncve = 1;
            //        MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            //        DialogResult dr = MessageBox.Show(cncve.ToString(), "是否导入大库", messButton);
            //        if (dr == DialogResult.OK)
            //        {

            //        }
            //        else
            //        {
            //            //MessageBox.Show("没有保存");
            //            flag = 1;
            //        }
            //    }
            //}
            //else
            //{
            //    flag = 1;
            //    MessageBox.Show("获取cncve失败");
            //}

            //if (flag == 0)
            //{
            //    //string now = DateTime.Now.ToString();
            //    string now = DBManager.MyNow();
            //    now = now.Replace(" ","__");
            //    now = now.Replace(":","_");
            //    now = now.Replace("/", "");
            //    SQLSentence = string.Format("select * into nipc_{0} from nipc",now);
            //    DBManager3.OpSQLWrite(SQLSentence);
            //    SQLSentence = string.Format("delete from nipc");
            //    DBManager3.OpSQLWrite(SQLSentence);

            //    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            //    {
            //        string cve = ds.Tables[0].Rows[k]["cve"].ToString();

            //        string a_v = ds.Tables[0].Rows[k]["strAV"].ToString();
            //        string a_c = ds.Tables[0].Rows[k]["strAC"].ToString();
            //        string auth = ds.Tables[0].Rows[k]["strAu"].ToString();
            //        string cia_c = ds.Tables[0].Rows[k]["strC"].ToString();
            //        string cia_i = ds.Tables[0].Rows[k]["strI"].ToString();
            //        string cia_a = ds.Tables[0].Rows[k]["strA"].ToString();
            //        string cvss_cve = ds.Tables[0].Rows[k]["CVSS_v2_Base_Score"].ToString();
            //        string severity_cve = ds.Tables[0].Rows[k]["rank"].ToString();

            //        string name = ds.Tables[0].Rows[k]["volname"].ToString();
            //        string publishtime = ds.Tables[0].Rows[k]["Original_release_date"].ToString();
            //        string updatetime = ds.Tables[0].Rows[k]["Last_revised"].ToString();
            //        string description = ds.Tables[0].Rows[k]["translations"].ToString();
            //        string affect = ds.Tables[0].Rows[k]["affect"].ToString();
            //        //string solution = ds.Tables[0].Rows[0][""].ToString();
            //        string solution = "厂商已修复该漏洞";
            //        //string credit = ds.Tables[0].Rows[0][""].ToString();
            //        string credit = "";
            //        string url = ds.Tables[0].Rows[k]["url"].ToString();
            //        string link = "";
            //        for (int h = 0; h < 10; h++)
            //        {
            //            string strnum = "ref_" + (h + 1).ToString();
            //            link = link + "\n" + ds.Tables[0].Rows[0][strnum].ToString();
            //        }
            //        string class_id = ds.Tables[0].Rows[k]["volclass"].ToString();
            //        string class_id_str = GetClassID(class_id);

            //        string datetime = ds.Tables[0].Rows[k]["datetime"].ToString();

            //        string str_cncve = GetStrCncve(cncve);
            //        cncve = cncve + 1;
            //        SQLSentence = string.Format("insert into nipc(cncve,cve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,severity_cve,name,publishtime,updatetime,description,affect,solution,credit,url,link,class_id,datetime) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}')", str_cncve, cve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, severity_cve, name, publishtime, updatetime, description, affect, solution, credit, url, link, class_id_str, datetime);
            //        //SQLSentence = string.Format("insert into nipc(cve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,severity_cve,name,publishtime,updatetime,description,affect,solution,credit,url,link,class_id,datetime) values('{0}')", cve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, severity_cve, name, publishtime, updatetime, description, affect, solution, credit, url, link, class_id, datetime);
            //        DBManager3.OpSQLWrite(SQLSentence);
            //    }

            //    MessageBox.Show("导入完毕");
            //}
        }

        public string GetStrCncve(int cncve)
        {
            string temp = cncve.ToString();
            if (temp.Length == 1)
                temp = "000" + temp;
            else if (temp.Length == 2)
                temp = "00" + temp;
            else if (temp.Length == 3)
                temp = "0" + temp;

            string str_cncve = "NIPC-" + textBox1_year.Text + "-" + temp.ToString();
            return str_cncve;
        }

        public string GetClassID(string str)
        {
            int num = str.IndexOf("[");
            str = str.Substring(num + 1);
            num = str.IndexOf("]");
            string strtemp = "23";
            if (num > 0)
            {
                str = str.Substring(0, num);
                SQLSentence = string.Format("select class_id from nipc_vul_type_desc where class_name = '{0}'", str);
                strtemp = DBManager3.OpSQLGetInt(SQLSentence).ToString();
            }

            return strtemp;
        }

        //导入大库 2013 2
        private void button1_Click(object sender, EventArgs e)
        {
            ImportBigDB_B();
            //SQLSentence = string.Format("select * from nipc order by cncve");
            //DataSet ds_nipc = DBManager3.OpSQLGetTable(SQLSentence);
            //for (int h = 0; h < ds_nipc.Tables[0].Rows.Count; h++)
            //{
            //    string cncve = ds_nipc.Tables[0].Rows[h]["cncve"].ToString();
            //    string cve = ds_nipc.Tables[0].Rows[h]["cve"].ToString();
            //    string a_v = ds_nipc.Tables[0].Rows[h]["a_v"].ToString();
            //    string a_c = ds_nipc.Tables[0].Rows[h]["a_c"].ToString();
            //    string auth = ds_nipc.Tables[0].Rows[h]["auth"].ToString();
            //    string cia_c = ds_nipc.Tables[0].Rows[h]["cia_c"].ToString();
            //    string cia_i = ds_nipc.Tables[0].Rows[h]["cia_i"].ToString();
            //    string cia_a = ds_nipc.Tables[0].Rows[h]["cia_a"].ToString();
            //    string cvss_cve = ds_nipc.Tables[0].Rows[h]["cvss_cve"].ToString();
            //    string severity_cve = ds_nipc.Tables[0].Rows[h]["severity_cve"].ToString();
            //    string name = ds_nipc.Tables[0].Rows[h]["name"].ToString();
            //    string publishtime = ds_nipc.Tables[0].Rows[h]["publishtime"].ToString();
            //    string updatetime = ds_nipc.Tables[0].Rows[h]["updatetime"].ToString();
            //    string description = ds_nipc.Tables[0].Rows[h]["description"].ToString();
            //    string affect = ds_nipc.Tables[0].Rows[h]["affect"].ToString();
            //    string solution = ds_nipc.Tables[0].Rows[h]["solution"].ToString();
            //    string credit = ds_nipc.Tables[0].Rows[h]["credit"].ToString();
            //    string url = ds_nipc.Tables[0].Rows[h]["url"].ToString();
            //    string link = ds_nipc.Tables[0].Rows[h]["link"].ToString();
            //    string class_id = ds_nipc.Tables[0].Rows[h]["class_id"].ToString();
            //    string datetime = ds_nipc.Tables[0].Rows[h]["datetime"].ToString();

            //    //SQLSentence = string.Format("insert into nipc_vul_cve(cncve,cve) values('{0}','{1}')", cncve, cve);
            //    //DBManager3.OpSQLWrite(SQLSentence);
            //    //SQLSentence = string.Format("insert into nipc_vul_cvss(cncve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,cvss_cn,severity_cve,severity_cn) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')", cncve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, "", severity_cve, "");
            //    //DBManager3.OpSQLWrite(SQLSentence);
            //    //SQLSentence = string.Format("insert into nipc_vul_info(cncve,name,publishtime,updatetime,description,affect,solution,credit,url,flag) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')", cncve, name, publishtime, updatetime, description, affect, solution, credit, url, "");
            //    //DBManager3.OpSQLWrite(SQLSentence);
            //    //SQLSentence = string.Format("insert into nipc_vul_ref(cncve,link) values('{0}','{1}')", cncve, link);
            //    //DBManager3.OpSQLWrite(SQLSentence);
            //    //SQLSentence = string.Format("insert into nipc_vul_type(cncve,class_id) values('{0}','{1}')", cncve, class_id);
            //    //DBManager3.OpSQLWrite(SQLSentence);

            //    SQLSentence = string.Format("insert into vul_cve(cncve,cve) values('{0}','{1}')", cncve, cve);
            //    DBManager4.OpSQLWrite(SQLSentence);
            //    SQLSentence = string.Format("insert into vul_cvss(cncve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,cvss_cn,severity_cve,severity_cn) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')", cncve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, "", severity_cve, "");
            //    DBManager4.OpSQLWrite(SQLSentence);
            //    SQLSentence = string.Format("insert into vul_info(cncve,name,publishtime,updatetime,description,affect,solution,credit,url,flag) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')", cncve, name, publishtime, updatetime, description, affect, solution, credit, url, "");
            //    DBManager4.OpSQLWrite(SQLSentence);
            //    SQLSentence = string.Format("insert into vul_ref(cncve,link) values('{0}','{1}')", cncve, link);
            //    DBManager4.OpSQLWrite(SQLSentence);
            //    SQLSentence = string.Format("insert into vul_type(cncve,class_id) values('{0}','{1}')", cncve, class_id);
            //    DBManager4.OpSQLWrite(SQLSentence);
            //}

            //MessageBox.Show("导入完毕");
        }

        private void update_bigdb_btn_Click(object sender, EventArgs e)
        {
            try
            {
                string now = DBManager.MyNow();
                now = now.Replace(" ", "__");
                now = now.Replace(":", "_");
                now = now.Replace("/", "");
                SQLSentence = string.Format("select * into nvd2_temp_{0} from nipc", now);
                DBManager3.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("DROP TABLE nvd2_temp");
                DBManager3.OpSQLWrite(SQLSentence);
            }
            catch (Exception ex)
            {
 
            }

            //****************************************************************************
            //   20150521 确保是要更新的内容
            //****************************************************************************
            //SQLSentence = string.Format("select * into nvd2_temp from nvd2 where cve in (select SUBSTRING(cve,27,13) as cve from nvd) order by datetime");
            SQLSentence = string.Format("select * into nvd2_temp from nvd2 where SUBSTRING(url,49,13) in (select SUBSTRING(url,49,13) as cve from nvd) order by datetime");
            DataSet ds_nvd = DBManager3.OpSQLGetTable(SQLSentence);

            ImportBigDB_A("nvd2_temp");
            ImportBigDB_B();
        }

        public void ImportBigDB_A(string table)
        {
            textBox1_year.Refresh();
            int year_test = System.Int32.Parse(textBox1_year.Text);
            //SQLSentence = string.Format("select * from {0} where cve like 'CVE-{1}-%' order by datetime", table, textBox1_year.Text);
            SQLSentence = string.Format("select * from {0} order by datetime", table);
            ds = DBManager3.OpSQLGetTable(SQLSentence);

            //****************************************************************************
            //   20150521 确保能够连上
            //****************************************************************************
            string currentcncve = "NIPC-2016-9999";
            //string currentcncve = getCurrentCNCVE();
            int cncve = 99999;
            int flag = 0;
            if (currentcncve.Contains("NIPC-") && currentcncve.Length == 14)
            {
                string[] strs = currentcncve.Split('-');
                if (strs.Count() == 3)
                {
                    cncve = System.Int32.Parse(strs[2]);
                    cncve = cncve + 1;
                    //cncve = 502;
                    MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                    DialogResult dr = MessageBox.Show(cncve.ToString(), "是否导入大库", messButton);
                    if (dr == DialogResult.OK)
                    {

                    }
                    else
                    {
                        //MessageBox.Show("没有保存");
                        flag = 1;
                    }
                }
            }
            else if (currentcncve == "")
            {
                int year = System.Int32.Parse(textBox1_year.Text);
                int temp1 = getCurrentCNCVE_year(year);
                int temp2 = getCurrentCNCVE_year(year - 1);

                if (temp1 == 0 && temp2 > 0)
                {
                    cncve = 1;
                    MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                    DialogResult dr = MessageBox.Show(cncve.ToString(), "是否导入大库", messButton);
                    if (dr == DialogResult.OK)
                    {

                    }
                    else
                    {
                        //MessageBox.Show("没有保存");
                        flag = 1;
                    }
                }
            }
            else
            {
                flag = 1;
                MessageBox.Show("获取cncve失败");
            }

            if (flag == 0)
            {
                //string now = DateTime.Now.ToString();
                string now = DBManager.MyNow();
                now = now.Replace(" ", "__");
                now = now.Replace(":", "_");
                now = now.Replace("/", "");
                SQLSentence = string.Format("select * into nipc_{0} from nipc", now);
                DBManager3.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("delete from nipc");
                DBManager3.OpSQLWrite(SQLSentence);

                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    string cve = ds.Tables[0].Rows[k]["cve"].ToString();

                    string a_v = ds.Tables[0].Rows[k]["strAV"].ToString();
                    string a_c = ds.Tables[0].Rows[k]["strAC"].ToString();
                    string auth = ds.Tables[0].Rows[k]["strAu"].ToString();
                    string cia_c = ds.Tables[0].Rows[k]["strC"].ToString();
                    string cia_i = ds.Tables[0].Rows[k]["strI"].ToString();
                    string cia_a = ds.Tables[0].Rows[k]["strA"].ToString();
                    string cvss_cve = ds.Tables[0].Rows[k]["CVSS_v2_Base_Score"].ToString();
                    string severity_cve = ds.Tables[0].Rows[k]["rank"].ToString();

                    string name = ds.Tables[0].Rows[k]["volname"].ToString();
                    string publishtime = ds.Tables[0].Rows[k]["Original_release_date"].ToString();
                    string updatetime = ds.Tables[0].Rows[k]["Last_revised"].ToString();
                    string description = ds.Tables[0].Rows[k]["translations"].ToString();
                    string affect = ds.Tables[0].Rows[k]["affect"].ToString();
                    //string solution = ds.Tables[0].Rows[0][""].ToString();
                    string solution = "厂商已修复该漏洞";
                    //string credit = ds.Tables[0].Rows[0][""].ToString();
                    string credit = "";
                    string url = ds.Tables[0].Rows[k]["url"].ToString();
                    string link = "";
                    for (int h = 0; h < 10; h++)
                    {
                        string strnum = "ref_" + (h + 1).ToString();
                        link = link + "\n" + ds.Tables[0].Rows[0][strnum].ToString();
                    }
                    string class_id = ds.Tables[0].Rows[k]["volclass"].ToString();
                    string class_id_str = GetClassID(class_id);

                    string datetime = ds.Tables[0].Rows[k]["datetime"].ToString();

                    string str_cncve = GetStrCncve(cncve);
                    cncve = cncve + 1;
                    SQLSentence = string.Format("insert into nipc(cncve,cve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,severity_cve,name,publishtime,updatetime,description,affect,solution,credit,url,link,class_id,datetime) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}')", str_cncve, cve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, severity_cve, name, publishtime, updatetime, description, affect, solution, credit, url, link, class_id_str, datetime);
                    //SQLSentence = string.Format("insert into nipc(cve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,severity_cve,name,publishtime,updatetime,description,affect,solution,credit,url,link,class_id,datetime) values('{0}')", cve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, severity_cve, name, publishtime, updatetime, description, affect, solution, credit, url, link, class_id, datetime);
                    DBManager3.OpSQLWrite(SQLSentence);
                }

                MessageBox.Show("导入完毕A");
            }
        }

        public void ImportBigDB_B()
        {
            SQLSentence = string.Format("select * from nipc order by cncve");
            DataSet ds_nipc = DBManager3.OpSQLGetTable(SQLSentence);
            for (int h = 0; h < ds_nipc.Tables[0].Rows.Count; h++)
            {
                string cncve = ds_nipc.Tables[0].Rows[h]["cncve"].ToString();
                string cve = ds_nipc.Tables[0].Rows[h]["cve"].ToString();
                string a_v = ds_nipc.Tables[0].Rows[h]["a_v"].ToString();
                string a_c = ds_nipc.Tables[0].Rows[h]["a_c"].ToString();
                string auth = ds_nipc.Tables[0].Rows[h]["auth"].ToString();
                string cia_c = ds_nipc.Tables[0].Rows[h]["cia_c"].ToString();
                string cia_i = ds_nipc.Tables[0].Rows[h]["cia_i"].ToString();
                string cia_a = ds_nipc.Tables[0].Rows[h]["cia_a"].ToString();
                string cvss_cve = ds_nipc.Tables[0].Rows[h]["cvss_cve"].ToString();
                string severity_cve = ds_nipc.Tables[0].Rows[h]["severity_cve"].ToString();
                string name = ds_nipc.Tables[0].Rows[h]["name"].ToString();
                string publishtime = ds_nipc.Tables[0].Rows[h]["publishtime"].ToString();
                string updatetime = ds_nipc.Tables[0].Rows[h]["updatetime"].ToString();
                string description = ds_nipc.Tables[0].Rows[h]["description"].ToString();
                string affect = ds_nipc.Tables[0].Rows[h]["affect"].ToString();
                string solution = ds_nipc.Tables[0].Rows[h]["solution"].ToString();
                string credit = ds_nipc.Tables[0].Rows[h]["credit"].ToString();
                string url = ds_nipc.Tables[0].Rows[h]["url"].ToString();
                string link = ds_nipc.Tables[0].Rows[h]["link"].ToString();
                string class_id = ds_nipc.Tables[0].Rows[h]["class_id"].ToString();
                string datetime = ds_nipc.Tables[0].Rows[h]["datetime"].ToString();

                //SQLSentence = string.Format("insert into nipc_vul_cve(cncve,cve) values('{0}','{1}')", cncve, cve);
                //DBManager3.OpSQLWrite(SQLSentence);
                //SQLSentence = string.Format("insert into nipc_vul_cvss(cncve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,cvss_cn,severity_cve,severity_cn) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')", cncve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, "", severity_cve, "");
                //DBManager3.OpSQLWrite(SQLSentence);
                //SQLSentence = string.Format("insert into nipc_vul_info(cncve,name,publishtime,updatetime,description,affect,solution,credit,url,flag) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')", cncve, name, publishtime, updatetime, description, affect, solution, credit, url, "");
                //DBManager3.OpSQLWrite(SQLSentence);
                //SQLSentence = string.Format("insert into nipc_vul_ref(cncve,link) values('{0}','{1}')", cncve, link);
                //DBManager3.OpSQLWrite(SQLSentence);
                //SQLSentence = string.Format("insert into nipc_vul_type(cncve,class_id) values('{0}','{1}')", cncve, class_id);
                //DBManager3.OpSQLWrite(SQLSentence);

                SQLSentence = string.Format("insert into vul_cve(cncve,cve) values('{0}','{1}')", cncve, cve);
                DBManager4.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("insert into vul_cvss(cncve,a_v,a_c,auth,cia_c,cia_i,cia_a,cvss_cve,cvss_cn,severity_cve,severity_cn) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')", cncve, a_v, a_c, auth, cia_c, cia_i, cia_a, cvss_cve, "", severity_cve, "");
                DBManager4.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("insert into vul_info(cncve,name,publishtime,updatetime,description,affect,solution,credit,url,flag) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')", cncve, name, publishtime, updatetime, description, affect, solution, credit, url, "");
                DBManager4.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("insert into vul_ref(cncve,link) values('{0}','{1}')", cncve, link);
                DBManager4.OpSQLWrite(SQLSentence);
                SQLSentence = string.Format("insert into vul_type(cncve,class_id) values('{0}','{1}')", cncve, class_id);
                DBManager4.OpSQLWrite(SQLSentence);
            }

            MessageBox.Show("导入完毕B");
        }

    }
}
