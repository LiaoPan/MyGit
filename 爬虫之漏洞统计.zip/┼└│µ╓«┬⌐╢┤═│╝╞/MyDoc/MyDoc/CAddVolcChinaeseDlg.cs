﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyDoc
{
    public partial class CAddVolcChineseDlg : Form
    {
        public CAddVolcChineseDlg()
        {
            InitializeComponent();

            string SQLSentence = string.Format("select min(id) from {0}", TableName);
            double id = DBManager2.OpSQLGetInt64(SQLSentence);
            MyFindByID2("id", id.ToString());
        }

        //public string TableName = "_nvd_dictionary_201312092_精简后";
        public string TableName = "_nvd_dictionary";
        private void AddBtn_Click(object sender, EventArgs e)
        {
            txtVolc.Refresh();
            txtChinese.Refresh();
            string SQLSentence = "";
            int id = 0;

            //SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'", txtVolc.Text);
            SQLSentence = string.Format("select count(*) from {0} where volc = '{1}'", TableName, txtVolc.Text);
            id = DBManager2.OpSQLGetInt(SQLSentence);

            if (id > 0)
            {
                MessageBox.Show("单词已存在");
            }
            else
            {
                //SQLSentence = "select count(*) from _nvd_trans";
                SQLSentence = "select max(id) from _nvd_trans";
                id = DBManager2.OpSQLGetInt(SQLSentence) + 1;
                //SQLSentence = string.Format("insert into _nvd_trans (id,volc,trans) values ({0},'{1}','{2}')", id.ToString(), txtVolc.Text, txtTrans.Text);
                SQLSentence = string.Format("insert into {0} (id,volc,Chinese) values ({1},'{2}','{3}')", TableName, id.ToString(), txtVolc.Text, txtChinese.Text);
                DBManager2.OpSQLWrite(SQLSentence);
                MessageBox.Show("添加成功");
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            MyUpdate();
        }

        public void MyUpdate()
        {
            txtChinese.Refresh();
            txtCVE.Refresh();
            txtID.Refresh();
            txtIDvolc.Refresh();
            txtOrderID.Refresh();
            txtOverview.Refresh();
            txtTrans.Refresh();
            txtVolc.Refresh();
            string SQLSentence = "";
            int id = 0;

            //SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'",txtVolc.Text);
            SQLSentence = string.Format("select count(*) from {0} where volc = '{1}'", TableName, txtVolc.Text);
            id = DBManager2.OpSQLGetInt(SQLSentence);

            if (id <= 0)
            {
                MessageBox.Show("单词不存在");
            }
            else
            {
                //SQLSentence = string.Format("update _nvd_trans set volc = '{0}', trans = '{1}'", txtVolc.Text, txtTrans.Text);
                SQLSentence = string.Format("update {0} set Chinese = '{1}' where id = {2}", TableName, txtChinese.Text, txtID.Text);
                DBManager2.OpSQLWrite(SQLSentence);
                //MessageBox.Show("更新成功");
            }
        }

        private void FindBtn_Click(object sender, EventArgs e)
        {
            txtVolc.Refresh();
            txtChinese.Refresh();

            MyFindByVolc("volc", txtVolc.Text);
        }

        //将ds_over中的值显示到每个text中
        public void display(DataSet ds_Over)
        {
            txtChinese.Text = ds_Over.Tables[0].Rows[0]["Chinese"].ToString();
            txtCVE.Text = ds_Over.Tables[0].Rows[0]["cve"].ToString();
            txtID.Text = ds_Over.Tables[0].Rows[0]["id"].ToString();
            txtOrderID.Text = ds_Over.Tables[0].Rows[0]["orderID"].ToString();
            txtOverview.Text = ds_Over.Tables[0].Rows[0]["OverView"].ToString();
            txtTrans.Text = ds_Over.Tables[0].Rows[0]["trans"].ToString();
            txtVolc.Text = ds_Over.Tables[0].Rows[0]["volc"].ToString();
            txtIDvolc.Text = ds_Over.Tables[0].Rows[0]["id_volc"].ToString();

            txtChinese.Refresh();
            txtCVE.Refresh();
            txtID.Refresh();
            txtIDvolc.Refresh();
            txtOrderID.Refresh();
            txtOverview.Refresh();
            txtTrans.Refresh();
            txtVolc.Refresh();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            txtChinese.Refresh();
            txtCVE.Refresh();
            txtID.Refresh();
            txtIDvolc.Refresh();
            txtOrderID.Refresh();
            txtOverview.Refresh();
            txtTrans.Refresh();
            txtVolc.Refresh();

            string SQLSentence = "";
            int id = 0;

            //SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'", txtVolc.Text);
            SQLSentence = string.Format("select count(*) from {0} where id = {1}", TableName, txtID.Text);
            id = DBManager2.OpSQLGetInt(SQLSentence);

            if (id > 0)
            {
                //SQLSentence = string.Format("delete from _nvd_trans where volc = '{0}'", txtVolc.Text);
                //SQLSentence = string.Format("delete from {0} where id_volc = '{1}'", TableName, txtIDvolc.Text);
                SQLSentence = string.Format("delete from {0} where id = '{1}'", TableName, txtID.Text);
                DBManager2.OpSQLWrite(SQLSentence);
                //MessageBox.Show("删除成功");

                int id2 = System.Int32.Parse(txtID.Text);

                SQLSentence = string.Format("select count(*) from {0}", TableName);
                int total = DBManager2.OpSQLGetInt(SQLSentence);
                if (id < total)
                {
                    id2 = id2 + 1;
                    MyFindById("id", id2.ToString());
                }
            }
            else
            {
                MessageBox.Show("单词不存在");
            }
        }

        private void AddOrderBtn_Click(object sender, EventArgs e)
        {
            string SQLSentence = string.Format("select * from {0} order by volc", TableName);
            DataSet ds = DBManager2.OpSQLGetTable(SQLSentence);
            int k = 0;
            for (k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                string id = ds.Tables[0].Rows[k]["id"].ToString();
                string SQLSentence2 = string.Format("update {0} set id_volc = {1} where id = {2}", TableName, k+1, id);
                DBManager2.OpSQLWrite(SQLSentence2);
            }
        }

        private void FindIDBtn_Click(object sender, EventArgs e)
        {
            txtVolc.Refresh();
            txtIDvolc.Refresh();

            MyFindById("id_volc", txtIDvolc.Text);
        }

        public bool MyFindById(string str1, string str2)
        {
            string SQLSentence = "";
            int id = 0;

            //SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'", txtVolc.Text);
            SQLSentence = string.Format("select count(*) from {0} where {1} = {2}", TableName, str1, str2);
            id = DBManager2.OpSQLGetInt(SQLSentence);

            if (id > 0)
            {
                //SQLSentence = string.Format("select trans from _nvd_trans where volc = '{0}'", txtVolc.Text);
                SQLSentence = string.Format("select * from {0} where {1} = {2} order by id_volc", TableName, str1, str2);
                DataSet ds_Over = new DataSet();
                ds_Over = DBManager2.OpSQLGetTable(SQLSentence);
                display(ds_Over);

                return true;
                //string strid = string.Format("存在{0}个,翻译是 [{1}]", id.ToString(), trans);
                //MessageBox.Show(strid);
            }
            else
            {
                //MessageBox.Show("要查找的单词不存在");
                return false;
            }
        }

        public void MyFindByVolc(string str1, string str2)
        {
            string SQLSentence = "";
            int id = 0;

            //SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'", txtVolc.Text);
            SQLSentence = string.Format("select count(*) from {0} where {1} = '{2}'", TableName, str1, str2);
            id = DBManager2.OpSQLGetInt(SQLSentence);

            if (id > 0)
            {
                //SQLSentence = string.Format("select trans from _nvd_trans where volc = '{0}'", txtVolc.Text);
                SQLSentence = string.Format("select * from {0} where {1} = '{2}' order by id", TableName, str1, str2);
                DataSet ds_Over = new DataSet();
                ds_Over = DBManager2.OpSQLGetTable(SQLSentence);
                display(ds_Over);


                //string strid = string.Format("存在{0}个,翻译是 [{1}]", id.ToString(), trans);
                //MessageBox.Show(strid);
            }
            else
            {
                MessageBox.Show("要查找的单词不存在");
            }
        }

        public bool MyFindByID2(string str1, string str2)
        {
            string SQLSentence = "";
            int id = 0;

            //SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'", txtVolc.Text);
            SQLSentence = string.Format("select count(*) from {0} where {1} = '{2}'", TableName, str1, str2);
            id = DBManager2.OpSQLGetInt(SQLSentence);

            if (id > 0)
            {
                //SQLSentence = string.Format("select trans from _nvd_trans where volc = '{0}'", txtVolc.Text);
                SQLSentence = string.Format("select * from {0} where {1} = '{2}' order by id_volc", TableName, str1, str2);
                DataSet ds_Over = new DataSet();
                ds_Over = DBManager2.OpSQLGetTable(SQLSentence);
                display(ds_Over);

                return true;
                //string strid = string.Format("存在{0}个,翻译是 [{1}]", id.ToString(), trans);
                //MessageBox.Show(strid);
            }
            else
            {
                return false;
                //MessageBox.Show("要查找的单词不存在");
            }
        }

        private void UpBtn_Click(object sender, EventArgs e)
        {
            txtVolc.Refresh();
            txtIDvolc.Refresh();
            int id_volc = System.Int32.Parse(txtIDvolc.Text);

            bool isbool = false;
            while (!isbool)
            {
                if (id_volc > 0)
                {
                    id_volc = id_volc - 1;
                    isbool = MyFindById("id_volc", id_volc.ToString());
                }
                else
                {
                    isbool = true;
                }
            }
        }

        private void DownBtn_Click(object sender, EventArgs e)
        {
            MyUpdate();

            txtVolc.Refresh();
            txtIDvolc.Refresh();
            int id_volc = System.Int32.Parse(txtIDvolc.Text);

            bool isbool = false;
            while (!isbool)
            {
                string SQLSentence = string.Format("select count(*) from {0}", TableName);
                int total = DBManager2.OpSQLGetInt(SQLSentence);
                if (id_volc < total)
                {
                    id_volc = id_volc + 1;
                    isbool = MyFindById("id_volc", id_volc.ToString());
                }
                else
                {
                    isbool = true;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //txtVolc.Refresh();
            //txtID.Refresh();

            //MyFindByID2("id", txtID.Text);

            //MyUpdate();

            txtVolc.Refresh();
            txtID.Refresh();
            int id = System.Int32.Parse(txtID.Text);

            bool isbool = false;
            while (!isbool)
            {

                //string SQLSentence = string.Format("select count(*) from {0}", TableName);
                //int total = DBManager2.OpSQLGetInt(SQLSentence);
                //if (id < total)
                //{
                //    isbool = MyFindByID2("id", id.ToString());
                //    id = id + 1;
                //}
                string SQLSentence = string.Format("select count(*) from {0} where id <= {1} ", TableName, txtID.Text);
                int already = DBManager2.OpSQLGetInt(SQLSentence);
                SQLSentence = string.Format("select count(*) from {0}", TableName);
                int total = DBManager2.OpSQLGetInt(SQLSentence);

                if (already < total)
                {
                    isbool = MyFindByID2("id", id.ToString());
                    id = id + 1;
                }
                else
                {
                    isbool = true;
                }
            }

            DisplayAlready();
        }

        //上一条id
        private void button2_Click(object sender, EventArgs e)
        {
            MyUpdate();

            txtVolc.Refresh();
            txtID.Refresh();
            int id = System.Int32.Parse(txtID.Text);

            bool isbool = false;
            while (!isbool)
            {
                if (id > 0)
                {
                    id = id - 1;
                    isbool = MyFindByID2("id", id.ToString());
                }
                else
                {
                    isbool = true;
                }
            }

            DisplayAlready();
        }


        //下一条id
        private void button1_Click(object sender, EventArgs e)
        {
            MyUpdate();

            txtVolc.Refresh();
            txtID.Refresh();
            int id = System.Int32.Parse(txtID.Text);

            bool isbool = false;
            while (!isbool)
            {
                string SQLSentence = string.Format("select count(*) from {0} where id <= {1} ", TableName, txtID.Text);
                int already = DBManager2.OpSQLGetInt(SQLSentence);
                SQLSentence = string.Format("select count(*) from {0}", TableName);
                int total = DBManager2.OpSQLGetInt(SQLSentence);
                txtAlready.Text = already.ToString() + " / " + total.ToString();

                if (already < total)
                {
                    id = id + 1;
                    isbool = MyFindByID2("id", id.ToString());
                }
                else
                {
                    isbool = true;
                }
            }

            DisplayAlready();
        }

        public void DisplayAlready()
        {
            //显示already
            string SQLSentence2 = string.Format("select count(*) from {0} where id <= {1} ", TableName, txtID.Text);
            int already = DBManager2.OpSQLGetInt(SQLSentence2);
            SQLSentence2 = string.Format("select count(*) from {0}", TableName);
            int total = DBManager2.OpSQLGetInt(SQLSentence2);
            txtAlready.Text = already.ToString() + " / " + total.ToString();
            txtAlready.Refresh();

            button1.Text = txtVolc.Text + "  下一条";
            button1.Refresh();
            txtVolc.Refresh();
            txtTrans.Refresh();
            string trans = txtTrans.Text.ToLower();
            if (trans.Contains(txtVolc.Text.ToLower()))
            {
                MessageBox.Show("不需要翻译");
                button1.Focus();
            }
            else
            {
                //txtChinese.Focus();
                txtVolc.Refresh();
                int a = txtOverview.Text.IndexOf(txtVolc.Text);
                string volc = txtVolc.Text;
                volc = volc.Trim();
                int b = volc.Length;
                txtOverview.Focus();
                txtOverview.Select(a, b);
            }
            
        }

        private void volcInOverviewBtn_Click(object sender, EventArgs e)
        {
            txtVolc.Refresh();
            int a = txtOverview.Text.IndexOf(txtVolc.Text);
            string volc = txtVolc.Text;
            volc = volc.Trim();
            int b = volc.Length;
            txtOverview.Focus();
            txtOverview.Select(a,b);
        }
    }
}
