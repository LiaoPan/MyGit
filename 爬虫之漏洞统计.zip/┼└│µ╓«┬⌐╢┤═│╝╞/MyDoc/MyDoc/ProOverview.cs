﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;


using System.IO;
using System.Data.SqlClient;

//using WeifenLuo.WinFormsUI.Docking;
using System.Web;
using System.Configuration;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.HttpContext;

namespace MyDoc
{
    public partial class ProOverview : Form
    {
        public ProOverview()
        {
            InitializeComponent();
            overview.Text = VolOverAll.strOverview;
            overview.Refresh();
        }

        string str = "";
        List<string[]> strList = new List<string[]>();
        //string[] strs;
        public void pro_str()
        {
            overview.Refresh();
            str = overview.Text;

            str = str.Replace(" ", "@");
            str = str.Replace("\n", "@");
            str = str.Replace("'","''");
            str = str.Replace(",","@,@");
            str = str.Replace("（", "@（@");
            str = str.Replace("）", "@）@");
            str = str.Replace("[", "@]@");
            str = str.Replace("]", "@]@");
            str = str.Replace("{", "@{@");
            str = str.Replace("}", "@}@");
            //str = str.Replace(":", "@:@");
            str = str.Replace(";", "@;@");
            str = str.Replace("!", "@!@");
            str = str.Replace("'s", "@的@");
            //str = str.Replace("/", "@/@");
            //str = str.Replace("\\", "@\\@");
            //str = str.Replace("|", "@|@");
            str = str.Replace("\"", "@\"@");
            str = str.Replace("`", "@`@");
            

            //str = str.Replace(". ","@.@");
            //str = str.Replace(".\r\n", "@.@");

            strs = str.Split('@');

            //处理strs单个的单词
            for (int k = 0; k < strs.Count(); k++)
            {
                //去掉单词后面的‘.’
                string strPoint = strs[k];
                if (strPoint != "")               
                {
                    char start = strPoint[0];
                    char end = strPoint[strPoint.Length - 1];
                    if (end == '.')
                        strs[k] = strPoint.Substring(0, strPoint.Length - 1);  
                    //else if (end == ')' && start != '(')                    
                    //    strs[k] = strPoint.Substring(0, strPoint.Length - 1);  
                    //else if (end != ')' && start == '(')
                    //    strs[k] = strPoint.Substring(1); 
                }
            }

        }

        public void pro_overview(string dictionary, string tempDic)
        {
            string SQLSentence = string.Format("delete from {0}", tempDic);
            DBManager2.OpSQLWrite(SQLSentence);

            int k = 1;
            string chineseb = "";
            for (k = 1; k <= strs.Count(); k++)
            {
                if (strs[k - 1] != "")
                {
                    SQLSentence = string.Format("select Chinese from {0} where volc = '{1}'", dictionary, strs[k - 1]);
                    string chinese = DBManager2.OpSQLGetString(SQLSentence);
                    if (chinese == "")
                        chinese = strs[k - 1];
                    //处理and，将“和“修改为“以及”
                    if (chinese == "和" && (chineseb == "," || chineseb == ";"))
                        chinese = "以及";
                    SQLSentence = string.Format("insert into {0} (id,volc,trans) values ({1},'{2}','{3}')", tempDic, k.ToString(), strs[k - 1], chinese);
                    DBManager2.OpSQLWrite(SQLSentence);
                    chineseb = chinese;
                }
            }
        }

        public void pro_allow()
        {
            string SQLSentence = string.Format("delete from {0}", VolOverAll.Field);
            DBManager2.OpSQLWrite(SQLSentence);

            for (int k = 1; k <= strs.Count(); k++)
            {
                if (strs[k - 1] != "")
                {
                    string volc_class = "$";
                    string volc_trans = strs[k - 1];

                    if (VolOverAll.attackers.Contains("@" + strs[k - 1] + "@"))
                        volc_class = "attacker";
                    else if (strs[k - 1] == "with")
                        volc_class = "with";
                    else if (strs[k - 1] == "and")
                        volc_class = "and";
                    else if (strs[k - 1] == "or")
                        volc_class = "or";
                    else if (strs[k - 1] == "allow")
                        volc_class = "allow";
                    else if (strs[k - 1] == "to")
                        volc_class = "to";
                    else if (strs[k - 1] == "on")
                        volc_class = "on";
                    else if (strs[k - 1] == "in")
                        volc_class = "in";
                    else if (strs[k - 1] == "the")
                        volc_class = "the";
                    else if (strs[k - 1] == "a")
                        volc_class = "a";
                    else if (strs[k - 1] == "an")
                        volc_class = "an";

                    SQLSentence = string.Format("select count(*) from _nvd_trans where volc = '{0}'", strs[k - 1]);
                    int num = DBManager2.OpSQLGetInt(SQLSentence);
                    if (num > 0)
                    {
                        SQLSentence = string.Format("select trans from _nvd_trans where volc = '{0}'", strs[k - 1]);
                        volc_trans = DBManager2.OpSQLGetString(SQLSentence);
                    }

                    SQLSentence = string.Format("insert into {0} (id,volc,volc_class,volc_trans) values ({1},'{2}','{3}','{4}')", VolOverAll.Field, k.ToString(), strs[k - 1], volc_class, volc_trans);
                    DBManager2.OpSQLWrite(SQLSentence);
                }
            }
        }

        //dataset用于显示grip控件
        DataSet dsGrip = new DataSet();
        string[] strs;
        //处理按钮
        private void pro_Click(object sender, EventArgs e)
        {
            //pro_str();
            overview.Refresh();
            strs = Pro_String.pro_str(overview.Text);
            if (VolOverAll.Field == "_nvdDisOverview")
                pro_overview("_nvd_dictionary", "_nvdDisOverview");
            if (VolOverAll.Field == "_nvd_allow")
                pro_allow();

            string SQLSentence = string.Format("select * from {0}", VolOverAll.Field);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);
            //dataGridView2.AutoGenerateColumns = false;
            dataGridView2.DataSource = dsGrip.Tables[0];
            dataGridView2.Refresh();

            CreateTrans();           
        }

        public void CreateTrans()
        {
            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }
            txtSentence.Text = chinese;
            txtSentence.Refresh();
        }

        public void CreateTransFragment()
        {
            //txtAllow.Refresh();
            //txtBecause.Refresh();
            //txtCause.Refresh();
            //txtSentence.Refresh();
            //txtVendor.Refresh();
            //txtVersion.Refresh();
            //txtVia.Refresh();
            //txtDesc.Refresh();
            //txtVul.Refresh();
            //txtNote.Refresh();

            //string strDesc = CreateTransDesc(txtDesc.Text, "_nvd_dictionary", "_nvdDisOverview");
            //string strVendorC = CreateTransVendor(txtVendor.Text, "_nvd_preposition", "_nvdDisOverview");
            //string strVul = CreateTransVul(txtVul.Text, "_nvd_dictionary", "_nvdDisOverview");
            //string strVersionC = CreateTransVersion(txtVersion.Text, "_nvd_preposition", "_nvdDisOverview");
            //string strBecauseC = CreateTransBecause(txtBecause.Text, "_nvd_dictionary", "_nvdDisOverview");
            //string strAllowC = CreateTransAllow(txtAllow.Text, "_nvd_dictionary", "_nvdDisOverview");
            //string strCauseC = CreateTransCause(txtCause.Text, "_nvd_dictionary", "_nvdDisOverview");
            //string strViaC = CreateTransVia(txtVia.Text, "_nvd_dictionary", "_nvdDisOverview");
            //string strNoteC = CreateTransNote(txtNote.Text, "_nvd_dictionary", "_nvdDisOverview");

            //txtSentence.Text = strDesc
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strVendorC
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strVul
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strVersionC
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + "由于没有能够" + VolOverAll.strCause
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strBecauseC
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strAllowC
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strViaC
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strCauseC
            //    + Environment.NewLine
            //    + Environment.NewLine
            //    + strNoteC
            //    ;

            //txtSentence.Text = txtSentence.Text.Replace("  ", " ");
            //txtSentence.Text = txtSentence.Text.Trim();
            //txtSentence.Refresh();
        }

        public void CreateTransFragmentAt()
        {
            txtAllow.Refresh();
            txtBecause.Refresh();
            txtCause.Refresh();
            txtSentence.Refresh();
            txtVendor.Refresh();
            txtVersion.Refresh();
            txtVia.Refresh();
            txtDesc.Refresh();
            txtVul.Refresh();
            txtNote.Refresh();

            string strDesc = CreateTransAt(txtDesc.Text, "_nvd_dictionary", "_nvdDisOverview");
            string strVendorC = CreateTransVendor(txtVendor.Text, "_nvd_preposition", "_nvdDisOverview");
            string strVul = CreateTransVul(txtVul.Text, "_nvd_dictionary", "_nvdDisOverview");
            string strVersionC = CreateTransVersion(txtVersion.Text, "_nvd_preposition", "_nvdDisOverview");
            string strBecauseC = CreateTransAt(txtBecause.Text, "_nvd_dictionary", "_nvdDisOverview");
            string strAllowC = CreateTransAt(txtAllow.Text, "_nvd_dictionary", "_nvdDisOverview");
            string strCauseC = CreateTransAt(txtCause.Text, "_nvd_dictionary", "_nvdDisOverview");
            string strViaC = CreateTransAt(txtVia.Text, "_nvd_dictionary", "_nvdDisOverview");
            string strNoteC = CreateTransAt(txtNote.Text, "_nvd_dictionary", "_nvdDisOverview");

            txtTital.Text = CreateTransVendor_tital(txtVendor.Text, "_nvd_preposition", "_nvdDisOverview")
                + CreateTransVul_tital(txtVul.Text, "_nvd_dictionary", "_nvdDisOverview");

            string strCause = "";
            if (VolOverAll.strCause.Length > 3)
            {
                strCause = "由于" + VolOverAll.strCause + ", ";
            }

            txtSentence.Text = strDesc
                + Environment.NewLine + Environment.NewLine
                + strVendorC
                + Environment.NewLine + Environment.NewLine
                + strVul
                + Environment.NewLine + Environment.NewLine
                + strVersionC
                + Environment.NewLine + Environment.NewLine
                + strCause
                + Environment.NewLine + Environment.NewLine
                + strBecauseC
                + Environment.NewLine + Environment.NewLine
                + strAllowC
                + Environment.NewLine + Environment.NewLine
                + strViaC + ", "
                + Environment.NewLine + Environment.NewLine
                + strCauseC
                + Environment.NewLine + Environment.NewLine
                + strNoteC;

            txtSentence.Text = txtSentence.Text.Replace("  ", " ");
            txtSentence.Text = txtSentence.Text.Trim();
            txtSentence.Refresh();
        }

        private string reverseString(string str)
        {
            char[] x = str.ToCharArray();
            string strr = "";
            foreach (char a in x)
            {
                strr = a + strr;
            }
            return strr;
        }

        public string AddStar(string str)
        {
            string rev = reverseString(str);
            int num = rev.IndexOf(' ');
            if (num >= 0)
            {
                rev = rev.Insert(num, " }*{ ");
                str = reverseString(rev);
            }
            else
            {
                //str = " {*} ";
            }

            return str;
        }

        public string CreateTransAt(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            string tempBefore = "";
            string chineseSentence = "";
            int id = 1;
            string senStart = "";
            string senEnd = "";
            string senStartBefore = "";
            string senEndBefore = "";
            string location = "";
            //string tempBeforeStar = "";
            DataSet dsAt = new DataSet();

            SQLSentence = string.Format("delete from _nvd_temp_sentence");
            DBManager2.OpSQLWrite(SQLSentence);

            int lines = dsGrip.Tables[0].Rows.Count;

            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];

                if (temp == "@")
                {
                    chineseSentence = senStartBefore + " " + chineseSentence + " " + senEndBefore;
                    chineseSentence = chineseSentence.Replace("'", "''");
                    SQLSentence = string.Format("insert into _nvd_temp_sentence (id,volc,sentence,senStart,senEnd) values ({0},'{1}','{2}','{3}','{4}')", id, tempBefore, chineseSentence, senStartBefore, senEndBefore);
                    DBManager2.OpSQLWrite(SQLSentence);
                    id = id + 1;
                    tempBefore = temp;
                    senStartBefore = senStart;
                    senEndBefore = senEnd;

                    chinese = chinese + Environment.NewLine + chineseSentence;
                    chineseSentence = "";

                    senStart = "";
                    senEnd = "";
                    location = "no";
                    senStartBefore = senStart;
                    senEndBefore = senEnd;

                    //chinese = chinese + Environment.NewLine + temp;      

                }
                else if (temp.Contains("@"))
                {
                    SQLSentence = string.Format("select * from _nvd_dic_preposition where volc = '{0}'", temp);
                    dsAt = DBManager2.OpSQLGetTable(SQLSentence);
                    if (dsAt.Tables.Count > 0 && dsAt.Tables[0].Rows.Count > 0)
                    {
                        senStart = (string)dsAt.Tables[0].Rows[0]["senStart"];
                        senEnd = (string)dsAt.Tables[0].Rows[0]["senEnd"];
                        location = (string)dsAt.Tables[0].Rows[0]["location"];
                    }
                    else
                    {
                        senStart = "";
                        senEnd = "";
                    }

                    if (location == "")
                    {
                        chineseSentence = AddStar(chineseSentence);
                    }
                    
                    chineseSentence = senStartBefore + " " + chineseSentence + " " + senEndBefore;
                    chineseSentence = chineseSentence.Replace("'","''");
                    SQLSentence = string.Format("insert into _nvd_temp_sentence (id,volc,sentence,senStart,senEnd) values ({0},'{1}','{2}','{3}','{4}')", id, tempBefore, chineseSentence, senStartBefore, senEndBefore);
                    DBManager2.OpSQLWrite(SQLSentence);
                    id = id + 1;
                    tempBefore = temp;
                    senStartBefore = senStart;
                    senEndBefore = senEnd;
                    
                    chinese = chinese + Environment.NewLine + chineseSentence;
                    chineseSentence = "";

                    //chinese = chinese + Environment.NewLine + temp;      
 
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    //chinese = chinese + " " + temp;
                    chineseSentence = chineseSentence + " " + temp;
                }
                //tempBeforeStar = temp;
            }

            if (chineseSentence != "")
            {
                chineseSentence = senStart + " " + chineseSentence + " " + senEnd;
                chineseSentence = chineseSentence.Replace("'", "''");
                SQLSentence = string.Format("insert into _nvd_temp_sentence (id,volc,sentence,senStart,senEnd) values ({0},'{1}','{2}','{3}','{4}')", id, tempBefore, chineseSentence, senStartBefore, senEndBefore);
                DBManager2.OpSQLWrite(SQLSentence);
                chinese = chinese + Environment.NewLine + chineseSentence;
            }

            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransIntel(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransNote(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransCause(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            int lines = dsGrip.Tables[0].Rows.Count;

            List<string> listSegment = new List<string>();
            string strb = "";
            string stre = "";
            for (int k = 0; k < lines; k++)
            {
                string strc = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (strc.Trim() == ", 通过")
                {
                    string strd = strb + stre;
                    listSegment.Add(strd);
                    strb = strc;
                    stre = "";
                }
                else if (strc == "@in")
                {
                    strc = " 于 ";
                    strb = strb + " " + strc;
                }
                else if (strc == "#" || strc == "@to")
                {
                    ;
                }
                else
                {
                    if (strb == "")
                        strb = strc;
                    else
                        strb = strb + " " + strc;
                }
            }
            string strf = strb + stre;
            listSegment.Add(strf);

            string chinese = "";
            for (int k = listSegment.Count - 1; k >= 0; k--)
            {
                chinese = chinese + listSegment[k] + " ";
            }

            chinese = " , 从而 " + chinese + " . ";
            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransVia(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            int lines = dsGrip.Tables[0].Rows.Count;

            List<string> listSegment = new List<string>();
            string strb = "";
            string stre = "";
            int num = -1;
            for (int k = 0; k < lines; k++)
            {
                string strc = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (strc.Trim() == ", 通过")
                {
                    string strd = strb + stre;
                    listSegment.Add(strd);
                    strb = strc;
                    stre = "";
                }
                else if (strc == "@in")
                {
                    string strd = strb + stre;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " 中的 ";
                }
                else if (strc == "#" || strc == "@to")
                {
                    ;
                }
                else
                {
                    if (strb == "")
                        strb = strc;
                    else
                        strb = strb + " " + strc;
                }
            }
            string strf = strb + stre;
            listSegment.Add(strf);

            string chinese = "";
            for (int k = listSegment.Count - 1; k >= 0; k--)
            {
                chinese = chinese + listSegment[k] + " ";
            }

            chinese = MyTrim(chinese);
            if (chinese[chinese.Count() - 1] == ',')
                chinese = chinese.Substring(0, chinese.Count() - 1);

            if (chinese.Contains("关于(related to)"))
            {
                num = chinese.IndexOf("关于(related to)");
            }

            chinese = chinese + " 的方式 , ";
            return chinese;
        }

        public string CreateTransBecause(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";

            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = " 该漏洞源于 " + chinese;
            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransDesc(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = chinese + " 的 ";
            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransAllow(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#") || temp.Contains("@to"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = "该漏洞 " + chinese;
            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransVul(string str, string dictionary, string tempDic)
        {
            if (str == "")
                str = "安全漏洞, ";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@in"))
                {
                    ;
                }
                else if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = " 中存在 " + chinese + ", ";
            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransVul_tital(string str, string dictionary, string tempDic)
        {
            if (str == "")
                str = " 安全漏洞";
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@in"))
                {
                    ;
                }
                else if (temp.Contains("@"))
                {
                    chinese = chinese + Environment.NewLine + temp;
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = " " + chinese;
            chinese = MyTrim(chinese);
            chinese = chinese.Replace(" 漏洞","漏洞");
            chinese = chinese.Replace("未知的漏洞", "未知漏洞");
            return chinese;
        }

        public string MyTrim(string chinese)
        {
            chinese = chinese.Trim();
            chinese = chinese.Replace("  ", " ");
            chinese = chinese.Replace(",,", ",");
            chinese = chinese.Replace(", ,", ",");
            chinese = chinese.Replace(", .", ".");
            chinese = chinese.Replace(". ,", ".");
            chinese = chinese.Replace(",.", ".");
            chinese = chinese.Replace(".,", ".");

            return chinese;
        }

        public string CreateTransVersion(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";
            str = str.Replace("@,",",");
            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            string chinese = "";
            int lines = dsGrip.Tables[0].Rows.Count;
            for (int k = 0; k < lines; k++)
            {
                string temp = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (temp.Contains("@for"))
                {
                    chinese = chinese + " 的 ";
                }
                if (temp.Contains("@on"))
                {
                    chinese = chinese + " 的 ";
                }
                else if (temp.Contains(" @, "))
                {
                    chinese = chinese + " , ";
                }
                else if (temp.Contains("#"))
                {
                    ;
                }
                else
                {
                    chinese = chinese + " " + temp;
                }
            }

            chinese = "受影响的产品, " + chinese + ",";
            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransVendor(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";

            str = str.Replace("@,",",");
            //按照特殊符号分词，空格、[｛等
            strs = Pro_String.pro_str(str);
            //完成_nvdDisOverview表，单词和中文翻译
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            int lines = dsGrip.Tables[0].Rows.Count;

            List<string> listSegment = new List<string>();
            string strb = "";
            string stre = "";
            for (int k = 0; k < lines; k++)
            {
                string strc = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (strc == "@in")
                {
                    strb = strb + stre;
                    string strd = strb;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " 中的";
                }
                else if (strc == "@on")
                {
                    strb = strb + stre;
                    string strd = strb;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " 中的";
                }
                else if (strc == "@for")
                {
                    strb = strb + stre;
                    string strd = strb;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " 上的";
                }
                else if (strc == "#")
                {
                    ;
                }
                else
                {
                    if (strb == "")
                        strb = strc;
                    else
                        strb = strb + " " + strc;
                }
            }
            strb = strb + stre;
            string strf = strb;
            listSegment.Add(strf);

            string chinese = "";
            for (int k = listSegment.Count-1; k >= 0; k--)
            {
                chinese = chinese + listSegment[k] + " ";
            }

            chinese = MyTrim(chinese);
            return chinese;
        }

        public string CreateTransVendor_tital(string str, string dictionary, string tempDic)
        {
            if (str == "")
                return "";

            str = str.Replace("@,", ",");

            strs = Pro_String.pro_str(str);
            pro_overview(dictionary, tempDic);

            string SQLSentence = string.Format("select * from {0}", tempDic);
            dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

            int lines = dsGrip.Tables[0].Rows.Count;

            List<string> listSegment = new List<string>();
            string strb = "";
            string stre = "";
            for (int k = 0; k < lines; k++)
            {
                string strc = (string)dsGrip.Tables[0].Rows[k]["trans"];
                if (strc == "@in")
                {
                    strb = strb + stre;
                    string strd = strb;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " ";
                }
                else if (strc == "@on")
                {
                    strb = strb + stre;
                    string strd = strb;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " ";
                }
                else if (strc == "@for")
                {
                    strb = strb + stre;
                    string strd = strb;
                    listSegment.Add(strd);
                    strb = "";
                    stre = " ";
                }
                else if (strc == "#")
                {
                    ;
                }
                else
                {
                    if (strb == "")
                        strb = strc;
                    else
                        strb = strb + " " + strc;
                }
            }
            strb = strb + stre;
            string strf = strb;
            listSegment.Add(strf);

            string chinese = "";
            for (int k = listSegment.Count - 1; k >= 0; k--)
            {
                chinese = chinese + listSegment[k] + " ";
            }

            chinese = MyTrim(chinese);
            return chinese;
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            //string SQLSentence = string.Format("select volclass from nvd where volclass <> ''");
            //DataSet ds = DBManager2.OpSQLGetTable(SQLSentence);
            //string str = (string)ds.Tables[0].Rows[0]["volclass"];

            CreateTransFragment();
        }

        private void ClearBtn_Click(object sender, System.EventArgs e)
        {
            txtAllow.Text = "";
            txtBecause.Text = "";
            txtCause.Text = "";
            txtDesc.Text = "";
            txtSentence.Text = "";
            txtVendor.Text = "";
            txtVersion.Text = "";
            txtVia.Text = "";
            txtVul.Text = "";
            txtNote.Text = "";
            overview.Text = "";

            txtAllow.Refresh();
            txtBecause.Refresh();
            txtCause.Refresh();
            txtDesc.Refresh();
            txtSentence.Refresh();
            txtVendor.Refresh();
            txtVersion.Refresh();
            txtVia.Refresh();
            txtVul.Refresh();
            txtNote.Refresh();
            overview.Refresh();
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            string temp = overview.Text;
            //词组替换，例如将“along with”替换为“@along^with”
            PhraseReplace();

            overview.Refresh();

            //将overview中的文本，按照\r\n拆分为9段
            string FragmentStr = overview.Text;
            FragmentStr = FragmentStr.Replace("^","!#$%&*!#$%&*!#$%&*+");
            FragmentStr = FragmentStr.Replace("\r\n","^");
            string[] FragmentStrs = FragmentStr.Split('^');
            for (int k = 0; k < FragmentStrs.Count(); k++)
            {
                FragmentStrs[k] = FragmentStrs[k].Replace("!#$%&*!#$%&*!#$%&*+","^");
            }

            //检查拆分后是否为9段
            if (FragmentStrs.Count() == 9)
            {
                txtVul.Text = FragmentStrs[0];
                txtVendor.Text = FragmentStrs[1];
                txtDesc.Text = FragmentStrs[2];
                txtVersion.Text = FragmentStrs[3];
                txtBecause.Text = FragmentStrs[4];
                txtAllow.Text = FragmentStrs[5];
                txtCause.Text = FragmentStrs[6];
                txtVia.Text = FragmentStrs[7];
                txtNote.Text = FragmentStrs[8];

                //CreateTransFragment();
                CreateTransFragmentAt();
                overview.Text = temp;
                overview.Refresh();
            }
            else
            {
                MessageBox.Show("重新分组");
            }
        }


        //处理介词
        private void button3_Click(object sender, EventArgs e)
        {
            overview.Refresh();
            //CreateTransPreposition(overview.Text, "_nvd_dictionary", "_nvdDisOverview");
        }

        //词组替换
        private void phraseBtn_Click(object sender, EventArgs e)
        {
            PhraseReplace();
        }

        //词组替换
        public void PhraseReplace()
        {
            DataSet ds = new DataSet();
            string SQLSentence = string.Format("select * from _nvd_dic_phrase order by id");
            ds = DBManager2.OpSQLGetTable(SQLSentence);
            overview.Refresh();

            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                overview.Text = overview.Text.Replace((string)ds.Tables[0].Rows[k][1], (string)ds.Tables[0].Rows[k][2]);
            }

            overview.Refresh();
        }

        private void AddPhraseBtn_Click(object sender, EventArgs e)
        {
            CAddPhraseDlg addphrase = new CAddPhraseDlg();
            addphrase.Show();
        }

        string replace = "!#$%&*!#$%&*!#$%&*+";
        private void CreateFinalBtn_Click(object sender, EventArgs e)
        {
            //string str = txtSentence.Text.Replace("\r\n", " ");
            string str = txtSentence.Text.Replace("^",replace);
            str = txtSentence.Text.Replace("\r\n","^");
            string[] strshuiche = str.Split('^');
            for (int k = 0; k < strshuiche.Count(); k++)
            {
                strshuiche[k] = strshuiche[k].Replace(replace,"^");
            }
            str = strshuiche[0];
            for (int k = 1; k < strshuiche.Count();k++ )
            {
                if (strshuiche[k] == "")
                {
                    ;
                }
                else
                {
                    if (str.Contains("{*}"))
                        str = str.Replace("{*}", strshuiche[k]);
                    else
                        str = str + " " + strshuiche[k];
                }
            }

            while (str.Contains("  "))
            {
                str = str.Replace("  ", " ");
            }
            while (str.Contains(",,") || str.Contains(", ,"))
            {
                str = str.Replace(",,", ",");
                str = str.Replace(", ,", ",");
            }
            str = str.Trim();
            txtFinal.Text = str;

            string[] strspaces = txtFinal.Text.Split(' ');
            int num = strspaces.Count();
            string Sentence = strspaces[0];
            for (int k = 0; k < num - 2; k++)
            {
                //if (strspaces[k])
                string strspace1 = strspaces[k];
                string strspace2 = strspaces[k+1];
                char end = strspace1[strspace1.Count() - 1];
                char start = strspace2[0];
                int num1 = end;
                int num2 = start;
                if (num1 <= 127 || num2 <= 127)
                {
                    Sentence = Sentence + " " + strspaces[k + 1];
                }
                else
                {
                    Sentence = Sentence + strspaces[k + 1];
                }
            }
            Sentence = Sentence + strspaces[num-1];

            txtFinal.Text = Sentence;
            txtFinal.Refresh();
        }

        private void AddVol_Click(object sender, EventArgs e)
        {
            CAddVolDlg addVol = new CAddVolDlg();
            addVol.Show();
        }

        private void success_final_btn_Click(object sender, EventArgs e)
        {
            VolOverAll.strTrans = txtFinal.Text;
            VolOverAll.strTital = txtTital.Text;
            this.Close();
        }

        public string GetTital()
        {
            string tital = "";
            return tital;
        }
        //public string CreateTransPreposition(string str, string dictionary, string tempDic)
        //{
        //    if (str == "")
        //        return "";
        //    strs = Pro_String.pro_str(str);
        //    pro_overview(dictionary, tempDic);

        //    string SQLSentence = string.Format("select * from {0}", tempDic);
        //    dsGrip = DBManager2.OpSQLGetTable(SQLSentence);

        //    int lines = dsGrip.Tables[0].Rows.Count;

        //    List<string> listSegmentSmall = new List<string>();
        //    List<List<string>> listSegment = new List<List<string>>();
        //    string strb = "";
        //    string stre = "";
        //    for (int k = 0; k < lines; k++)
        //    {
        //        string strc = (string)dsGrip.Tables[0].Rows[k]["volc"];
        //        if (strc.Trim() == ", 通过")
        //        {
        //            List<string> listSegmentTemp = listSegmentSmall;
        //            listSegment.Add(listSegmentTemp);
        //        }
        //        else
        //        {
        //            listSegmentSmall.Add(strc);
        //        }
        //    }
        //    List<string> listSegmentTemp2 = listSegmentSmall;
        //    listSegment.Add(listSegmentTemp2);

        //    return chinese;
        //}
    }
}
