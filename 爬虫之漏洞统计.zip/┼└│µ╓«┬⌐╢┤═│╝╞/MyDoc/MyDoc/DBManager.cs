﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace MyDoc
{
    class DBManager
    {
        static public DataSet ds = new DataSet();
        static public DataSet ds1 = new DataSet();
        static public DataSet ds2 = new DataSet();
        static public DataSet dsMSName = new DataSet();
        static public DataSet dsMS1 = new DataSet();
        static public DataSet dsMS2 = new DataSet();
        static public DataSet dsMSSevere = new DataSet();
        static public bool ds1flag = false;
        static public bool dsflag = false;
        static public int GridRow = 0;
        static public int GridColumn = 0;
        static public int GridRow2 = 0;
        static public int GridColumn2 = 0;
        static public int flagtods = 0;
        static public bool severe = true;
        static public bool high = true;
        static public bool middle = true;
        static public bool low = true;
        static public string severestr = "xx";
        static public string highstr = "xx";
        static public string middlestr = "xx";
        static public string lowstr = "xx";
        static public int numSevere = 0;
        static public int numHigh = 0;
        static public int numMiddle = 0;
        static public int numLow = 0;
        static public int numTotal = 0;
        static public int numSevereLast = 0;
        static public int numHighLast = 0;
        static public int numMiddleLast = 0;
        static public int numLowLast = 0;
        static public int numTotalLast = 0;
        static public string datetimeLast = "";
        static public int numNetWork = 0;
        static public int numAdjection = 0;
        static public int numLocal = 0;

        static public string MSAtention = "";
        static public string MSSummary = "";
        //static public int AdNum = dsMS1.Tables[0].Rows.Count;
        //static public int CveNum = dsMS2.Tables[0].Rows.Count;
        //static public int[] AdCve = new int[200];
        static public int AdNum = 0;
        static public int CveNum = 0;
        static public int RankNum = 0;
        static public string[,] AdCve = new string[50, 3];
        //static public int RankNum = 0;
        //static public int MOffice = 0;
        //static public int MServer = 0;
        //static public int MWindows = 0;
        //static public int MExplorer = 0;
        //static public int MKaiFaGongJu = 0;
        //static public int MDNet = 0;
        //static public int MSilverlinght = 0;
        //static public int MFuWuQi = 0;
        //static public int MAnQuan = 0;
        //static public int MLync = 0;
        //static public int MRuanJianBao = 0;
        //static public int MVS = 0;

        static public bool statDate = false;
        static public bool statDateTime = false;

        static public bool[] month = new bool[12];
        static public int MSMonth = 0;

        static public bool IfUpdate = false;

        public static DataSet GetDataFromDB(string TableName)
        {
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            //ds = new DataSet();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    com.CommandType = CommandType.Text;
                    //com.CommandText = "select * from NVD where id > '20134900'";
                    severestr = "xx";
                    highstr = "xx";
                    middlestr = "xx";
                    lowstr = "xx";
                    if (severe == true)
                        severestr = "紧急";
                    if (high == true)
                        highstr = "高";
                    if (middle == true)
                        middlestr = "中";
                    if (low == true)
                        lowstr = "低";
                    string rankstr = string.Format("(rank='{0}' or rank='{1}' or rank='{2}' or rank='{3}')", severestr, highstr, middlestr, lowstr);
                    //com.CommandText = string.Format("select * from {0} where datetime >= '2013/10/12 14:42:10' {1}", TableName, rankstr);
                    com.CommandText = string.Format("select * from {0} where {1} order by datetime", TableName, rankstr);
                    com.Connection = con;

                    da = new SqlDataAdapter(com);
                    if (dsflag == true)
                        ds.Tables[0].Rows.Clear();
                    da.Fill(ds);
                    dsflag = true;

                    severestr = "xx";
                    highstr = "xx";
                    middlestr = "xx";
                    lowstr = "xx";
                }

                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("从表NVD读取数据失败");
                return ds;
            }
            finally
            {
                con.Close();
            }
        }

        public static int[] CountDataFromDB(string TableName, string statStartDate, string statEndDate, string statStartDateTime, string statEndDateTime, string NVDLog)
        {
            CountLastDataFromDB2(NVDLog);
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            string dateLimite = "";
            if(statDate==true)
                //dateLimite = string.Format("and Last_revised >= '{0}' and Last_revised <= '{1}'", statStartDate, statEndDate);
                dateLimite = string.Format("and Original_release_date >= '{0}' and Original_release_date <= '{1}'", statStartDate, statEndDate);
            string dateTimeLimite = "";
            string datetimestr1 = "";
            string datetimestr2 = "";
            if (statDateTime == true)
            {
                if (statStartDateTime != "")
                    datetimestr1 = string.Format("and datetime >= '{0}' ", statStartDateTime);
                else
                    datetimestr1 = string.Format("and datetime >= '{0}' ", datetimeLast);

                if (statEndDateTime != "")
                    datetimestr2 = string.Format("and datetime <= '{0}'", statEndDateTime);
                dateTimeLimite = datetimestr1 + datetimestr2;
            }                
            string comSevere = string.Format("select COUNT(*) from {0} where rank = '紧急' {1} {2}", TableName, dateLimite, dateTimeLimite);
            string comHigh = string.Format("select COUNT(*) from {0} where rank = '高' {1} {2}", TableName, dateLimite, dateTimeLimite);
            string comMiddle = string.Format("select COUNT(*) from {0} where rank = '中' {1} {2}", TableName, dateLimite, dateTimeLimite);
            string comLow = string.Format("select COUNT(*) from {0} where rank = '低' {1} {2}", TableName, dateLimite, dateTimeLimite);
            string comNetWork = string.Format("select COUNT(*) from {0} where strAV = '网络' {1} {2}", TableName, dateLimite, dateTimeLimite);
            string comAdjection = string.Format("select COUNT(*) from {0} where strAV = '局域网' {1} {2}", TableName, dateLimite, dateTimeLimite);
            string comLocal = string.Format("select COUNT(*) from {0} where strAV = '本地' {1} {2}", TableName, dateLimite, dateTimeLimite);
            SqlDataAdapter da = new SqlDataAdapter();
            //ds = new DataSet();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    com.CommandType = CommandType.Text;                    
                    com.Connection = con;

                    com.CommandText = comSevere;
                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    numSevere = dr.GetInt32(0);
                    dr.Close();

                    com.CommandText = comHigh;
                    dr = com.ExecuteReader();
                    dr.Read();
                    numHigh = dr.GetInt32(0);
                    dr.Close();

                    com.CommandText = comMiddle;
                    dr = com.ExecuteReader();
                    dr.Read();
                    numMiddle = dr.GetInt32(0);
                    dr.Close();

                    com.CommandText = comLow;
                    dr = com.ExecuteReader();
                    dr.Read();
                    numLow = dr.GetInt32(0);
                    dr.Close();

                    com.CommandText = comNetWork;
                    dr = com.ExecuteReader();
                    dr.Read();
                    numNetWork = dr.GetInt32(0);
                    dr.Close();

                    com.CommandText = comAdjection;
                    dr = com.ExecuteReader();
                    dr.Read();
                    numAdjection = dr.GetInt32(0);
                    dr.Close();

                    com.CommandText = comLocal;
                    dr = com.ExecuteReader();
                    dr.Read();
                    numLocal = dr.GetInt32(0);
                    dr.Close();

                    numTotal = numSevere + numMiddle + numHigh + numLow;
                }

                int[] ints = {numSevere, numHigh, numMiddle, numLow, numTotal};
                return ints;
            }
            catch (Exception ex)
            {
                MessageBox.Show("从表NVD2计算失败");
                int[] ints = { numSevere, numHigh, numMiddle, numLow, numTotal };
                return ints;
            }
            finally
            {
                con.Close();
            }
        }

        public static void IniAdCve()
        {
            for (int k = 0; k < 50; k++)
            {
                AdCve[k, 0] = "";
                AdCve[k, 1] = "";
                AdCve[k, 2] = "";
            }
            AdCve[0, 0] = "Microsoft_Office";
            AdCve[1, 0] = "Microsoft_Server_软件";
            AdCve[2, 0] = "Microsoft_Windows";
            AdCve[3, 0] = "Internet_Explorer";
            AdCve[4, 0] = "Microsoft_开发工具";
            AdCve[5, 0] = "Microsoft_DNET_Framework";
            AdCve[6, 0] = "Microsoft_Silverlight";
            AdCve[7, 0] = "Microsoft_服务器软件";
            AdCve[8, 0] = "Microsoft_安全软件";
            AdCve[9, 0] = "Microsoft_Lync";
            AdCve[10, 0] = "Microsoft_Windows_软件包";
            AdCve[11, 0] = "Microsoft_Visual_Studio";
        }

        public static void GetDataFromDBMS(bool isDouble)
        {
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            SqlCommand com2 = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();

            //int month = 10;
            string Monthstr = "";

            string comstr1;
            string comstr2;
            string comstrSevere;
            IniAdCve();

            if (isDouble == false)
            {
                Monthstr = string.Format("(month = {0})", MSMonth);
            }
            else
            {
                Monthstr = string.Format("(month = {0} or month = {1})", MSMonth, MSMonth - 1);
            }
            comstr1 = string.Format("select * from NVD_MS1 where {0}", Monthstr);
            comstr2 = string.Format("select * from NVD_MS2 where {0}", Monthstr);
            comstrSevere = string.Format("select * from NVD_MS1 where {0} and rank = '严重'", Monthstr);

            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    com.CommandType = CommandType.Text;
                    com.Connection = con;
                    com.CommandText = comstr1;
                    da = new SqlDataAdapter(com);
                    da.Fill(dsMS1);
                    com.CommandText = comstr2;
                    da.Fill(dsMS2);
                    com.CommandText = comstrSevere;
                    da.Fill(dsMSSevere);

                    AdNum = dsMS1.Tables[0].Rows.Count;
                    CveNum = dsMS2.Tables[0].Rows.Count;
                    RankNum = dsMSSevere.Tables[0].Rows.Count;

                    MSAtention = "此次微软发布的安全更新中为严重等级的公告如下，";
                    for (int k = 0; k < RankNum; k++)
                    {
                        MSAtention = MSAtention + "[*]" + (string)dsMS1.Tables[0].Rows[k]["adid"] + " "
                            + (string)dsMS1.Tables[0].Rows[k]["tital"] 
                            + (string)dsMS1.Tables[0].Rows[k]["summary"];
                    }

                    dsMS1 = new DataSet();
                    dsMS2 = new DataSet();
                    dsMSSevere = new DataSet();

                    com2.CommandType = CommandType.Text;
                    com2.Connection = con;
                    SqlDataReader dr2;
                    for (int k = 0; k < 12; k++)
                    {
                        string str = "";

                        str = string.Format("SELECT count(*) FROM NVD_MS1 where {0} and {1} = '1'", Monthstr, AdCve[k, 0]);
                        com2.CommandText = str;
                        dr2 = com2.ExecuteReader();
                        dr2.Read();
                        AdCve[k, 1] = dr2.GetInt32(0).ToString();
                        dr2.Close();

                        str = string.Format("select count(*) from NVD_MS2 where adid in (SELECT adid FROM NVD_MS1 where {0} and {1} = '1')", Monthstr, AdCve[k,0]);
                        com2.CommandText = str;
                        dr2 = com2.ExecuteReader();
                        dr2.Read();
                        AdCve[k,2] = dr2.GetInt32(0).ToString();
                        dr2.Close();
                    }
                }                
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show("从表NVD2计算失败");               
            }
            finally
            {
                con.Close();
            }
        }

        //public static void CountDataFromDBMS()
        //{
        //    if (dsMS1.Tables[0] != null && dsMS2.Tables[0]!=null)
        //    {
        //        AdNum = dsMS1.Tables[0].Rows.Count;
        //        CveNum = dsMS2.Tables[0].Rows.Count;
        //        RankNum = dsMSSevere.Tables[0].Rows.Count;
                  

        //        MSAtention = "";
        //        for (int k = 0; k < RankNum; k++)
        //        {
        //            MSAtention = MSAtention + (string)dsMS1.Tables[0].Rows[k]["tital"] + "[*]解决了" + (string)dsMS1.Tables[0].Rows[k]["summary"];
        //        }                               
        //    }
        //}

        //public static void CountDataFromDBMS2()
        //{
        //    if (dsMS1.Tables[0] != null && dsMS2.Tables[0]!=null)
        //    {
        //        int AdNum = dsMS1.Tables[0].Rows.Count;
        //        int CveNum = dsMS2.Tables[0].Rows.Count;
        //        int[] AdCve = new int[AdNum];
        //        for(int j=0;j<AdNum;j++)
        //        {
        //            AdCve[j] = 0;
        //        }
                    
        //        int RankNum = 0;
        //        int MOffice = 0;
        //        int MServer = 0;
        //        int MWindows = 0;
        //        int MExplorer = 0;
        //        int MKaiFaGongJu = 0;
        //        int MDNet = 0;
        //        int MSilverlinght = 0;
        //        int MFuWuQi = 0;
        //        int MAnQuan = 0;
        //        int MLync = 0;
        //        int MRuanJianBao = 0;
        //        int MVS = 0;
        //        MSAtention = "";
        //        MSSummary = "";
        //        for (int k = 0; k < AdNum; k++)
        //        {
        //            if (dsMS1.Tables[0].Rows[k]["rank"] == "严重"){
        //                RankNum = RankNum + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Office"]=="1"){
        //                MOffice = MOffice + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Server_软件"]=="1"){
        //                MServer = MServer + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Windows"]=="1"){
        //                MWindows = MWindows + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Internet_Explorer"]=="1"){
        //                MExplorer = MExplorer + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_开发工具"]=="1"){
        //                MKaiFaGongJu = MKaiFaGongJu + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_DNET_Framework"]=="1"){
        //                MDNet = MDNet + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Silverlight"]=="1"){
        //                MSilverlinght = MSilverlinght + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_服务器软件"]=="1"){
        //                MFuWuQi = MFuWuQi + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_安全软件"]=="1"){
        //                MAnQuan = MAnQuan + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Lync"]=="1"){
        //                MLync = MLync + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Windows_软件包"]=="1"){
        //                MRuanJianBao = MRuanJianBao + 1;
        //            }
        //            if (dsMS1.Tables[0].Rows[k]["Microsoft_Visual_Studio"] == "1")
        //            {
        //                MVS = MVS + 1;
        //            }

        //            string distr = (string)dsMS1.Tables[0].Rows[k]["adid"];
        //            for (int h = 0; h < CveNum; h++)
        //            {
        //                if (dsMS1.Tables[0].Rows[k]["adid"] == distr)
        //                    AdCve[k] = AdCve[k] + 1;
        //            }

        //            MSAtention = MSAtention + (string)dsMS1.Tables[0].Rows[k]["tital"] + "[*]解决了" + (string)dsMS1.Tables[0].Rows[k]["summary"];
        //            string str1 = string.Format("微软公司发布的{0}项安全更新，共修复{1}个漏洞，{2}个安全公告等级为“严重”，其余为“重要”。", AdNum, CveNum, RankNum);
        //            //string str2 = string.Format("有{0}项安全公告针对office漏洞，涉及{1}个漏洞", );
        //        }
                                
        //    }
        //}

        public static string MyNow()
        {
            string NowYear = DateTime.Now.Year.ToString();
            string NowMonth = DateTime.Now.Month.ToString();
            if (NowMonth.Count() < 2)
                NowMonth = "0" + NowMonth;
            string NowDay = DateTime.Now.Day.ToString();
            if (NowDay.Count() < 2)
                NowDay = "0" + NowDay;
            string NowHour = DateTime.Now.Hour.ToString();
            if (NowHour.Count() < 2)
                NowHour = "0" + NowHour;
            string NowMinute = DateTime.Now.Minute.ToString();
            if (NowMinute.Count() < 2)
                NowMinute = "0" + NowMinute;
            string NowSecond = DateTime.Now.Second.ToString();
            if (NowSecond.Count() < 2)
                NowSecond = "0" + NowSecond;
            string strNow = NowYear + "/" + NowMonth + "/" + NowDay + " " + NowHour + ":" + NowMinute + ":" + NowSecond;

            return strNow;
        }

        public static void CountLastDataFromDB(string NVDLog)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = "select * from " + NVDLog + " order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    dscl.Tables[0].Rows.Add();
                    int k = dscl.Tables[0].Rows.Count;
                    dscl.Tables[0].Rows[k - 1][0] = k;
                    //dscl.Tables[0].Rows[k - 1][1] = DateTime.Now;
                    dscl.Tables[0].Rows[k - 1][1] = MyNow();
                    dscl.Tables[0].Rows[k - 1][2] = (int)dscl.Tables[0].Rows[k - 2][3] + 1;
                    dscl.Tables[0].Rows[k - 1][3] = (int)dscl.Tables[0].Rows[k - 2][3] + DBManager.numTotal;
                    dscl.Tables[0].Rows[k - 1][4] = DBManager.numTotal;
                    dscl.Tables[0].Rows[k - 1][5] = DBManager.numLow;
                    dscl.Tables[0].Rows[k - 1][6] = DBManager.numMiddle;
                    dscl.Tables[0].Rows[k - 1][7] = DBManager.numHigh;
                    dscl.Tables[0].Rows[k - 1][8] = DBManager.numSevere;

                    DBManager.numTotalLast = (int)dscl.Tables[0].Rows[k - 2][4];
                    DBManager.numLowLast = (int)dscl.Tables[0].Rows[k - 2][5];
                    DBManager.numMiddleLast = (int)dscl.Tables[0].Rows[k - 2][6];
                    DBManager.numHighLast = (int)dscl.Tables[0].Rows[k - 2][7];
                    DBManager.numSevereLast = (int)dscl.Tables[0].Rows[k - 2][8];
                    DBManager.datetimeLast = (string)dscl.Tables[0].Rows[k - 2]["datetime"];

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    if (IfUpdate == true)
                    {
                        da.Update(dscl);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void CountLastDataFromDB2(string NVDLog)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = "select * from " + NVDLog + " order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    int k = dscl.Tables[0].Rows.Count;
                    DBManager.datetimeLast = (string)dscl.Tables[0].Rows[k - 1]["datetime"];
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static DataSet GetDataFromDBMS()
        {
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            string comstr;

            string monthstr = SetMonth();
            string Monthstr = "";
            

            Monthstr = string.Format("month in ({0})", monthstr);

            comstr = string.Format("select * from NVD_MS2 where {0}", Monthstr);

            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    com.CommandType = CommandType.Text;
                    com.Connection = con;
                    com.CommandText = comstr;
                    da = new SqlDataAdapter(com);
                    da.Fill(dsMSName);
                }
                return dsMSName;
            }
            catch (Exception ex)
            {
                MessageBox.Show("MS2读取失败");
                return dsMSName;
            }
            finally
            {
                con.Close();
            }
        }

        public static string SetMonth()
        {
            string monthstr = "0";
            for (int k = 0; k < 12; k++)
            {
                if (month[k])
                    monthstr = monthstr + "," + (k + 1).ToString();
            }
            return monthstr;
        }
    }
}
