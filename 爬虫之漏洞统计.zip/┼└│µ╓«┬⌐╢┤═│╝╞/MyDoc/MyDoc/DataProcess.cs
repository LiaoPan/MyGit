﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
//using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;

namespace MyDoc
{
    class DataProcess
    {
        DataSet ds;// = new DataSet();
        public void GetDataFromDB()
        {
            SqlConnection con = new SqlConnection();
            SqlCommand com = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            ds = new DataSet();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {                   
                    com.CommandType = CommandType.Text;
                    //com.CommandText = "select * from NVD where id > '20134900'";
                    com.CommandText = "select * from NVD";
                    com.Connection = con;

                    da = new SqlDataAdapter(com);
                    da.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("从表NVD读取数据失败");
            }
            finally
            {
                con.Close();
            }
        }

        public string CVEPro(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][4];
            string temp = str.Substring(26,13);
            //string temp = str.Substring(71, 13);
            return temp;
        }

        public string OriginalReleaseDatePro(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][5];
            if (str != "")
            {
                string temp1 = str.Substring(0, 2);
                if (temp1.Count() == 1)
                    temp1 = "0" + temp1;
                string temp2 = str.Substring(3, 2);
                if (temp2.Count() == 1)
                    temp2 = "0" + temp2;
                string temp3 = str.Substring(6, 4);
                string temp = temp3 + "/" + temp1 + "/" + temp2;
                return temp;
            }
            else
            {
                return str;
            }
        }

        public string LastRevisedPro(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][6];
            if (str != "")
            {
                string temp1 = str.Substring(0, 2);
                if (temp1.Count() == 1)
                    temp1 = "0" + temp1;
                string temp2 = str.Substring(3, 2);
                if (temp2.Count() == 1)
                    temp2 = "0" + temp2;
                string temp3 = str.Substring(6, 4);
                string temp = temp3 + "/" + temp1 + "/" + temp2;
                return temp;
            }
            else 
            {
                return str;
            }
        }

        public string[] CVSS_String(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][12];
            string[] temp = new string[6];
            for (int k = 0; k < 6; k++)
            {
                temp[k] = "";
            }

            if (str.Length >= 26)
            {
                string temp1 = str.Substring(4, 1);
                string temp2 = str.Substring(9, 1);
                string temp3 = str.Substring(14, 1);
                string temp4 = str.Substring(18, 1);
                string temp5 = str.Substring(22, 1);
                string temp6 = str.Substring(26, 1);
                if (temp1 == "N")
                {
                    temp1 = "网络";
                }
                else if (temp1 == "A")
                {
                    temp1 = "局域网";
                }
                else if (temp1 == "L")
                {
                    temp1 = "本地";
                }
                else
                {
                    temp1 = "未知";
                }

                if (temp2 == "H")
                {
                    temp2 = "高";
                }
                else if (temp2 == "M")
                {
                    temp2 = "中";
                }
                else if (temp2 == "L")
                {
                    temp2 = "低";
                }
                else
                {
                    temp2 = "未知";
                }

                if (temp3 == "N")
                {
                    temp3 = "没有";
                }
                else if (temp3 == "S")
                {
                    temp3 = "单个实例";
                }
                else if (temp3 == "M")
                {
                    temp3 = "多个实例";
                }
                else
                {
                    temp3 = "未知";
                }

                if (temp4 == "C")
                {
                    temp4 = "整体";
                }
                else if (temp4 == "P")
                {
                    temp4 = "部分";
                }
                else if (temp4 == "N")
                {
                    temp4 = "没有";
                }
                else
                {
                    temp4 = "未知";
                }

                if (temp5 == "C")
                {
                    temp5 = "整体";
                }
                else if (temp5 == "P")
                {
                    temp5 = "部分";
                }
                else if (temp5 == "N")
                {
                    temp5 = "没有";
                }
                else
                {
                    temp5 = "未知";
                }

                if (temp6 == "C")
                {
                    temp6 = "整体";
                }
                else if (temp6 == "P")
                {
                    temp6 = "部分";
                }
                else if (temp6 == "N")
                {
                    temp6 = "没有";
                }
                else
                {
                    temp6 = "未知";
                }

                //string temp;
                //temp = "被攻击范围: " + temp1 + "\n"
                //     + "攻击复杂度: " + temp2 + "\n"
                //     + "所需授权度: " + temp3 + "\n"
                //     + "影响机密性: " + temp4 + "\n"
                //     + "影响完整性: " + temp5 + "\n"
                //     + "影响可用性: " + temp6 + "\n";
                temp[0] = temp1;
                temp[1] = temp2;
                temp[2] = temp3;
                temp[3] = temp4;
                temp[4] = temp5;
                temp[5] = temp6;

                return temp;
            }

            return temp;
        }

        public string ScoreRank(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][13];
            if (str.Length > 1)
            {
                string temp = str.Substring(1, str.Count() - 2);
                return temp;
            }
            return "没有值";
        }

        public string[] volclass(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][16];

            string substr = "\n";
            int flag = str.IndexOf(substr, 0);
            while(flag != -1)
            {
                str = str.Remove(flag, 1);
                flag = str.IndexOf(substr, 0);
            }
            
            string name = "";
            string cause = "";
            switch(str)
            {
                case  "Authentication Issues (CWE-287)": 
                    cause = "没有正确对用户进行认证";
                    name = "认证错误" + " [" + str + "]"; break;
                case  "Credentials Management (CWE-255)": 
                    cause = "创建、存储、传输、或保护口令和其他证书失败";
                    name = "证书管理错误" + " [" + str + "]"; break;
                case  "Permissions, Privileges, and Access Control (CWE-264)": 
                    cause = "没有对资源进行正确的访问限制，或权限管理有误";
                    name = "许可，权限和访问控制错误" + " [" + str + "]"; break;
                case  "Buffer Errors (CWE-119)": 
                    cause = "对内存缓冲区的创建、修改、管理或删除有误";
                    name = "缓冲区错误" + " [" + str + "]"; break;
                case  "Cross-Site Request Forgery (CSRF) (CWE-352)": 
                    cause = "对输入参数未进行正确的限制";
                    name = "跨站请求伪造" + " [" + str + "]"; break;
                case  "Cross-Site Scripting (XSS) (CWE-79)": 
                    cause = "对输入参数未进行正确的限制";
                    name = "跨站脚本" + " [" + str + "]"; break;
                case  "Path Traversal (CWE-22)": 
                    cause = "对输入参数未进行正确的限制";
                    name = "目录遍历" + " [" + str + "]"; break;
                case  "SQL Injection (CWE-89)": 
                    cause = "对输入参数未进行正确的限制";
                    name = "SQL注入" + " [" + str + "]"; break;
                case  "Input Validation (CWE-20)": 
                    cause = "对输入参数未进行正确的限制";
                    name = "输入验证错误" + " [" + str + "]"; break;
                case  "Cryptographic Issues (CWE-310)": 
                    cause = "不安全的算法或对算法的不当使用";
                    name = "加密错误" + " [" + str + "]"; break;
                case  "Code Injection (CWE-94)": 
                    cause = "系统读取攻击者控制的文件，并执行该文件中的任意代码";
                    name = "代码注入" + " [" + str + "]"; break;
                case  "Format String Vulnerability (CWE-134)": 
                    cause = "某些函数中使用了可以从外部控制的格式字符串";
                    name = "格式字符串漏洞" + " [" + str + "]"; break;
                case  "Configuration (CWE-16)": 
                    cause = "与口令和许可无关的通用组态问题";
                    name = "配置错误" + " [" + str + "]"; break;
                case  "Information Leak / Disclosure (CWE-200)": 
                    cause = "系统信息、敏感信息或私人信息泄露";
                    name = "信息泄露" + " [" + str + "]"; break;
                case  "Numeric Errors (CWE-189)": 
                    cause = "处理数值时出现整数溢出、符号截断等错误";
                    name = "数值错误" + " [" + str + "]"; break;
                case  "OS Command Injections (CWE-78)":
                    cause = "将用户控制的输入注入到命令行中";
                    name = "操作系统命令注入" + " [" + str + "]"; break;
                case  "Race Conditions (CWE-362)": 
                    cause = "资源在被检查和访问时状态发生变化";
                    name = "竞争条件错误" + " [" + str + "]"; break;
                case  "Resource Management Errors (CWE-399)": 
                    cause = "没有正确管理系统资源";
                    name = "资源管理错误" + " [" + str + "]"; break;
                case  "Link Following (CWE-59)": 
                    cause = "未能防止使用指向不应被应用访问的文件的符号或硬链接";
                    name = "链接跟随错误" + " [" + str + "]"; break;
                case "Other (NVD-CWE-Other)": 
                    cause = "未知";
                    name = "其他" + " [" + str + "]"; break;
                case  "Insufficient Information (NVD-CWE-noinfo)": 
                    cause = "未知";
                    name = "信息不足" + " [" + str + "]"; break;
                case "Design Error (NVD-CWE-DesignError)":                   
                    cause = "系统初始设计有误";
                    name = "设计错误" + " [" + str + "]"; break;
                default:
                    //MessageBox.Show("没有这个类型");
                    break;
            }

            string[] strs = { name, cause };
            return strs;
        }


        public string ref_1(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][17];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_2(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][18];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_3(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][19];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_4(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][20];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_5(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][21];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_6(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][22];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_7(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][23];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_8(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][24];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_9(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][25];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string ref_10(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][26];
            string find = "Hyperlink:\n";
            int k = str.IndexOf(find);
            string temp = "";
            if (k >= 0)
            {
                temp = str.Substring(k + 11);
            }

            //string temp = str.Substring(1, str.Count() - 2);
            return temp;
        }

        public string translations_s(int i)
        {
            string str1 = (string)ds.Tables[0].Rows[i][5];
            string str2 = (string)ds.Tables[0].Rows[i][9];
            string temp = str1 + str2;
            return temp;
        }

        public string Impact(int i)
        {
            string str1 = (string)ds.Tables[0].Rows[i][5];
            string str2 = (string)ds.Tables[0].Rows[i][14];
            string temp = str1 + str2;
            return temp;
        }

        public string rank(int i)
        {
            string str = (string)ds.Tables[0].Rows[i][9];
            string temp = "";
            if (str == "")
            {
                temp = "未知";
                return temp;
            }
            float k = float.Parse(str);
            if (k >= 0 && k < 4)
            {
                temp = "低";
            }
            else if (k >= 4 && k < 7)
            {
                temp = "中";
            }
            else if (k >= 7 && k < 9)
            {
                temp = "高";
            }
            else if (k >= 9 && k <= 10)
            {
                temp = "紧急";
            }
            else
            {
                temp = "未知";
            }          

            return temp;
        }

        public void SetAdvisory()
        {
            int num = ds.Tables[0].Rows.Count;
            int numCo = ds.Tables[0].Columns.Count;
            for (int i = 0; i < num; i++)
            {
                Advisory advisory = new Advisory();
                string SectionName = "";
                string SectionValue = "";
                for (int j = 0; j < numCo; j++)
                {
                    SectionName = ds.Tables[0].Columns[j].ColumnName;
                    SectionValue = (string)ds.Tables[0].Rows[i][j];
                    advisory.AddSection(SectionName, SectionValue, j);
                }

                //cve
                SectionName = ds.Tables[0].Columns[4].ColumnName;
                SectionValue = CVEPro(i);                
                advisory.AddSection(SectionName, SectionValue, 4);

                //time
                SectionName = ds.Tables[0].Columns[5].ColumnName;
                SectionValue = OriginalReleaseDatePro(i);
                advisory.AddSection(SectionName, SectionValue, 5);

                //time
                SectionName = ds.Tables[0].Columns[6].ColumnName;
                SectionValue = LastRevisedPro(i);
                advisory.AddSection(SectionName, SectionValue, 6);

                //[ScoreRank]
                SectionName = ds.Tables[0].Columns[13].ColumnName;
                SectionValue = ScoreRank(i);
                advisory.AddSection(SectionName, SectionValue, 13);

                //[volclass]
                SectionName = ds.Tables[0].Columns[16].ColumnName;
                SectionValue = volclass(i)[0];
                advisory.AddSection(SectionName, SectionValue, 16);

                //[ref_1]
                SectionName = ds.Tables[0].Columns[17].ColumnName;
                SectionValue = ref_1(i);
                advisory.AddSection(SectionName, SectionValue, 17);

                //[ref_2]
                SectionName = ds.Tables[0].Columns[18].ColumnName;
                SectionValue = ref_2(i);
                advisory.AddSection(SectionName, SectionValue, 18);

                //[ref_3]
                SectionName = ds.Tables[0].Columns[19].ColumnName;
                SectionValue = ref_3(i);
                advisory.AddSection(SectionName, SectionValue, 19);

                //[ref_4]
                SectionName = ds.Tables[0].Columns[20].ColumnName;
                SectionValue = ref_4(i);
                advisory.AddSection(SectionName, SectionValue, 20);

                //[ref_5]
                SectionName = ds.Tables[0].Columns[21].ColumnName;
                SectionValue = ref_5(i);
                advisory.AddSection(SectionName, SectionValue, 21);

                //[ref_6]
                SectionName = ds.Tables[0].Columns[22].ColumnName;
                SectionValue = ref_6(i);
                advisory.AddSection(SectionName, SectionValue, 22);

                //[ref_7]
                SectionName = ds.Tables[0].Columns[23].ColumnName;
                SectionValue = ref_7(i);
                advisory.AddSection(SectionName, SectionValue, 23);

                //[ref_8]
                SectionName = ds.Tables[0].Columns[24].ColumnName;
                SectionValue = ref_8(i);
                advisory.AddSection(SectionName, SectionValue, 24);

                //[ref_9]
                SectionName = ds.Tables[0].Columns[25].ColumnName;
                SectionValue = ref_9(i);
                advisory.AddSection(SectionName, SectionValue, 25);

                //[ref_10]
                SectionName = ds.Tables[0].Columns[26].ColumnName;
                SectionValue = ref_10(i);
                advisory.AddSection(SectionName, SectionValue, 26);

                //[translations]
                SectionName = "translations";
                SectionValue = translations_s(i);
                advisory.AddSection(SectionName, SectionValue, 27);

                //[Impact]
                SectionName = "Impact";
                SectionValue = Impact(i);
                advisory.AddSection(SectionName, SectionValue, 28);

                //[CVSS_v2_Base_Score_String]
                SectionName = "strAV";
                SectionValue = CVSS_String(i)[0];
                advisory.AddSection(SectionName, SectionValue, 29);
                SectionName = "strAC";
                SectionValue = CVSS_String(i)[1];
                advisory.AddSection(SectionName, SectionValue, 30);
                SectionName = "strAu";
                SectionValue = CVSS_String(i)[2];
                advisory.AddSection(SectionName, SectionValue, 31);
                SectionName = "strC";
                SectionValue = CVSS_String(i)[3];
                advisory.AddSection(SectionName, SectionValue, 32);
                SectionName = "strI";
                SectionValue = CVSS_String(i)[4];
                advisory.AddSection(SectionName, SectionValue, 33);
                SectionName = "strA";
                SectionValue = CVSS_String(i)[5];
                advisory.AddSection(SectionName, SectionValue, 34);

                //[rank]
                SectionName = "rank";
                SectionValue = rank(i);
                advisory.AddSection(SectionName, SectionValue, 35);

                //[name]
                SectionName = "volname";
                SectionValue = CVEPro(i);
                advisory.AddSection(SectionName, SectionValue, 36);

                //[volcause]
                SectionName = "volcause";
                SectionValue = volclass(i)[1];
                advisory.AddSection(SectionName, SectionValue, 37);

                AdvisoryList.Instance.Add(advisory);
            }

        }

        private bool InsertAdvisory(Advisory advisory)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";

            string[,] xmlSections = new string[100, 3];
            int iSection = 0;

            try
            {
                con.Open();
                for (iSection = 0; iSection < 100; iSection++)
                {
                    if (advisory.xmlSections[iSection, 0] == "")
                    {
                        break;
                    }
                }
                int totaliSections = 0;
                totaliSections = iSection;

                for (iSection = 0; iSection < totaliSections; iSection++)
                {
                    xmlSections[iSection, 0] = advisory.xmlSections[iSection, 0];
                    xmlSections[iSection, 1] = advisory.xmlSections[iSection, 1];
                    if (xmlSections[iSection, 1] != "" && xmlSections[iSection, 1] != null)
                        xmlSections[iSection, 1] = xmlSections[iSection, 1].Replace("'", "\"");
                }

                string columns_2 = null;
                string values_2 = null;
                string cmd = "";
                for (iSection = 0; iSection < totaliSections - 1; iSection++)
                {
                    columns_2 += string.Format("{0}, ", xmlSections[iSection, 0]);
                    values_2 += string.Format("'{0}', ", xmlSections[iSection, 1]);
                }
                columns_2 += string.Format("{0}", xmlSections[iSection, 0]);
                values_2 += string.Format("'{0}'", xmlSections[iSection, 1]);                

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.Connection = con;
                    cmd = string.Format("insert into {0} ({1}) values ({2})", "NVD2", columns_2, values_2);
                    com.CommandText = cmd;
                    com.Connection = con;
                    com.ExecuteNonQuery();
                }

                return true;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("加入数据库失败");
                return false;
            }
            finally
            {
                con.Close();
            }

        }

        public bool InsertIntoAdvisory()
        {
            try
            {
                int info_error = 0;
                foreach (Advisory advisory in AdvisoryList.Instance)
                {
                    bool ok = false;
                    ok = InsertAdvisory(advisory);
                    if (ok == false)
                        info_error = info_error + 1;
                }

                int info = AdvisoryList.Instance.Count;
                int info_success = info - info_error;
                string info_InsertAdvisory = info_success.ToString() + "提交成功     " + info_error.ToString() + "提交失败";
                MessageBox.Show(info_InsertAdvisory);
                return true;
            }
            catch (Exception ex)
            {
                //LogDbError(ex);
                return false;
            }
        }

        public void AdvisoryPro()
        {
            GetDataFromDB();

            if (ds == null)
            {
                MessageBox.Show("DataSet为NULL");
                return;
            }

            SetAdvisory();
            InsertIntoAdvisory();            
        }


    }
}
