﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace MyDoc
{
    public class VolOverAll
    {
        // VolOverAll的唯一实例
        //private static VolOverAll _instance = new VolOverAll();
        public static bool AutoSumbit = false;
        public static int ForSubmit = 20;
        public static bool coloumflag = false;
        //public int tatoliSections = 100;
        //public static string[] ArrayOver = new string[500];
        public static List<string> ArrayOver = new List<string>();
        //public static string DataBaseName = "W_NVD3B1";
        ////public static string DateBaseIP = "124.16.70.204";
        ////public static string DataBaseIP = "192.168.1.102";
        //public static string DataBaseIP = "127.0.0.1";
        //public static string DataUid = "sa";
        //public static string DataPassword = "sqlserver";
        //public static List<string[]> AdvisoryProducts = new List<string[]>(); 
        public static string TestText = "";
        public static int textBox_Num = 0;
        public static bool Pause = true;
        public static bool WebCheckOver = true;
        //public static Site OverAllSite;
        public static int idLinks = 1;
        public static int idPocLinks = 1;
        public static string HttpBefore = "";
        public static string DataBaseNameLink = "";
        public static string DataBaseWhere = "";
        //public static BindingList<string[]> strIndex = new BindingList<string[]>();
        public static bool isErrorUpdate = false;
        public static bool isInsertWhenNone = false;
        public static bool isPoc = false;
        public static string downloadpath = "d://SecurityFocus//";
        public static string OverAllOverview = "";
        public static string Allows = "";
        //字段名，ProOverview类和CDlgTranslations类用到
        public static string Field = "";
        //全局的sql语句，ProOverview类和CDlgTranslations类用到
        public static string SQLSentence = "";
        //ProOverview要处理的string，ProOverview类和CDlgTranslations类用到
        public static string ProString = "";
        public static string attackers = "@attacker@user@server@administrator@application@site@applet@it@client@admin@file@operator@role@author@process@node@page@code@kernel@module@program@gateway@moderator@packet@editor@relay@webmaster@session@attack@router@point@community@cookie@email@intruder@class@header@Javascript@educator@keyserver@mirror site@hub@";

        public static string strOverview = "";
        public static string strTrans = "";
        public static string strTital = "";
        public static string strMessage = "";
        public static string strCause = "";

        public static string DataBaseName = "W_NVD3B1";
        public static string DataBaseName_db3 = "NVD";
        public static string DataBaseIP = "127.0.0.1";
        public static string DataBaseIP_db3 = "127.0.0.1";
        public static string DataUid = "sa";
        public static string DataUid_db3 = "sa";
        public static string DataPassword = "sqlserver";
        public static string DataPassword_db3 = "sqlserver";

        public static string DataBaseName_db4 = "nipc";
        //public static string DataBaseIP_db4 = "124.16.71.27";
        public static string DataBaseIP_db4 = "124.16.71.236";
        public static string DataUid_db4 = "sa";
        public static string DataPassword_db4 = "N^%$#@!";
		// 使用单例模式
        private VolOverAll() { }

        //public static VolOverAll Instance
        //{
        //    get { return _instance; }
        //}

    }
}
