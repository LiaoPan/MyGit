﻿namespace MyDoc
{
    partial class Translations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Translations));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.OverView = new System.Windows.Forms.TextBox();
            this.保存 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.add = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.loading = new System.Windows.Forms.Button();
            this.刷新 = new System.Windows.Forms.Button();
            this.DocWeek = new System.Windows.Forms.Button();
            this.textCVE = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.texttrans = new System.Windows.Forms.TextBox();
            this.修改 = new System.Windows.Forms.Button();
            this.renyidaimazhixing = new System.Windows.Forms.CheckBox();
            this.xinxixielu = new System.Windows.Forms.CheckBox();
            this.quanxiantisheng = new System.Windows.Forms.CheckBox();
            this.jujuefuwu = new System.Windows.Forms.CheckBox();
            this.weizhi = new System.Windows.Forms.CheckBox();
            this.addCVE = new System.Windows.Forms.Button();
            this.ExcelToMS = new System.Windows.Forms.Button();
            this.Translations2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(1190, 315);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEnter);
            // 
            // OverView
            // 
            this.OverView.Location = new System.Drawing.Point(12, 490);
            this.OverView.Multiline = true;
            this.OverView.Name = "OverView";
            this.OverView.Size = new System.Drawing.Size(388, 81);
            this.OverView.TabIndex = 1;
            // 
            // 保存
            // 
            this.保存.Location = new System.Drawing.Point(1110, 490);
            this.保存.Name = "保存";
            this.保存.Size = new System.Drawing.Size(75, 23);
            this.保存.TabIndex = 2;
            this.保存.Text = "保存";
            this.保存.UseVisualStyleBackColor = true;
            this.保存.Click += new System.EventHandler(this.保存_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView2.Location = new System.Drawing.Point(0, 315);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(1190, 169);
            this.dataGridView2.TabIndex = 3;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellEnter);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(1110, 519);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 23);
            this.add.TabIndex = 4;
            this.add.Text = "add";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(1110, 577);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 5;
            this.delete.Text = "delete";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // loading
            // 
            this.loading.Location = new System.Drawing.Point(403, 656);
            this.loading.Name = "loading";
            this.loading.Size = new System.Drawing.Size(75, 23);
            this.loading.TabIndex = 6;
            this.loading.Text = "loading";
            this.loading.UseVisualStyleBackColor = true;
            this.loading.Click += new System.EventHandler(this.load_Click);
            // 
            // 刷新
            // 
            this.刷新.Location = new System.Drawing.Point(484, 656);
            this.刷新.Name = "刷新";
            this.刷新.Size = new System.Drawing.Size(75, 23);
            this.刷新.TabIndex = 7;
            this.刷新.Text = "刷新";
            this.刷新.UseVisualStyleBackColor = true;
            this.刷新.Click += new System.EventHandler(this.刷新_Click);
            // 
            // DocWeek
            // 
            this.DocWeek.Location = new System.Drawing.Point(565, 656);
            this.DocWeek.Name = "DocWeek";
            this.DocWeek.Size = new System.Drawing.Size(75, 23);
            this.DocWeek.TabIndex = 8;
            this.DocWeek.Text = "生成报告";
            this.DocWeek.UseVisualStyleBackColor = true;
            this.DocWeek.Click += new System.EventHandler(this.DocWeek_Click);
            // 
            // textCVE
            // 
            this.textCVE.Location = new System.Drawing.Point(405, 492);
            this.textCVE.Name = "textCVE";
            this.textCVE.Size = new System.Drawing.Size(353, 21);
            this.textCVE.TabIndex = 9;
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(406, 519);
            this.textName.Multiline = true;
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(352, 52);
            this.textName.TabIndex = 10;
            // 
            // texttrans
            // 
            this.texttrans.Location = new System.Drawing.Point(764, 492);
            this.texttrans.Multiline = true;
            this.texttrans.Name = "texttrans";
            this.texttrans.Size = new System.Drawing.Size(259, 79);
            this.texttrans.TabIndex = 12;
            // 
            // 修改
            // 
            this.修改.Location = new System.Drawing.Point(12, 577);
            this.修改.Name = "修改";
            this.修改.Size = new System.Drawing.Size(75, 23);
            this.修改.TabIndex = 13;
            this.修改.Text = "修改";
            this.修改.UseVisualStyleBackColor = true;
            this.修改.Click += new System.EventHandler(this.修改_Click);
            // 
            // renyidaimazhixing
            // 
            this.renyidaimazhixing.AutoSize = true;
            this.renyidaimazhixing.Location = new System.Drawing.Point(406, 577);
            this.renyidaimazhixing.Name = "renyidaimazhixing";
            this.renyidaimazhixing.Size = new System.Drawing.Size(96, 16);
            this.renyidaimazhixing.TabIndex = 14;
            this.renyidaimazhixing.Text = "任意代码执行";
            this.renyidaimazhixing.UseVisualStyleBackColor = true;
            // 
            // xinxixielu
            // 
            this.xinxixielu.AutoSize = true;
            this.xinxixielu.Location = new System.Drawing.Point(406, 599);
            this.xinxixielu.Name = "xinxixielu";
            this.xinxixielu.Size = new System.Drawing.Size(72, 16);
            this.xinxixielu.TabIndex = 15;
            this.xinxixielu.Text = "信息泄露";
            this.xinxixielu.UseVisualStyleBackColor = true;
            // 
            // quanxiantisheng
            // 
            this.quanxiantisheng.AutoSize = true;
            this.quanxiantisheng.Location = new System.Drawing.Point(508, 577);
            this.quanxiantisheng.Name = "quanxiantisheng";
            this.quanxiantisheng.Size = new System.Drawing.Size(72, 16);
            this.quanxiantisheng.TabIndex = 16;
            this.quanxiantisheng.Text = "权限提升";
            this.quanxiantisheng.UseVisualStyleBackColor = true;
            // 
            // jujuefuwu
            // 
            this.jujuefuwu.AutoSize = true;
            this.jujuefuwu.Location = new System.Drawing.Point(508, 599);
            this.jujuefuwu.Name = "jujuefuwu";
            this.jujuefuwu.Size = new System.Drawing.Size(72, 16);
            this.jujuefuwu.TabIndex = 17;
            this.jujuefuwu.Text = "拒绝服务";
            this.jujuefuwu.UseVisualStyleBackColor = true;
            // 
            // weizhi
            // 
            this.weizhi.AutoSize = true;
            this.weizhi.Location = new System.Drawing.Point(586, 577);
            this.weizhi.Name = "weizhi";
            this.weizhi.Size = new System.Drawing.Size(48, 16);
            this.weizhi.TabIndex = 18;
            this.weizhi.Text = "未知";
            this.weizhi.UseVisualStyleBackColor = true;
            // 
            // addCVE
            // 
            this.addCVE.Location = new System.Drawing.Point(1110, 548);
            this.addCVE.Name = "addCVE";
            this.addCVE.Size = new System.Drawing.Size(75, 23);
            this.addCVE.TabIndex = 19;
            this.addCVE.Text = "addCVE";
            this.addCVE.UseVisualStyleBackColor = true;
            this.addCVE.Click += new System.EventHandler(this.addCVE_Click);
            // 
            // ExcelToMS
            // 
            this.ExcelToMS.Location = new System.Drawing.Point(1110, 681);
            this.ExcelToMS.Name = "ExcelToMS";
            this.ExcelToMS.Size = new System.Drawing.Size(75, 23);
            this.ExcelToMS.TabIndex = 21;
            this.ExcelToMS.Text = "ExcelToMS";
            this.ExcelToMS.UseVisualStyleBackColor = true;
            this.ExcelToMS.Click += new System.EventHandler(this.ExcelToMS_Click);
            // 
            // Translations2
            // 
            this.Translations2.Location = new System.Drawing.Point(646, 656);
            this.Translations2.Name = "Translations2";
            this.Translations2.Size = new System.Drawing.Size(75, 23);
            this.Translations2.TabIndex = 22;
            this.Translations2.Text = "半自动翻译";
            this.Translations2.UseVisualStyleBackColor = true;
            this.Translations2.Click += new System.EventHandler(this.Translations2_Click);
            // 
            // Translations
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1190, 715);
            this.Controls.Add(this.Translations2);
            this.Controls.Add(this.ExcelToMS);
            this.Controls.Add(this.addCVE);
            this.Controls.Add(this.weizhi);
            this.Controls.Add(this.jujuefuwu);
            this.Controls.Add(this.quanxiantisheng);
            this.Controls.Add(this.xinxixielu);
            this.Controls.Add(this.renyidaimazhixing);
            this.Controls.Add(this.修改);
            this.Controls.Add(this.texttrans);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.textCVE);
            this.Controls.Add(this.DocWeek);
            this.Controls.Add(this.刷新);
            this.Controls.Add(this.loading);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.add);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.保存);
            this.Controls.Add(this.OverView);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Translations";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Translations";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Translations_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox OverView;
        private System.Windows.Forms.Button 保存;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button loading;
        private System.Windows.Forms.Button 刷新;
        private System.Windows.Forms.Button DocWeek;
        private System.Windows.Forms.TextBox textCVE;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox texttrans;
        private System.Windows.Forms.Button 修改;
        private System.Windows.Forms.CheckBox renyidaimazhixing;
        private System.Windows.Forms.CheckBox xinxixielu;
        private System.Windows.Forms.CheckBox quanxiantisheng;
        private System.Windows.Forms.CheckBox jujuefuwu;
        private System.Windows.Forms.CheckBox weizhi;
        private System.Windows.Forms.Button addCVE;
        private System.Windows.Forms.Button ExcelToMS;
        private System.Windows.Forms.Button Translations2;
    }
}