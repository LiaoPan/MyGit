﻿namespace MyDoc
{
    partial class translation2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Save = new System.Windows.Forms.Button();
            this.weizhi = new System.Windows.Forms.CheckBox();
            this.jujuefuwu = new System.Windows.Forms.CheckBox();
            this.quanxiantisheng = new System.Windows.Forms.CheckBox();
            this.xinxixielu = new System.Windows.Forms.CheckBox();
            this.renyidaimazhixing = new System.Windows.Forms.CheckBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.volnamelabel = new System.Windows.Forms.Label();
            this.texttrans = new System.Windows.Forms.TextBox();
            this.translabel = new System.Windows.Forms.Label();
            this.affectlabel = new System.Windows.Forms.Label();
            this.textCVE = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textOverView = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textImpact = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textAffect = new System.Windows.Forms.TextBox();
            this.textclass = new System.Windows.Forms.TextBox();
            this.textcause = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textTrans2 = new System.Windows.Forms.TextBox();
            this.Previous = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textRank = new System.Windows.Forms.TextBox();
            this.trans_Btn = new System.Windows.Forms.Button();
            this.refresh_btn = new System.Windows.Forms.Button();
            this.lab_Message = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textTital = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(813, 146);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 0;
            this.Save.Text = "保存";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // weizhi
            // 
            this.weizhi.AutoSize = true;
            this.weizhi.Location = new System.Drawing.Point(1037, 516);
            this.weizhi.Name = "weizhi";
            this.weizhi.Size = new System.Drawing.Size(48, 16);
            this.weizhi.TabIndex = 23;
            this.weizhi.Text = "未知";
            this.weizhi.UseVisualStyleBackColor = true;
            // 
            // jujuefuwu
            // 
            this.jujuefuwu.AutoSize = true;
            this.jujuefuwu.Location = new System.Drawing.Point(959, 516);
            this.jujuefuwu.Name = "jujuefuwu";
            this.jujuefuwu.Size = new System.Drawing.Size(72, 16);
            this.jujuefuwu.TabIndex = 22;
            this.jujuefuwu.Text = "拒绝服务";
            this.jujuefuwu.UseVisualStyleBackColor = true;
            // 
            // quanxiantisheng
            // 
            this.quanxiantisheng.AutoSize = true;
            this.quanxiantisheng.Location = new System.Drawing.Point(803, 516);
            this.quanxiantisheng.Name = "quanxiantisheng";
            this.quanxiantisheng.Size = new System.Drawing.Size(72, 16);
            this.quanxiantisheng.TabIndex = 21;
            this.quanxiantisheng.Text = "权限提升";
            this.quanxiantisheng.UseVisualStyleBackColor = true;
            // 
            // xinxixielu
            // 
            this.xinxixielu.AutoSize = true;
            this.xinxixielu.Location = new System.Drawing.Point(881, 516);
            this.xinxixielu.Name = "xinxixielu";
            this.xinxixielu.Size = new System.Drawing.Size(72, 16);
            this.xinxixielu.TabIndex = 20;
            this.xinxixielu.Text = "信息泄露";
            this.xinxixielu.UseVisualStyleBackColor = true;
            // 
            // renyidaimazhixing
            // 
            this.renyidaimazhixing.AutoSize = true;
            this.renyidaimazhixing.Location = new System.Drawing.Point(701, 516);
            this.renyidaimazhixing.Name = "renyidaimazhixing";
            this.renyidaimazhixing.Size = new System.Drawing.Size(96, 16);
            this.renyidaimazhixing.TabIndex = 19;
            this.renyidaimazhixing.Text = "任意代码执行";
            this.renyidaimazhixing.UseVisualStyleBackColor = true;
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(695, 213);
            this.textName.Multiline = true;
            this.textName.Name = "textName";
            this.textName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textName.Size = new System.Drawing.Size(403, 52);
            this.textName.TabIndex = 24;
            // 
            // volnamelabel
            // 
            this.volnamelabel.AutoSize = true;
            this.volnamelabel.Location = new System.Drawing.Point(648, 213);
            this.volnamelabel.Name = "volnamelabel";
            this.volnamelabel.Size = new System.Drawing.Size(41, 12);
            this.volnamelabel.TabIndex = 25;
            this.volnamelabel.Text = "标题：";
            // 
            // texttrans
            // 
            this.texttrans.Location = new System.Drawing.Point(695, 271);
            this.texttrans.Multiline = true;
            this.texttrans.Name = "texttrans";
            this.texttrans.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.texttrans.Size = new System.Drawing.Size(403, 225);
            this.texttrans.TabIndex = 26;
            // 
            // translabel
            // 
            this.translabel.AutoSize = true;
            this.translabel.Location = new System.Drawing.Point(648, 268);
            this.translabel.Name = "translabel";
            this.translabel.Size = new System.Drawing.Size(41, 12);
            this.translabel.TabIndex = 27;
            this.translabel.Text = "翻译：";
            // 
            // affectlabel
            // 
            this.affectlabel.AutoSize = true;
            this.affectlabel.Location = new System.Drawing.Point(654, 519);
            this.affectlabel.Name = "affectlabel";
            this.affectlabel.Size = new System.Drawing.Size(41, 12);
            this.affectlabel.TabIndex = 28;
            this.affectlabel.Text = "影响：";
            // 
            // textCVE
            // 
            this.textCVE.Location = new System.Drawing.Point(81, 9);
            this.textCVE.Multiline = true;
            this.textCVE.Name = "textCVE";
            this.textCVE.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textCVE.Size = new System.Drawing.Size(264, 21);
            this.textCVE.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 30;
            this.label1.Text = "Cve：";
            // 
            // textOverView
            // 
            this.textOverView.Location = new System.Drawing.Point(363, 232);
            this.textOverView.Multiline = true;
            this.textOverView.Name = "textOverView";
            this.textOverView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textOverView.Size = new System.Drawing.Size(252, 240);
            this.textOverView.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(361, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 32;
            this.label2.Text = "OverView:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 33;
            this.label3.Text = "Impact：";
            // 
            // textImpact
            // 
            this.textImpact.Location = new System.Drawing.Point(81, 36);
            this.textImpact.Multiline = true;
            this.textImpact.Name = "textImpact";
            this.textImpact.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textImpact.Size = new System.Drawing.Size(264, 102);
            this.textImpact.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 35;
            this.label4.Text = "Affect：";
            // 
            // textAffect
            // 
            this.textAffect.Location = new System.Drawing.Point(81, 144);
            this.textAffect.Multiline = true;
            this.textAffect.Name = "textAffect";
            this.textAffect.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textAffect.Size = new System.Drawing.Size(264, 328);
            this.textAffect.TabIndex = 36;
            // 
            // textclass
            // 
            this.textclass.Location = new System.Drawing.Point(81, 478);
            this.textclass.Multiline = true;
            this.textclass.Name = "textclass";
            this.textclass.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textclass.Size = new System.Drawing.Size(264, 49);
            this.textclass.TabIndex = 37;
            // 
            // textcause
            // 
            this.textcause.Location = new System.Drawing.Point(81, 532);
            this.textcause.Multiline = true;
            this.textcause.Name = "textcause";
            this.textcause.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textcause.Size = new System.Drawing.Size(264, 49);
            this.textcause.TabIndex = 38;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 483);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 39;
            this.label5.Text = "Class：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 537);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 40;
            this.label6.Text = "Cause：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(361, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 41;
            this.label7.Text = "trans：";
            // 
            // textTrans2
            // 
            this.textTrans2.Location = new System.Drawing.Point(363, 36);
            this.textTrans2.Multiline = true;
            this.textTrans2.Name = "textTrans2";
            this.textTrans2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textTrans2.Size = new System.Drawing.Size(252, 163);
            this.textTrans2.TabIndex = 42;
            // 
            // Previous
            // 
            this.Previous.Location = new System.Drawing.Point(732, 146);
            this.Previous.Name = "Previous";
            this.Previous.Size = new System.Drawing.Size(75, 23);
            this.Previous.TabIndex = 43;
            this.Previous.Text = "上一条";
            this.Previous.UseVisualStyleBackColor = true;
            this.Previous.Click += new System.EventHandler(this.Previous_Click);
            // 
            // Next
            // 
            this.Next.Location = new System.Drawing.Point(732, 175);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(75, 23);
            this.Next.TabIndex = 44;
            this.Next.Text = "下一条";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(363, 483);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 45;
            this.label8.Text = "Rank：";
            // 
            // textRank
            // 
            this.textRank.Location = new System.Drawing.Point(365, 499);
            this.textRank.Name = "textRank";
            this.textRank.Size = new System.Drawing.Size(250, 21);
            this.textRank.TabIndex = 46;
            // 
            // trans_Btn
            // 
            this.trans_Btn.Location = new System.Drawing.Point(651, 175);
            this.trans_Btn.Name = "trans_Btn";
            this.trans_Btn.Size = new System.Drawing.Size(75, 23);
            this.trans_Btn.TabIndex = 47;
            this.trans_Btn.Text = "翻译";
            this.trans_Btn.UseVisualStyleBackColor = true;
            this.trans_Btn.Click += new System.EventHandler(this.trans_Btn_Click);
            // 
            // refresh_btn
            // 
            this.refresh_btn.Location = new System.Drawing.Point(651, 146);
            this.refresh_btn.Name = "refresh_btn";
            this.refresh_btn.Size = new System.Drawing.Size(75, 23);
            this.refresh_btn.TabIndex = 48;
            this.refresh_btn.Text = "刷新_保存";
            this.refresh_btn.UseVisualStyleBackColor = true;
            this.refresh_btn.Click += new System.EventHandler(this.refresh_btn_Click);
            // 
            // lab_Message
            // 
            this.lab_Message.AutoSize = true;
            this.lab_Message.Location = new System.Drawing.Point(654, 547);
            this.lab_Message.Name = "lab_Message";
            this.lab_Message.Size = new System.Drawing.Size(41, 12);
            this.lab_Message.TabIndex = 49;
            this.lab_Message.Text = "消息：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(648, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 50;
            this.label9.Text = "tital:";
            // 
            // textTital
            // 
            this.textTital.Location = new System.Drawing.Point(650, 29);
            this.textTital.Multiline = true;
            this.textTital.Name = "textTital";
            this.textTital.Size = new System.Drawing.Size(448, 48);
            this.textTital.TabIndex = 51;
            // 
            // translation2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1110, 593);
            this.Controls.Add(this.textTital);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lab_Message);
            this.Controls.Add(this.refresh_btn);
            this.Controls.Add(this.trans_Btn);
            this.Controls.Add(this.textRank);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Previous);
            this.Controls.Add(this.textTrans2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textcause);
            this.Controls.Add(this.textclass);
            this.Controls.Add(this.textAffect);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textImpact);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textOverView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textCVE);
            this.Controls.Add(this.affectlabel);
            this.Controls.Add(this.translabel);
            this.Controls.Add(this.texttrans);
            this.Controls.Add(this.volnamelabel);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.weizhi);
            this.Controls.Add(this.jujuefuwu);
            this.Controls.Add(this.quanxiantisheng);
            this.Controls.Add(this.xinxixielu);
            this.Controls.Add(this.renyidaimazhixing);
            this.Controls.Add(this.Save);
            this.Name = "translation2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "translation2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.CheckBox weizhi;
        private System.Windows.Forms.CheckBox jujuefuwu;
        private System.Windows.Forms.CheckBox quanxiantisheng;
        private System.Windows.Forms.CheckBox xinxixielu;
        private System.Windows.Forms.CheckBox renyidaimazhixing;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Label volnamelabel;
        private System.Windows.Forms.TextBox texttrans;
        private System.Windows.Forms.Label translabel;
        private System.Windows.Forms.Label affectlabel;
        private System.Windows.Forms.TextBox textCVE;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textOverView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textImpact;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textAffect;
        private System.Windows.Forms.TextBox textclass;
        private System.Windows.Forms.TextBox textcause;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textTrans2;
        private System.Windows.Forms.Button Previous;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textRank;
        private System.Windows.Forms.Button trans_Btn;
        private System.Windows.Forms.Button refresh_btn;
        private System.Windows.Forms.Label lab_Message;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textTital;
    }
}