﻿namespace MyDoc
{
    partial class LoadNVD2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoadNVD2));
            this.load = new System.Windows.Forms.Button();
            this.low = new System.Windows.Forms.CheckBox();
            this.middle = new System.Windows.Forms.CheckBox();
            this.high = new System.Windows.Forms.CheckBox();
            this.severe = new System.Windows.Forms.CheckBox();
            this.DateProcess = new System.Windows.Forms.Button();
            this.MSAdd = new System.Windows.Forms.Button();
            this.month1 = new System.Windows.Forms.CheckBox();
            this.month2 = new System.Windows.Forms.CheckBox();
            this.month4 = new System.Windows.Forms.CheckBox();
            this.month3 = new System.Windows.Forms.CheckBox();
            this.month6 = new System.Windows.Forms.CheckBox();
            this.month5 = new System.Windows.Forms.CheckBox();
            this.month12 = new System.Windows.Forms.CheckBox();
            this.month11 = new System.Windows.Forms.CheckBox();
            this.month10 = new System.Windows.Forms.CheckBox();
            this.month9 = new System.Windows.Forms.CheckBox();
            this.month8 = new System.Windows.Forms.CheckBox();
            this.month7 = new System.Windows.Forms.CheckBox();
            this.UniDatetime = new System.Windows.Forms.Button();
            this.Import_BigDatabase_btn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1_year = new System.Windows.Forms.TextBox();
            this.update_bigdb_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // load
            // 
            this.load.Location = new System.Drawing.Point(472, 23);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(75, 23);
            this.load.TabIndex = 0;
            this.load.Text = "load";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.load_Click);
            // 
            // low
            // 
            this.low.AutoSize = true;
            this.low.Location = new System.Drawing.Point(472, 130);
            this.low.Name = "low";
            this.low.Size = new System.Drawing.Size(42, 16);
            this.low.TabIndex = 16;
            this.low.Text = "low";
            this.low.UseVisualStyleBackColor = true;
            // 
            // middle
            // 
            this.middle.AutoSize = true;
            this.middle.Location = new System.Drawing.Point(472, 107);
            this.middle.Name = "middle";
            this.middle.Size = new System.Drawing.Size(60, 16);
            this.middle.TabIndex = 15;
            this.middle.Text = "middle";
            this.middle.UseVisualStyleBackColor = true;
            // 
            // high
            // 
            this.high.AutoSize = true;
            this.high.Location = new System.Drawing.Point(472, 85);
            this.high.Name = "high";
            this.high.Size = new System.Drawing.Size(48, 16);
            this.high.TabIndex = 14;
            this.high.Text = "high";
            this.high.UseVisualStyleBackColor = true;
            // 
            // severe
            // 
            this.severe.AutoSize = true;
            this.severe.Location = new System.Drawing.Point(472, 62);
            this.severe.Name = "severe";
            this.severe.Size = new System.Drawing.Size(60, 16);
            this.severe.TabIndex = 13;
            this.severe.Text = "severe";
            this.severe.UseVisualStyleBackColor = true;
            // 
            // DateProcess
            // 
            this.DateProcess.Location = new System.Drawing.Point(12, 12);
            this.DateProcess.Name = "DateProcess";
            this.DateProcess.Size = new System.Drawing.Size(75, 23);
            this.DateProcess.TabIndex = 17;
            this.DateProcess.Text = "数据处理";
            this.DateProcess.UseVisualStyleBackColor = true;
            this.DateProcess.Click += new System.EventHandler(this.DateProcess_Click);
            // 
            // MSAdd
            // 
            this.MSAdd.Location = new System.Drawing.Point(12, 41);
            this.MSAdd.Name = "MSAdd";
            this.MSAdd.Size = new System.Drawing.Size(75, 23);
            this.MSAdd.TabIndex = 18;
            this.MSAdd.Text = "MSAdd";
            this.MSAdd.UseVisualStyleBackColor = true;
            this.MSAdd.Click += new System.EventHandler(this.MSAdd_Click);
            // 
            // month1
            // 
            this.month1.AutoSize = true;
            this.month1.Location = new System.Drawing.Point(12, 70);
            this.month1.Name = "month1";
            this.month1.Size = new System.Drawing.Size(42, 16);
            this.month1.TabIndex = 19;
            this.month1.Text = "1月";
            this.month1.UseVisualStyleBackColor = true;
            // 
            // month2
            // 
            this.month2.AutoSize = true;
            this.month2.Location = new System.Drawing.Point(60, 70);
            this.month2.Name = "month2";
            this.month2.Size = new System.Drawing.Size(42, 16);
            this.month2.TabIndex = 20;
            this.month2.Text = "1月";
            this.month2.UseVisualStyleBackColor = true;
            // 
            // month4
            // 
            this.month4.AutoSize = true;
            this.month4.Location = new System.Drawing.Point(60, 92);
            this.month4.Name = "month4";
            this.month4.Size = new System.Drawing.Size(42, 16);
            this.month4.TabIndex = 22;
            this.month4.Text = "4月";
            this.month4.UseVisualStyleBackColor = true;
            // 
            // month3
            // 
            this.month3.AutoSize = true;
            this.month3.Location = new System.Drawing.Point(12, 92);
            this.month3.Name = "month3";
            this.month3.Size = new System.Drawing.Size(42, 16);
            this.month3.TabIndex = 21;
            this.month3.Text = "3月";
            this.month3.UseVisualStyleBackColor = true;
            // 
            // month6
            // 
            this.month6.AutoSize = true;
            this.month6.Location = new System.Drawing.Point(60, 114);
            this.month6.Name = "month6";
            this.month6.Size = new System.Drawing.Size(42, 16);
            this.month6.TabIndex = 24;
            this.month6.Text = "6月";
            this.month6.UseVisualStyleBackColor = true;
            // 
            // month5
            // 
            this.month5.AutoSize = true;
            this.month5.Location = new System.Drawing.Point(12, 114);
            this.month5.Name = "month5";
            this.month5.Size = new System.Drawing.Size(42, 16);
            this.month5.TabIndex = 23;
            this.month5.Text = "5月";
            this.month5.UseVisualStyleBackColor = true;
            // 
            // month12
            // 
            this.month12.AutoSize = true;
            this.month12.Location = new System.Drawing.Point(60, 180);
            this.month12.Name = "month12";
            this.month12.Size = new System.Drawing.Size(48, 16);
            this.month12.TabIndex = 30;
            this.month12.Text = "12月";
            this.month12.UseVisualStyleBackColor = true;
            // 
            // month11
            // 
            this.month11.AutoSize = true;
            this.month11.Location = new System.Drawing.Point(12, 180);
            this.month11.Name = "month11";
            this.month11.Size = new System.Drawing.Size(48, 16);
            this.month11.TabIndex = 29;
            this.month11.Text = "11月";
            this.month11.UseVisualStyleBackColor = true;
            // 
            // month10
            // 
            this.month10.AutoSize = true;
            this.month10.Location = new System.Drawing.Point(60, 158);
            this.month10.Name = "month10";
            this.month10.Size = new System.Drawing.Size(48, 16);
            this.month10.TabIndex = 28;
            this.month10.Text = "10月";
            this.month10.UseVisualStyleBackColor = true;
            // 
            // month9
            // 
            this.month9.AutoSize = true;
            this.month9.Location = new System.Drawing.Point(12, 158);
            this.month9.Name = "month9";
            this.month9.Size = new System.Drawing.Size(42, 16);
            this.month9.TabIndex = 27;
            this.month9.Text = "9月";
            this.month9.UseVisualStyleBackColor = true;
            // 
            // month8
            // 
            this.month8.AutoSize = true;
            this.month8.Location = new System.Drawing.Point(60, 136);
            this.month8.Name = "month8";
            this.month8.Size = new System.Drawing.Size(42, 16);
            this.month8.TabIndex = 26;
            this.month8.Text = "8月";
            this.month8.UseVisualStyleBackColor = true;
            // 
            // month7
            // 
            this.month7.AutoSize = true;
            this.month7.Location = new System.Drawing.Point(12, 136);
            this.month7.Name = "month7";
            this.month7.Size = new System.Drawing.Size(42, 16);
            this.month7.TabIndex = 25;
            this.month7.Text = "7月";
            this.month7.UseVisualStyleBackColor = true;
            // 
            // UniDatetime
            // 
            this.UniDatetime.Location = new System.Drawing.Point(120, 12);
            this.UniDatetime.Name = "UniDatetime";
            this.UniDatetime.Size = new System.Drawing.Size(82, 23);
            this.UniDatetime.TabIndex = 31;
            this.UniDatetime.Text = "UniDatetime";
            this.UniDatetime.UseVisualStyleBackColor = true;
            this.UniDatetime.Click += new System.EventHandler(this.UniDatetime_Click);
            // 
            // Import_BigDatabase_btn
            // 
            this.Import_BigDatabase_btn.Location = new System.Drawing.Point(120, 66);
            this.Import_BigDatabase_btn.Name = "Import_BigDatabase_btn";
            this.Import_BigDatabase_btn.Size = new System.Drawing.Size(67, 23);
            this.Import_BigDatabase_btn.TabIndex = 32;
            this.Import_BigDatabase_btn.Text = "导入大库";
            this.Import_BigDatabase_btn.UseVisualStyleBackColor = true;
            this.Import_BigDatabase_btn.Click += new System.EventHandler(this.Import_BigDatabase_btn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(193, 66);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 23);
            this.button1.TabIndex = 33;
            this.button1.Text = "导入大库2";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 34;
            this.label1.Text = "要导入的年份：";
            // 
            // textBox1_year
            // 
            this.textBox1_year.Location = new System.Drawing.Point(206, 43);
            this.textBox1_year.Name = "textBox1_year";
            this.textBox1_year.Size = new System.Drawing.Size(55, 21);
            this.textBox1_year.TabIndex = 35;
            // 
            // update_bigdb_btn
            // 
            this.update_bigdb_btn.Location = new System.Drawing.Point(120, 92);
            this.update_bigdb_btn.Name = "update_bigdb_btn";
            this.update_bigdb_btn.Size = new System.Drawing.Size(141, 23);
            this.update_bigdb_btn.TabIndex = 36;
            this.update_bigdb_btn.Text = "每周更新大库";
            this.update_bigdb_btn.UseVisualStyleBackColor = true;
            this.update_bigdb_btn.Click += new System.EventHandler(this.update_bigdb_btn_Click);
            // 
            // LoadNVD2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 253);
            this.Controls.Add(this.update_bigdb_btn);
            this.Controls.Add(this.textBox1_year);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Import_BigDatabase_btn);
            this.Controls.Add(this.UniDatetime);
            this.Controls.Add(this.month12);
            this.Controls.Add(this.month11);
            this.Controls.Add(this.month10);
            this.Controls.Add(this.month9);
            this.Controls.Add(this.month8);
            this.Controls.Add(this.month7);
            this.Controls.Add(this.month6);
            this.Controls.Add(this.month5);
            this.Controls.Add(this.month4);
            this.Controls.Add(this.month3);
            this.Controls.Add(this.month2);
            this.Controls.Add(this.month1);
            this.Controls.Add(this.MSAdd);
            this.Controls.Add(this.DateProcess);
            this.Controls.Add(this.low);
            this.Controls.Add(this.middle);
            this.Controls.Add(this.high);
            this.Controls.Add(this.severe);
            this.Controls.Add(this.load);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LoadNVD2";
            this.Text = "LoadNVD2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button load;
        private System.Windows.Forms.CheckBox low;
        private System.Windows.Forms.CheckBox middle;
        private System.Windows.Forms.CheckBox high;
        private System.Windows.Forms.CheckBox severe;
        private System.Windows.Forms.Button DateProcess;
        private System.Windows.Forms.Button MSAdd;
        private System.Windows.Forms.CheckBox month1;
        private System.Windows.Forms.CheckBox month2;
        private System.Windows.Forms.CheckBox month4;
        private System.Windows.Forms.CheckBox month3;
        private System.Windows.Forms.CheckBox month6;
        private System.Windows.Forms.CheckBox month5;
        private System.Windows.Forms.CheckBox month12;
        private System.Windows.Forms.CheckBox month11;
        private System.Windows.Forms.CheckBox month10;
        private System.Windows.Forms.CheckBox month9;
        private System.Windows.Forms.CheckBox month8;
        private System.Windows.Forms.CheckBox month7;
        private System.Windows.Forms.Button UniDatetime;
        private System.Windows.Forms.Button Import_BigDatabase_btn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1_year;
        private System.Windows.Forms.Button update_bigdb_btn;
    }
}