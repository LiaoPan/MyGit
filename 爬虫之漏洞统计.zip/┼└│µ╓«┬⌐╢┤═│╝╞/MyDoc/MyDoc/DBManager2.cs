﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

//using Microsoft.ApplicationBlocks.Data;


namespace MyDoc
{
    public class DBManager2
    {
        //private DBManager2()
        //{
        //}

        //private SqlConnectionStringBuilder _connStrBuilder = new SqlConnectionStringBuilder();
        //private SqlConnection _conn = new SqlConnection();
        //private bool _isConnected = false;
        //SqlTransaction transaction = null;

        //private SiteManager _siteManager = SiteManager.Instance;
        //private static DBManager2 _instance = new DBManager2();

        public static List<Uri> NVD_CVE()
        {
            List<Uri> urlIndex = new List<Uri>();


            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    SqlCommand com2 = new SqlCommand();
                    com2.CommandType = CommandType.Text;

                    VolOverAll.DataBaseNameLink = "cvd";
                    string databasename2 = "cnvd";
                    string databasewhere2 = "where cve <> ''";
                    //int a = 10000;
                    VolOverAll.DataBaseWhere = "where id > 20020716";
                    com.CommandText = "select * from " + VolOverAll.DataBaseNameLink + " " + VolOverAll.DataBaseWhere + " " + "order by cvd";
                    com.Connection = con;
                    com2.CommandText = "select * from " + databasename2 + " " + databasewhere2 + " " + "order by cvd";
                    com2.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);
                    SqlDataAdapter da2 = new SqlDataAdapter(com2);
                    DataSet dscl2 = new DataSet();
                    da2.Fill(dscl2);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    {
                        string str = (string)dscl.Tables[0].Rows[k]["url"];
                        //http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-1999-1191
                        str = str.Substring(48);
                        dscl.Tables[0].Rows[k]["cve"] = str;
                        dscl.Tables[0].Rows[k]["cvd"] = k+1;
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlIndex;
        }

        //public static List<Uri> OSVDB_Pro()
        //{
        //    List<Uri> urlIndex = new List<Uri>();


        //    SqlConnection con = new SqlConnection();
        //    con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
        //    try
        //    {
        //        con.Open();
        //        if (con.State == ConnectionState.Open)
        //        {
        //            SqlCommand com = new SqlCommand();
        //            com.CommandType = CommandType.Text;

        //            string databasename = "cvd_osvdb";
        //            string databasewhere = "where id <= 100 and cvelinks <> ''";

        //            com.CommandText = "select * from " + databasename + " " + databasewhere + " " + "order by id";
        //            com.Connection = con;

        //            SqlDataAdapter da = new SqlDataAdapter(com);
        //            DataSet dscl = new DataSet();
        //            da.Fill(dscl);

        //            for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
        //            {
        //                string str = (string)dscl.Tables[0].Rows[k]["url"];
        //                //http://nvd.nist.gov/nvd.cfm?cvename=CVE-1999-0776
        //                str = str.Substring(36);
        //                dscl.Tables[0].Rows[k]["cve"] = str;
        //            }

        //            SqlCommandBuilder scb = new SqlCommandBuilder(da);
        //            da.Update(dscl);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("");
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }

        //    return urlIndex;
        //}

        public static void CNVD_Translations()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cnvd where cve <> '' order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scCn = "scCn = 'yes' ";

                        //string SQLSentence = string.Format("update cvd set Translations = '{0}' where cve = '{1}'", dscl.Tables[0].Rows[k]["Description"], dscl.Tables[0].Rows[k]["CVE"]);
                        string cve = (string)dscl.Tables[0].Rows[k]["cve"];
                        List<string> intlist = new List<string>();
                        for (; cve.Count() > 0; )
                        {
                            int a = cve.IndexOf("CVE");
                            string str = "";
                            if (a >= 0)
                            {
                                str = cve.Substring(a, 13);
                                cve = cve.Substring(a + 13);
                                intlist.Add(str);
                            }
                            else
                                break;
                        }
                        cve = "";
                        for (int h = 0; h < intlist.Count; h++)
                        {
                            cve = cve + "cve = '" + intlist[h] + "' ";
                        }

                        string title = (string)dscl.Tables[0].Rows[k]["title"];
                        if (title.Contains("CNVD-"))
                            title = "";
                        else
                            title = "titleC = '" + title + "' ";

                        string solution = (string)dscl.Tables[0].Rows[k]["Solution"];
                        if (solution != "")
                            solution = "Solution = '" + solution + "' ";

                        string Patch = (string)dscl.Tables[0].Rows[k]["Patch"];
                        if (Patch != "")
                            Patch = "Patch = '" + Patch + " ";

                        string where = scCn;
                        //if (cve != "" && cve!=null)
                        //    where = where + ", " + cve;
                        if (title != "" && title != null)
                            where = where + ", " + title;
                        if (solution != "" && solution != null)
                            where = where + ", " + solution;
                        if (Patch != "" && Patch != null)
                            where = where + ", " + Patch;

                        string SQLSentence = string.Format("update cvd set {0} where {1}",where, cve);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void CXSecurity_PocToOSVDB_cve()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    //com.CommandText = "select * from CXSecurity_Pro where (cve <> '' and POC <> '' and id >100 and id <= 1000) order by id";
                    com.CommandText = "select * from CXSecurity_Pro where UniDate>'' and UniDate<='2013/12/31' and (cve like 'CVE-%' or cve like '%CVE-%') and poc <> '' order by UniDate, datetime";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scCx = "scCx = 'yes' ";

                        //string SQLSentence = string.Format("update cvd set Translations = '{0}' where cve = '{1}'", dscl.Tables[0].Rows[k]["Description"], dscl.Tables[0].Rows[k]["CVE"]);
                        string cve = (string)dscl.Tables[0].Rows[k]["cve"];
                        List<string> intlist = new List<string>();
                        for (; cve.Count() > 0; )
                        {
                            int a = cve.IndexOf("CVE");
                            string str = "";
                            if (a >= 0)
                            {
                                str = cve.Substring(a, 13);
                                cve = cve.Substring(a + 13);
                                intlist.Add(str);
                            }
                            else
                                break;
                        }
                        cve = "";
                        cve = "(cve = '" + intlist[0] + "' ";
                        for (int h = 1; h < intlist.Count; h++)
                        {
                            cve = cve + " or cve = '" + intlist[h] + "' ";
                        }
                        cve = cve + ")";

                        string POC = (string)dscl.Tables[0].Rows[k]["POC"];

                        string UniPoc = (string)dscl.Tables[0].Rows[k]["POC"];
                        UniPoc = UniPoc.Replace("'", "''");
                        UniPoc = "poc = '" + UniPoc + "' ";

                        string where = scCx;
                        if (UniPoc != "" && UniPoc != null)
                            where = where + ", " + UniPoc;


                        if (where != "" && where != null)
                            where = "set " + where;

                        string SQLSentence = string.Format("update cvd_osvdb {0} where {1}", where, cve);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Sebug_PocToOSVDB_cve()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from Sebug_Pro where UniDate>'' and UniDate<='2013/12/31' and (cve like 'CVE-%' or cve like '%CVE-%') and poc <> '' order by UniDate, datetime";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scSe = "scSe = 'yes' ";

                        //string SQLSentence = string.Format("update cvd set Translations = '{0}' where cve = '{1}'", dscl.Tables[0].Rows[k]["Description"], dscl.Tables[0].Rows[k]["CVE"]);
                        string cve = (string)dscl.Tables[0].Rows[k]["cve"];
                        List<string> intlist = new List<string>();
                        for (; cve.Count() > 0; )
                        {
                            int a = cve.IndexOf("CVE-");
                            string str = "";
                            if (a >= 0)
                            {
                                str = cve.Substring(a, 13);
                                cve = cve.Substring(a + 13);
                                intlist.Add(str);
                            }
                            else
                                break;
                        }
                        cve = "";
                        cve = "(cve = '" + intlist[0] + "' ";
                        for (int h = 1; h < intlist.Count; h++)
                        {
                            cve = cve + " or cve = '" + intlist[h] + "' ";
                        }
                        cve = cve + ")";

                        string UniPoc = (string)dscl.Tables[0].Rows[k]["UniPoc"];
                        UniPoc = UniPoc.Replace("'", "''");
                        UniPoc = "poc = '" + UniPoc + "' ";

                        string where = scSe;
                        if (UniPoc != "" && UniPoc != null)
                            where = where + ", " + UniPoc;


                        if (where != "" && where != null)
                            where = "set " + where;

                        string SQLSentence = string.Format("update cvd_osvdb {0} where {1}", where, cve);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Sebug_PocToOSVDB_no_cve()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from Sebug_Pro where (not (cve like '%CVE-%') and UniPoc <> '' and id >10000 and id < 15000) order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scSe = "'nocve' ";

                        //string SQLSentence = string.Format("update cvd set Translations = '{0}' where cve = '{1}'", dscl.Tables[0].Rows[k]["Description"], dscl.Tables[0].Rows[k]["CVE"]);
                        string UniTitle = (string)dscl.Tables[0].Rows[k]["UniTitle"];
                        UniTitle = UniTitle.Replace("'", "''");
                        UniTitle = "'" + UniTitle + "' ";

                        string UniDate = (string)dscl.Tables[0].Rows[k]["UniDate"];
                        UniDate = UniDate.Replace("'", "''");
                        UniDate = "'" + UniDate + "' ";

                        string UniPoc = (string)dscl.Tables[0].Rows[k]["UniPoc"];
                        UniPoc = UniPoc.Replace("'", "''");
                        UniPoc = "'" + UniPoc + "' ";

                        string where = "(" + scSe;
                        if (UniTitle != "" && UniTitle != null)
                            where = where + ", " + UniTitle;
                        if (UniDate != "" && UniDate != null)
                            where = where + ", " + UniDate;
                        if (UniPoc != "" && UniPoc != null)
                            where = where + ", " + UniPoc;

                        where = where + ")";

                        string SQLSentence = string.Format("insert into cvd_osvdb (scSe, Title, UniDate, poc) values {0}", where);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void OSVDB_Pro()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cvd_osvdb2 order by UniDate, datetime";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string title = (string)dscl.Tables[0].Rows[k]["Title"];
                        int a = title.IndexOf(":");
                        if (a >= 0)
                            title = title.Substring(a + 1);
                        //title = title.Trim();
                        title = title.Replace("'","''");
                        title = "Title = '" + title + "' ";

                        string where = title;

                        string SQLSentence = string.Format("update cvd_osvdb2 set {0} where {1}", where, idstr);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        //public static void OSVDB_Pro()
        //{
        //    SqlConnection con = new SqlConnection();
        //    con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
        //    try
        //    {
        //        con.Open();
        //        if (con.State == ConnectionState.Open)
        //        {
        //            SqlCommand com = new SqlCommand();
        //            com.CommandType = CommandType.Text;

        //            com.CommandText = "select * from cvd_osvdb2 where cvelinks <> '' and id >0 and id<=5000 order by id";
        //            com.Connection = con;

        //            SqlDataAdapter da = new SqlDataAdapter(com);
        //            DataSet dscl = new DataSet();
        //            da.Fill(dscl);

        //            for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
        //            //for (int k = 0; k < 10; k++)
        //            {
        //                string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
        //                idstr = "id = " + idstr + " ";

        //                string cve = (string)dscl.Tables[0].Rows[k]["cvelinks"];
        //                //http://nvd.nist.gov/nvd.cfm?cvename=CVE-1999-0524
        //                cve = cve.Substring(cve.Count() - 13);
        //                if (cve != "" && cve != null)
        //                    cve = "cve = '" + cve + "' ";
        //                else
        //                    cve = "";

        //                string title = (string)dscl.Tables[0].Rows[k]["Title"];
        //                int a = title.IndexOf(":");
        //                if (a >= 0)
        //                    title = title.Substring(a + 1);
        //                //title = title.Trim();
        //                title = title.Replace("'", "''");
        //                title = "Title = '" + title + "' ";

        //                string numstr = "";

        //                string CVSS_Access_Vector = (string)dscl.Tables[0].Rows[k]["CVSS_Access_Vector_n"];
        //                if (CVSS_Access_Vector.Count() > 0)
        //                {
        //                    numstr = CVSS_Access_Vector.Substring(CVSS_Access_Vector.Count() - 1);
        //                    if (numstr == "0")
        //                        CVSS_Access_Vector = "本地";
        //                    else if (numstr == "1")
        //                        CVSS_Access_Vector = "局域网";
        //                    else if (numstr == "2")
        //                        CVSS_Access_Vector = "远程";
        //                    CVSS_Access_Vector = "CVSS_Access_Vector = '" + CVSS_Access_Vector + "' ";
        //                }


        //                string CVSS_Access_Compexity = (string)dscl.Tables[0].Rows[k]["CVSS_Access_Compexity_n"];
        //                if (CVSS_Access_Compexity.Count() > 0)
        //                {
        //                    numstr = CVSS_Access_Compexity.Substring(CVSS_Access_Compexity.Count() - 1);
        //                    if (numstr == "0")
        //                        CVSS_Access_Compexity = "高";
        //                    else if (numstr == "1")
        //                        CVSS_Access_Compexity = "中";
        //                    else if (numstr == "2")
        //                        CVSS_Access_Compexity = "低";
        //                    CVSS_Access_Compexity = "CVSS_Access_Compexity = '" + CVSS_Access_Compexity + "' ";
        //                }


        //                string CVSS_Authentication = (string)dscl.Tables[0].Rows[k]["CVSS_Authentication_n"];
        //                if (CVSS_Authentication.Count() > 0)
        //                {
        //                    numstr = CVSS_Authentication.Substring(CVSS_Authentication.Count() - 1);
        //                    if (numstr == "0")
        //                        CVSS_Authentication = "多次认证";
        //                    else if (numstr == "1")
        //                        CVSS_Authentication = "单次认证";
        //                    else if (numstr == "2")
        //                        CVSS_Authentication = "多次认证";
        //                    CVSS_Authentication = "CVSS_Authentication = '" + CVSS_Authentication + "' ";
        //                }


        //                string CVSS_Confidentiality = (string)dscl.Tables[0].Rows[k]["CVSS_Confidentiality_n"];
        //                if (CVSS_Confidentiality.Count() > 0)
        //                {
        //                    numstr = CVSS_Confidentiality.Substring(CVSS_Confidentiality.Count() - 1);
        //                    if (numstr == "0")
        //                        CVSS_Confidentiality = "无影响";
        //                    else if (numstr == "1")
        //                        CVSS_Confidentiality = "部分";
        //                    else if (numstr == "2")
        //                        CVSS_Confidentiality = "完全";
        //                    CVSS_Confidentiality = "CVSS_Confidentiality = '" + CVSS_Confidentiality + "' ";
        //                }


        //                string CVSS_Integrity = (string)dscl.Tables[0].Rows[k]["CVSS_Integrity_n"];
        //                if (CVSS_Integrity.Count() > 0)
        //                {
        //                    numstr = CVSS_Integrity.Substring(CVSS_Integrity.Count() - 1);
        //                    if (numstr == "0")
        //                        CVSS_Integrity = "无影响";
        //                    else if (numstr == "1")
        //                        CVSS_Integrity = "部分";
        //                    else if (numstr == "2")
        //                        CVSS_Integrity = "完全";
        //                    CVSS_Integrity = "CVSS_Integrity = '" + CVSS_Integrity + "' ";
        //                }


        //                string CVSS_Availability = (string)dscl.Tables[0].Rows[k]["CVSS_Availability_n"];
        //                if (CVSS_Availability.Count() > 0)
        //                {
        //                    numstr = CVSS_Availability.Substring(CVSS_Availability.Count() - 1);
        //                    if (numstr == "0")
        //                        CVSS_Availability = "无影响";
        //                    else if (numstr == "1")
        //                        CVSS_Availability = "部分";
        //                    else if (numstr == "2")
        //                        CVSS_Availability = "完全";
        //                    CVSS_Availability = "CVSS_Availability = '" + CVSS_Availability + "' ";
        //                }


        //                string where = cve;
        //                //if (cve != "" && cve!=null)
        //                //    where = where + ", " + cve;
        //                if (title != "" && title != null)
        //                    where = where + ", " + title;
        //                if (CVSS_Access_Vector != "" && CVSS_Access_Vector != null)
        //                    where = where + ", " + CVSS_Access_Vector;
        //                if (CVSS_Access_Compexity != "" && CVSS_Access_Compexity != null)
        //                    where = where + ", " + CVSS_Access_Compexity;
        //                if (CVSS_Authentication != "" && CVSS_Authentication != null)
        //                    where = where + ", " + CVSS_Authentication;
        //                if (CVSS_Confidentiality != "" && CVSS_Confidentiality != null)
        //                    where = where + ", " + CVSS_Confidentiality;
        //                if (CVSS_Integrity != "" && CVSS_Integrity != null)
        //                    where = where + ", " + CVSS_Integrity;
        //                if (CVSS_Availability != "" && CVSS_Availability != null)
        //                    where = where + ", " + CVSS_Availability;


        //                string SQLSentence = string.Format("update cvd_osvdb2 set {0} where {1}", where, idstr);
        //                OpSQLWrite(SQLSentence);
        //            }

        //            SqlCommandBuilder scb = new SqlCommandBuilder(da);
        //            //da.Update(dscl);
        //            MessageBox.Show("下载完毕");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        int a = 0;
        //        //MessageBox.Show("");
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}
        public static void OSVDB_Pro_UniDate()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cvd_osvdb where id >1800 and id<=10000 order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string UniDate = dscl.Tables[0].Rows[k]["Disclosure_Date"].ToString();
                        string UniYear = "";
                        string UniMonth = "";
                        string UniDay = "";
                        if (UniDate.Count() >= 10)
                        {
                            UniYear = UniDate.Substring(0, 4);
                            UniMonth = UniDate.Substring(5, 2);
                            UniDay = UniDate.Substring(8, 2);
                            UniDate = "UniDate = '" + UniYear + "/" + UniMonth + "/" + UniDay + "' ";
                        }

                        string where = UniDate;

                        string SQLSentence = string.Format("update cvd_osvdb set {0} where {1}", where, idstr);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void EDB_Pro_UniDate()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from edb where id >14693 and id<=30000 order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string UniDate = dscl.Tables[0].Rows[k]["Published"].ToString();
                        string UniYear = "";
                        string UniMonth = "";
                        string UniDay = "";
                        if (UniDate.Count() >= 10)
                        {
                            //Published: 2003-03-30
                            UniYear = UniDate.Substring(11, 4);
                            UniMonth = UniDate.Substring(16, 2);
                            UniDay = UniDate.Substring(19, 2);
                            UniDate = "UniDate = '" + UniYear + "/" + UniMonth + "/" + UniDay + "' ";
                        }

                        string where = UniDate;

                        string SQLSentence = string.Format("update edb set {0} where {1}", where, idstr);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void EDB_Pro_UniDate2()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from edb where id >14691 and id<=30000 order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string UniDate = dscl.Tables[0].Rows[k]["date"].ToString();
                        string UniYear = "";
                        string UniMonth = "";
                        string UniDay = "";
                        if (UniDate.Count() <= 10 && UniDate.Count() > 0)
                        {
                            //2010/8/20
                            int index = UniDate.IndexOf("/");
                            UniYear = UniDate.Substring(0,index);
                            if (UniYear.Count() == 1)
                                UniYear = "0" + UniYear;
                            string temp = UniDate.Substring(index+1);
                            index = temp.IndexOf("/");
                            UniMonth = temp.Substring(0, index);
                            if (UniMonth.Count() == 1)
                                UniMonth = "0" + UniMonth;
                            UniDay = temp.Substring(index+1);
                            if (UniDay.Count() == 1)
                                UniDay = "0" + UniDay;

                            UniDate = "UniDate = '" + UniYear + "/" + UniMonth + "/" + UniDay + "' ";
                        }

                        string where = UniDate;
                        if (where.Count() > 0)
                        {
                            where = "set " + where;
                            string SQLSentence = string.Format("update edb {0} where {1}", where, idstr);
                            OpSQLWrite(SQLSentence);
                        }

                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void CXSecurity_Pro()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from CXSecurity_Pro where id>500 and id<=17354 order by id";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string UniDate = (string)dscl.Tables[0].Rows[k]["Published"];
                        string UniYear = "";
                        string UniMonth = "";
                        string UniDay = "";
                        if (UniDate.Count() >= 10)
                        {
                            UniYear = UniDate.Substring(0, 4);
                            UniMonth = UniDate.Substring(5, 2);
                            UniDay = UniDate.Substring(8,2);
                            UniDate = "UniDate = '" + UniYear + "/" + UniMonth + "/" + UniDay + "' ";
                        }
                                               

                        string UniTitle = (string)dscl.Tables[0].Rows[k]["title"];
                        int a = UniTitle.Count();
                        if (a >= 5)
                            UniTitle = UniTitle.Substring(0, a - 5);
                        //title = title.Trim();
                        UniTitle = UniTitle.Replace("'", "''");
                        UniTitle = "UniTitle = '" + UniTitle + "' ";


                        string where = UniDate;
                        if (UniTitle != "" && UniTitle != null)
                            where = where + ", " + UniTitle;

                        string SQLSentence = string.Format("update CXSecurity_Pro set {0} where {1}", where, idstr);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Sebug_Pro()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from Sebug_Pro where id>100 and id<=20955 order by id";//20955
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string UniDate = (string)dscl.Tables[0].Rows[k]["Public_Time"];
                        string UniYear = "";
                        string UniMonth = "";
                        string UniDay = "";
                        if (UniDate.Count() >= 10)
                        {
                            UniYear = UniDate.Substring(6, 4);
                            UniMonth = UniDate.Substring(11, 2);
                            UniDay = UniDate.Substring(14, 2);
                            UniDate = "UniDate = '" + UniYear + "/" + UniMonth + "/" + UniDay + "' ";
                        }


                        string UniTitle = (string)dscl.Tables[0].Rows[k]["title"];
                        UniTitle = UniTitle.Replace("'", "''");
                        UniTitle = "UniTitle = '" + UniTitle + "' ";

                        string UniPoc = (string)dscl.Tables[0].Rows[k]["Method"];
                        UniPoc = UniPoc.Replace("'", "''");
                        UniPoc = "UniPoc = '" + UniPoc + "' ";


                        string where = UniDate;
                        if (UniTitle != "" && UniTitle != null && where != "" && where != null)
                            where = where + ", " + UniTitle;
                        else if (UniTitle != "" && UniTitle != null)
                            where = UniTitle;
                        if (UniPoc != "" && UniPoc != null && where != "" && where != null)
                            where = where + ", " + UniPoc;
                        else if (UniPoc != "" && UniPoc != null)
                            where = UniPoc;

                        if (where != "" && where != null)
                            where = "set " + where;

                        string SQLSentence = string.Format("update Sebug_Pro {0} where {1}", where, idstr);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Add_Cvd()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cvd_osvdb where UniDate>'2003/06/02' and UniDate<='2007/11/27' order by UniDate, title";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    int start = 10184;
                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string UniDate = dscl.Tables[0].Rows[k]["UniDate"].ToString();
                        UniDate = "UniDate = '" + UniDate + "' ";
                        string UniTitle = dscl.Tables[0].Rows[k]["title"].ToString();
                        UniTitle = "title = '" + UniTitle + "' ";

                        int intcvd = start + k;
                        string cvd = "cvd = " + intcvd.ToString() + " ";
                        string where = cvd;

                        string SQLSentence = string.Format("update cvd_osvdb set {0} where {1} and {2}", where, UniDate, UniTitle);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Add_idInsertCx()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    string SQLSentence = "";
                    com.CommandText = string.Format("select * from CXSecurity_Pro where UniDate>'' and UniDate<='2013/12/31' and not (cve like 'CVE-%' or cve like '%CVE-%') and poc <> '' order by UniDate, datetime");
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    SQLSentence = "select count(*) from cvd_osvdb";
                    int start = OpSQLGetInt(SQLSentence);
                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scCx = "'no_cve'";
                        string UniDate = "'" + dscl.Tables[0].Rows[k]["UniDate"].ToString() + "'";
                        string datetime = "'" + dscl.Tables[0].Rows[k]["datetime"].ToString() + "'";

                        string UniTitle = dscl.Tables[0].Rows[k]["UniTitle"].ToString();
                        UniTitle = UniTitle.Replace("'", "''");
                        UniTitle = "'" + UniTitle + "'";

                        string UniPoc = dscl.Tables[0].Rows[k]["POC"].ToString();
                        UniPoc = UniPoc.Replace("'", "''");
                        UniPoc = "'" + UniPoc + "'";

                        string volReferences1 = dscl.Tables[0].Rows[k]["volReferences1"].ToString();
                        volReferences1 = volReferences1.Replace("'", "''");
                        string volReferences2 = dscl.Tables[0].Rows[k]["volReferences2"].ToString();
                        volReferences2 = volReferences1.Replace("'", "''");
                        string UniRefs = "";
                        if (volReferences1 != "")
                            UniRefs = UniRefs + volReferences1 + "\n";
                        if (volReferences2 != "")
                            UniRefs = UniRefs + volReferences2 + "\n";
                        UniRefs = "'" + UniRefs + "'";


                        int intidInsert = start + k + 1;
                        string idInsert = intidInsert.ToString();

                        string values = idInsert.ToString() + "," + scCx;
                        if (UniTitle != "")
                            values = values + "," + UniTitle;
                        if (UniDate != "")
                            values = values + "," + UniDate;
                        if (datetime != "")
                            values = values + "," + datetime;
                        if (UniPoc != "")
                            values = values + "," + UniPoc;
                        if (UniRefs != "")
                            values = values + "," + UniRefs;
                        values = "(" + values + ")";

                        SQLSentence = string.Format("insert into cvd_osvdb (idInsert,scCx,title,UniDate,datetime,poc,UniRefs) values {0}",values);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Add_idInsertSe()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    string SQLSentence = "";
                    com.CommandText = string.Format("select * from Sebug_Pro where UniDate>'' and UniDate<='2013/12/31' and not (cve like 'CVE-%' or cve like '%CVE-%') and UniPoc <> '' order by UniDate, datetime");
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    SQLSentence = "select count(*) from cvd_osvdb";
                    int start = OpSQLGetInt(SQLSentence);
                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scSe = "'no_cve'";
                        string UniDate = "'" + dscl.Tables[0].Rows[k]["UniDate"].ToString() + "'";
                        string datetime = "'" + dscl.Tables[0].Rows[k]["datetime"].ToString() + "'";

                        string UniTitle = dscl.Tables[0].Rows[k]["UniTitle"].ToString();
                        UniTitle = UniTitle.Replace("'", "''");
                        UniTitle = "'" + UniTitle + "'";

                        string UniPoc = dscl.Tables[0].Rows[k]["UniPoc"].ToString();
                        UniPoc = UniPoc.Replace("'", "''");
                        UniPoc = "'" + UniPoc + "'";

                        string UniRefs = dscl.Tables[0].Rows[k]["reference"].ToString();
                        UniRefs = UniRefs.Replace("'", "''");
                        UniRefs = "'" + UniRefs + "'";

                        int intidInsert = start + k + 1;
                        string idInsert = intidInsert.ToString();

                        string values = idInsert.ToString() + "," + scSe;
                        if (UniTitle != "")
                            values = values + "," + UniTitle;
                        if (UniDate != "")
                            values = values + "," + UniDate;
                        if (datetime != "")
                            values = values + "," + datetime;
                        if (UniPoc != "")
                            values = values + "," + UniPoc;
                        if (UniRefs != "")
                            values = values + "," + UniRefs;
                        values = "(" + values + ")";

                        SQLSentence = string.Format("insert into cvd_osvdb (idInsert,scSe,title,UniDate,datetime,poc,UniRefs) values {0}", values);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void OSVDB_Pro_cvss()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cvd_osvdb where CVSS_Score like 'CVSS%'  order by idInsert";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string CVSS_Score = dscl.Tables[0].Rows[k]["CVSS_Score"].ToString();
                        //CVSSv2 Base Score = 7.5
                        CVSS_Score = "CVSS_Score = '" + CVSS_Score.Replace("'", "''").Substring(20) + "'";


                        string where = CVSS_Score;

                        string SQLSentence = string.Format("update cvd_osvdb set {0} where {1}", where, idstr);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void OSVDB_Pro_solution()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cvd_osvdb where id > 100 and id <= 100000 order by idInsert";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        //string CVSS_Score = dscl.Tables[0].Rows[k]["CVSS_Score"].ToString();
                        ////CVSSv2 Base Score = 7.5
                        //CVSS_Score = "CVSS_Score = '" + CVSS_Score.Replace("'", "''").Substring(20) + "'";

                        string CLocation = dscl.Tables[0].Rows[k]["CLocation"].ToString();
                        CLocation = CLocation.Replace("'","''");
                        if (CLocation.Count()>=2 && CLocation.Substring(0, 2) == ":\n")
                            CLocation = CLocation.Substring(2);
                        CLocation = "CLocation = '" + CLocation + "' ";

                        string CAttack_Type = dscl.Tables[0].Rows[k]["CAttack_Type"].ToString();
                        CAttack_Type = CAttack_Type.Replace("'", "''");
                        if (CAttack_Type.Count() >= 2 && CAttack_Type.Substring(0, 2) == ":\n")
                            CAttack_Type = CAttack_Type.Substring(2);
                        CAttack_Type = "CAttack_Type = '" + CAttack_Type + "' ";

                        string CImpact = dscl.Tables[0].Rows[k]["CImpact"].ToString();
                        CImpact = CImpact.Replace("'", "''");
                        if (CImpact.Count() >= 2 && CImpact.Substring(0, 2) == ":\n")
                            CImpact = CImpact.Substring(2);
                        CImpact = "CImpact = '" + CImpact + "' ";

                        string CSolution = dscl.Tables[0].Rows[k]["CSolution"].ToString();
                        CSolution = CSolution.Replace("'", "''");
                        if (CSolution.Count() >= 2 && CSolution.Substring(0, 2) == ":\n")
                            CSolution = CSolution.Substring(2);
                        CSolution = "CSolution = '" + CSolution + "' ";

                        string CExploit = dscl.Tables[0].Rows[k]["CExploit"].ToString();
                        CExploit = CExploit.Replace("'", "''");
                        if (CExploit.Count() >= 2 && CExploit.Substring(0, 2) == ":\n")
                            CExploit = CExploit.Substring(2);
                        CExploit = "CExploit = '" + CExploit + "' ";

                        string CDisclosure = dscl.Tables[0].Rows[k]["CDisclosure"].ToString();
                        CDisclosure = CDisclosure.Replace("'", "''");
                        if (CDisclosure.Count() >= 2 && CDisclosure.Substring(0, 2) == ":\n")
                            CDisclosure = CDisclosure.Substring(2);
                        CDisclosure = "CDisclosure = '" + CDisclosure + "' ";

                        string COSVDB = dscl.Tables[0].Rows[k]["COSVDB"].ToString();
                        COSVDB = COSVDB.Replace("'", "''");
                        if (COSVDB.Count() >= 2 && COSVDB.Substring(0, 2) == ":\n")
                            COSVDB = COSVDB.Substring(2);
                        COSVDB = "COSVDB = '" + COSVDB + "' ";

                        string Solution = dscl.Tables[0].Rows[k]["Solution"].ToString();
                        Solution = Solution.Replace("'", "''");
                        Solution = Solution.Replace("OSVDB","CVD");
                        Solution = "Solution = '" + Solution + "' ";

                        string where = CLocation;
                        if (where != "" && CAttack_Type != "")
                            where = where + ", ";
                        where = where + CAttack_Type;
                        if (where != "" && CImpact != "")
                            where = where + ", ";
                        where = where + CImpact;
                        if (where != "" && CSolution != "")
                            where = where + ", ";
                        where = where + CSolution;
                        if (where != "" && CExploit != "")
                            where = where + ", ";
                        where = where + CExploit;
                        if (where != "" && CDisclosure != "")
                            where = where + ", ";
                        where = where + CDisclosure;
                        if (where != "" && COSVDB != "")
                            where = where + ", ";
                        where = where + COSVDB;

                        string SQLSentence = "";
                        if (where != "")
                        {
                            SQLSentence = "update cvd_osvdb set " + where + " where " + idstr;
                            OpSQLWrite(SQLSentence);
                        }

                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void OSVDB_Pro_solution2()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = "select * from cvd_osvdb where solution like '%OSVDB' or solution like 'OSVDB%' or solution like '%OSVDB%' order by idInsert";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "id = " + idstr + " ";

                        string Solution = dscl.Tables[0].Rows[k]["Solution"].ToString();
                        Solution = Solution.Replace("'", "''");
                        Solution = Solution.Replace("OSVDB", "CVD");
                        Solution = "Solution = '" + Solution + "' ";

                        string where = Solution;


                        string SQLSentence = "";
                        if (where != "")
                        {
                            SQLSentence = "update cvd_osvdb set " + where + " where " + idstr;
                            OpSQLWrite(SQLSentence);
                        }

                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void Add_idInsertEDB()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    string SQLSentence = "";
                    com.CommandText = string.Format("select * from edb_Pro where UniDate>'' and UniDate<='2013/12/31' and not (cve <> '' or osvdb_id <> '')  or (cve = 'N/A' and osvdb_id = 'N/A') and id > 14000 order by id");
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    SQLSentence = "select count(*) from cvd_osvdb";
                    int start = OpSQLGetInt(SQLSentence);
                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scEd = "'no_cve'";
                        string UniDate = "'" + dscl.Tables[0].Rows[k]["UniDate"].ToString() + "'";
                        string datetime = "'" + dscl.Tables[0].Rows[k]["datetime"].ToString() + "'";

                        string UniTitle = dscl.Tables[0].Rows[k]["title"].ToString();
                        UniTitle = UniTitle.Replace("'", "''");
                        UniTitle = "'" + UniTitle + "'";

                        //string UniPoc = dscl.Tables[0].Rows[k]["POC"].ToString();
                        //UniPoc = UniPoc.Replace("'", "''");
                        //UniPoc = "'" + UniPoc + "'";

                        string UniRefs = dscl.Tables[0].Rows[k]["Vulnerable_App_Ref"].ToString();
                        UniRefs = UniRefs.Replace("'", "''");
                        UniRefs = "'" + UniRefs + "'";

                        string path = dscl.Tables[0].Rows[k]["path"].ToString();
                        path = path.Replace("'", "''");
                        path = "'" + path + "'";

                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "'" + idstr + "'";

                        int intidInsert = start + k + 1;
                        string idInsert = intidInsert.ToString();

                        string values = idInsert.ToString() + "," + scEd;
                        if (UniTitle != "")
                            values = values + "," + UniTitle;
                        if (UniDate != "")
                            values = values + "," + UniDate;
                        if (datetime != "")
                            values = values + "," + datetime;
                        if (UniRefs != "")
                            values = values + "," + UniRefs;
                        if (idstr != "")
                            values = values + "," + idstr;
                        if (path != "")
                            values = values + "," + path;
                        values = "(" + values + ")";


                        SQLSentence = string.Format("insert into cvd_osvdb (idInsert,scEd,title,UniDate,datetime,UniRefs,edb,path) values {0}", values);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                    MessageBox.Show("下载完毕");
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }

        public static void EDB_id_ToOSVDB_cve()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    //com.CommandText = "select * from CXSecurity_Pro where (cve <> '' and POC <> '' and id >100 and id <= 1000) order by id";
                    com.CommandText = "select * from edb_Pro where (cve <> '' or osvdb_id <> '') and not (cve = 'N/A' and osvdb_id = 'N/A') and id > 24322 order by UniDate, datetime";
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    //for (int k = 0; k < 10; k++)
                    {
                        string scEd = "scEd = 'yes' ";

                        //string SQLSentence = string.Format("update cvd set Translations = '{0}' where cve = '{1}'", dscl.Tables[0].Rows[k]["Description"], dscl.Tables[0].Rows[k]["CVE"]);
                        string cve = (string)dscl.Tables[0].Rows[k]["cve"];
                        //CVE-2001-1183
                        if (cve == "N/A")
                            cve = "xxxxxxx";
                        cve = "right(cve,4) = '" + cve + "'";
                        string osvdb_id = (string)dscl.Tables[0].Rows[k]["osvdb_id"];
                        if (osvdb_id == "N/A")
                            osvdb_id = "0";
                        osvdb_id = "id = '" + osvdb_id + "'";

                        string idstr = dscl.Tables[0].Rows[k]["id"].ToString();
                        idstr = "edb = " + idstr + "";

                        string path = dscl.Tables[0].Rows[k]["path"].ToString();
                        path = path.Replace("'", "''");
                        path = "path = '" + path + "'";

                        string where = scEd;
                        if (where != "" && idstr != null)
                            where = where + ", " + idstr;
                        if (where != "" && path != null)
                            path = where + ", " + path;


                        if (where != "" && where != null)
                            where = "set " + where;

                        
                        string SQLSentence = string.Format("update cvd_osvdb {0} where {1} or {2}", where, cve, osvdb_id);
                        OpSQLWrite(SQLSentence);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    //da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }
        }


        public static DataSet OpSQLWrite(string SQLSentence)
        {
            DataSet ds = new DataSet();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    com.ExecuteNonQuery();

                    //SqlDataAdapter da = new SqlDataAdapter(com);
                    ////DataSet dscl = new DataSet();
                    //da.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return ds;
        }

        public static int OpSQLGetInt(string SQLSentence)
        {
            DataSet ds = new DataSet();
            int urlnum = -1;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    //string SQLSentence = "select count(*) from cvd_osvdb2";
                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    //com.ExecuteNonQuery();

                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    urlnum = dr.GetInt32(0);
                    //urlnum = dr.GetInt64(0);
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlnum;
        }

        public static Double OpSQLGetInt64(string SQLSentence)
        {
            DataSet ds = new DataSet();
            Double urlnum = -1;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    //string SQLSentence = "select count(*) from cvd_osvdb2";
                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    //com.ExecuteNonQuery();

                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    urlnum = dr.GetInt64(0);
                    //urlnum = dr.GetInt64(0);
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlnum;
        }



        public static string OpSQLGetString(string SQLSentence)
        {
            //List<Uri> urlIndex = new List<Uri>();
            string urlnum = "";
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dscl);
                    urlnum = (string)dscl.Tables[0].Rows[0][0];
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlnum;
        }

        public static DataSet OpSQLGetTable(string SQLSentence)
        {
            //List<Uri> urlIndex = new List<Uri>();
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP + ";database=" + VolOverAll.DataBaseName + ";uid=" + VolOverAll.DataUid + ";pwd=" + VolOverAll.DataPassword;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dscl);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return dscl;
        }
 
    }


}
