﻿using Aspose.Words;
using Aspose.Words.Drawing;
using Aspose.Words.Reporting;

namespace MyDoc
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateDoc = new System.Windows.Forms.Button();
            this.dateTimeStart = new System.Windows.Forms.DateTimePicker();
            this.开始日期 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimeEnd = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimeReport = new System.Windows.Forms.DateTimePicker();
            this.GongW = new System.Windows.Forms.Button();
            this.XinHua = new System.Windows.Forms.Button();
            this.XinHuaW = new System.Windows.Forms.Button();
            this.XinXiHua = new System.Windows.Forms.Button();
            this.statStart = new System.Windows.Forms.DateTimePicker();
            this.statEnd = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.statDate = new System.Windows.Forms.CheckBox();
            this.statDateTime = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.statDateTimeStart = new System.Windows.Forms.TextBox();
            this.statDateTimeEnd = new System.Windows.Forms.TextBox();
            this.SummaryText = new System.Windows.Forms.TextBox();
            this.MSSummaryText = new System.Windows.Forms.TextBox();
            this.XinWangAnZaZhi = new System.Windows.Forms.Button();
            this.GongAnBuM = new System.Windows.Forms.Button();
            this.KeYuanM = new System.Windows.Forms.Button();
            this.YuanWangXinM = new System.Windows.Forms.Button();
            this.MSMonth = new System.Windows.Forms.DateTimePicker();
            this.MS_Static = new System.Windows.Forms.Label();
            this.IfUpdate = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // CreateDoc
            // 
            this.CreateDoc.Location = new System.Drawing.Point(227, 11);
            this.CreateDoc.Name = "CreateDoc";
            this.CreateDoc.Size = new System.Drawing.Size(75, 23);
            this.CreateDoc.TabIndex = 0;
            this.CreateDoc.Text = "公安部周报";
            this.CreateDoc.UseVisualStyleBackColor = true;
            this.CreateDoc.Click += new System.EventHandler(this.CreateDoc_Click);
            // 
            // dateTimeStart
            // 
            this.dateTimeStart.Location = new System.Drawing.Point(83, 13);
            this.dateTimeStart.Name = "dateTimeStart";
            this.dateTimeStart.Size = new System.Drawing.Size(123, 21);
            this.dateTimeStart.TabIndex = 1;
            // 
            // 开始日期
            // 
            this.开始日期.AutoSize = true;
            this.开始日期.Location = new System.Drawing.Point(12, 18);
            this.开始日期.Name = "开始日期";
            this.开始日期.Size = new System.Drawing.Size(65, 12);
            this.开始日期.TabIndex = 2;
            this.开始日期.Text = "开始日期：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "结束日期：";
            // 
            // dateTimeEnd
            // 
            this.dateTimeEnd.Location = new System.Drawing.Point(83, 47);
            this.dateTimeEnd.Name = "dateTimeEnd";
            this.dateTimeEnd.Size = new System.Drawing.Size(123, 21);
            this.dateTimeEnd.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "报告日期：";
            // 
            // dateTimeReport
            // 
            this.dateTimeReport.Location = new System.Drawing.Point(83, 84);
            this.dateTimeReport.Name = "dateTimeReport";
            this.dateTimeReport.Size = new System.Drawing.Size(123, 21);
            this.dateTimeReport.TabIndex = 5;
            // 
            // GongW
            // 
            this.GongW.Location = new System.Drawing.Point(308, 11);
            this.GongW.Name = "GongW";
            this.GongW.Size = new System.Drawing.Size(109, 23);
            this.GongW.TabIndex = 9;
            this.GongW.Text = "公安部周报(微软)";
            this.GongW.UseVisualStyleBackColor = true;
            this.GongW.Click += new System.EventHandler(this.GongW_Click);
            // 
            // XinHua
            // 
            this.XinHua.Location = new System.Drawing.Point(228, 42);
            this.XinHua.Name = "XinHua";
            this.XinHua.Size = new System.Drawing.Size(75, 23);
            this.XinHua.TabIndex = 10;
            this.XinHua.Text = "新华网周报";
            this.XinHua.UseVisualStyleBackColor = true;
            this.XinHua.Click += new System.EventHandler(this.XinHua_Click);
            // 
            // XinHuaW
            // 
            this.XinHuaW.Location = new System.Drawing.Point(308, 42);
            this.XinHuaW.Name = "XinHuaW";
            this.XinHuaW.Size = new System.Drawing.Size(109, 23);
            this.XinHuaW.TabIndex = 11;
            this.XinHuaW.Text = "新华网周报(微软)";
            this.XinHuaW.UseVisualStyleBackColor = true;
            this.XinHuaW.Click += new System.EventHandler(this.XinHuaW_Click);
            // 
            // XinXiHua
            // 
            this.XinXiHua.Location = new System.Drawing.Point(228, 72);
            this.XinXiHua.Name = "XinXiHua";
            this.XinXiHua.Size = new System.Drawing.Size(189, 23);
            this.XinXiHua.TabIndex = 12;
            this.XinXiHua.Text = "信息化处月报(16号)";
            this.XinXiHua.UseVisualStyleBackColor = true;
            this.XinXiHua.Click += new System.EventHandler(this.XinXiHua_Click);
            // 
            // statStart
            // 
            this.statStart.Location = new System.Drawing.Point(83, 153);
            this.statStart.Name = "statStart";
            this.statStart.Size = new System.Drawing.Size(123, 21);
            this.statStart.TabIndex = 13;
            // 
            // statEnd
            // 
            this.statEnd.Location = new System.Drawing.Point(83, 187);
            this.statEnd.Name = "statEnd";
            this.statEnd.Size = new System.Drawing.Size(123, 21);
            this.statEnd.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 15;
            this.label3.Text = "统计开始：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 16;
            this.label4.Text = "统计结束：";
            // 
            // statDate
            // 
            this.statDate.AutoSize = true;
            this.statDate.Location = new System.Drawing.Point(14, 131);
            this.statDate.Name = "statDate";
            this.statDate.Size = new System.Drawing.Size(72, 16);
            this.statDate.TabIndex = 17;
            this.statDate.Text = "统计日期";
            this.statDate.UseVisualStyleBackColor = true;
            this.statDate.CheckedChanged += new System.EventHandler(this.statDate_CheckedChanged);
            // 
            // statDateTime
            // 
            this.statDateTime.AutoSize = true;
            this.statDateTime.Location = new System.Drawing.Point(14, 228);
            this.statDateTime.Name = "statDateTime";
            this.statDateTime.Size = new System.Drawing.Size(96, 16);
            this.statDateTime.TabIndex = 18;
            this.statDateTime.Text = "统计DateTime";
            this.statDateTime.UseVisualStyleBackColor = true;
            this.statDateTime.CheckedChanged += new System.EventHandler(this.statDateTime_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 19;
            this.label5.Text = "开始：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 20;
            this.label6.Text = "结束：";
            // 
            // statDateTimeStart
            // 
            this.statDateTimeStart.Location = new System.Drawing.Point(59, 250);
            this.statDateTimeStart.Name = "statDateTimeStart";
            this.statDateTimeStart.Size = new System.Drawing.Size(147, 21);
            this.statDateTimeStart.TabIndex = 21;
            // 
            // statDateTimeEnd
            // 
            this.statDateTimeEnd.Location = new System.Drawing.Point(59, 280);
            this.statDateTimeEnd.Name = "statDateTimeEnd";
            this.statDateTimeEnd.Size = new System.Drawing.Size(147, 21);
            this.statDateTimeEnd.TabIndex = 22;
            // 
            // SummaryText
            // 
            this.SummaryText.AcceptsReturn = true;
            this.SummaryText.AcceptsTab = true;
            this.SummaryText.Location = new System.Drawing.Point(437, 11);
            this.SummaryText.Multiline = true;
            this.SummaryText.Name = "SummaryText";
            this.SummaryText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SummaryText.Size = new System.Drawing.Size(127, 181);
            this.SummaryText.TabIndex = 23;
            // 
            // MSSummaryText
            // 
            this.MSSummaryText.Location = new System.Drawing.Point(590, 11);
            this.MSSummaryText.Multiline = true;
            this.MSSummaryText.Name = "MSSummaryText";
            this.MSSummaryText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.MSSummaryText.Size = new System.Drawing.Size(446, 334);
            this.MSSummaryText.TabIndex = 24;
            // 
            // XinWangAnZaZhi
            // 
            this.XinWangAnZaZhi.Location = new System.Drawing.Point(228, 102);
            this.XinWangAnZaZhi.Name = "XinWangAnZaZhi";
            this.XinWangAnZaZhi.Size = new System.Drawing.Size(189, 23);
            this.XinWangAnZaZhi.TabIndex = 25;
            this.XinWangAnZaZhi.Text = "信息安全杂志漏洞月报(21号)";
            this.XinWangAnZaZhi.UseVisualStyleBackColor = true;
            this.XinWangAnZaZhi.Click += new System.EventHandler(this.XinWangAnZaZhi_Click);
            // 
            // GongAnBuM
            // 
            this.GongAnBuM.Location = new System.Drawing.Point(228, 131);
            this.GongAnBuM.Name = "GongAnBuM";
            this.GongAnBuM.Size = new System.Drawing.Size(190, 23);
            this.GongAnBuM.TabIndex = 26;
            this.GongAnBuM.Text = "公安部月报(1号)";
            this.GongAnBuM.UseVisualStyleBackColor = true;
            this.GongAnBuM.Click += new System.EventHandler(this.GongAnBuM_Click);
            // 
            // KeYuanM
            // 
            this.KeYuanM.Location = new System.Drawing.Point(228, 160);
            this.KeYuanM.Name = "KeYuanM";
            this.KeYuanM.Size = new System.Drawing.Size(189, 23);
            this.KeYuanM.TabIndex = 27;
            this.KeYuanM.Text = "科院安全信息月报(1)";
            this.KeYuanM.UseVisualStyleBackColor = true;
            this.KeYuanM.Click += new System.EventHandler(this.KeYuanM_Click);
            // 
            // YuanWangXinM
            // 
            this.YuanWangXinM.Location = new System.Drawing.Point(228, 189);
            this.YuanWangXinM.Name = "YuanWangXinM";
            this.YuanWangXinM.Size = new System.Drawing.Size(189, 23);
            this.YuanWangXinM.TabIndex = 28;
            this.YuanWangXinM.Text = "院网络信息通报(1)";
            this.YuanWangXinM.UseVisualStyleBackColor = true;
            this.YuanWangXinM.Click += new System.EventHandler(this.YuanWangXinM_Click);
            // 
            // MSMonth
            // 
            this.MSMonth.Location = new System.Drawing.Point(83, 318);
            this.MSMonth.Name = "MSMonth";
            this.MSMonth.Size = new System.Drawing.Size(123, 21);
            this.MSMonth.TabIndex = 29;
            // 
            // MS_Static
            // 
            this.MS_Static.AutoSize = true;
            this.MS_Static.Location = new System.Drawing.Point(12, 324);
            this.MS_Static.Name = "MS_Static";
            this.MS_Static.Size = new System.Drawing.Size(71, 12);
            this.MS_Static.TabIndex = 30;
            this.MS_Static.Text = "MS_Static：";
            // 
            // IfUpdate
            // 
            this.IfUpdate.AutoSize = true;
            this.IfUpdate.Location = new System.Drawing.Point(228, 228);
            this.IfUpdate.Name = "IfUpdate";
            this.IfUpdate.Size = new System.Drawing.Size(72, 16);
            this.IfUpdate.TabIndex = 31;
            this.IfUpdate.Text = "是否更新";
            this.IfUpdate.UseVisualStyleBackColor = true;
            this.IfUpdate.CheckedChanged += new System.EventHandler(this.IfUpdate_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 357);
            this.Controls.Add(this.IfUpdate);
            this.Controls.Add(this.MS_Static);
            this.Controls.Add(this.MSMonth);
            this.Controls.Add(this.YuanWangXinM);
            this.Controls.Add(this.KeYuanM);
            this.Controls.Add(this.GongAnBuM);
            this.Controls.Add(this.XinWangAnZaZhi);
            this.Controls.Add(this.MSSummaryText);
            this.Controls.Add(this.SummaryText);
            this.Controls.Add(this.statDateTimeEnd);
            this.Controls.Add(this.statDateTimeStart);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.statDateTime);
            this.Controls.Add(this.statDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.statEnd);
            this.Controls.Add(this.statStart);
            this.Controls.Add(this.XinXiHua);
            this.Controls.Add(this.XinHuaW);
            this.Controls.Add(this.XinHua);
            this.Controls.Add(this.GongW);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimeReport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimeEnd);
            this.Controls.Add(this.开始日期);
            this.Controls.Add(this.dateTimeStart);
            this.Controls.Add(this.CreateDoc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CreateDoc;
        public System.Windows.Forms.DateTimePicker dateTimeStart;
        private System.Windows.Forms.Label 开始日期;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.DateTimePicker dateTimeEnd;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.DateTimePicker dateTimeReport;

        DataSubmit datasubmit = new DataSubmit();
        public Bookmark mark1;
        public Document doc;
        private System.Windows.Forms.Button GongW;
        private System.Windows.Forms.Button XinHua;
        private System.Windows.Forms.Button XinHuaW;
        private System.Windows.Forms.Button XinXiHua;

        private System.Windows.Forms.DateTimePicker statStart;
        private System.Windows.Forms.DateTimePicker statEnd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox statDate;
        private System.Windows.Forms.CheckBox statDateTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox statDateTimeStart;
        private System.Windows.Forms.TextBox statDateTimeEnd;
        private System.Windows.Forms.TextBox SummaryText;
        private System.Windows.Forms.TextBox MSSummaryText;
        private System.Windows.Forms.Button XinWangAnZaZhi;
        private System.Windows.Forms.Button GongAnBuM;
        private System.Windows.Forms.Button KeYuanM;
        private System.Windows.Forms.Button YuanWangXinM;

        public string GongAnBuWS = "D:\\模板-国家计算机网络入侵防范中心（2月08日至2月14日).doc";
        public string GongAnBuWD = "";
        public string XinXiHuaChuMonthSdan = "D:\\模板-国家计算机网络入侵防范中心六月至八月十大安全漏洞通报 _单栏_双月版.doc";
        public string XinXiHuaChuMonthDdan = "";
        public string XinXiHuaChuMonthSshuang = "D:\\模板-国家计算机网络入侵防范中心六月至八月十大安全漏洞通报 _双栏_双月版.doc";
        public string XinXiHuaChuMonthDshuang = "";
        public string XinWangAnZhaZhiS = "D:\\模板-国家计算机网络入侵防范中心三月份十大安全漏洞通报（2013年）.doc";
        public string XinWangAnZhaZhiD = "";
        public string GongAnBuMonthS = "d:\\模板-2013年09月份十大重要漏洞.doc";
        public string GongAnBuMonthD = "";
        public string KeYuanMonthS = "d:\\模板-国家计算机网络入侵防范中心_2013年09月安全漏洞信息月报.doc";
        public string KeYuanMonthD = "";
        public string YuanWangXinS = "d:\\模板-院网络与信息情况通报（2013年第10期-总第三十八期）20131001.doc";
        public string YuanWangXinD = "";
        public string XinHuaWangSwan = "d:\\模板-2013年10月01日至2013年10月14日漏洞报告_完整版.doc";
        public string XinHuaWangDwan = "";
        public string XinHuaWangSzi = "d:\\模板-2013年10月01日至2013年10月14日漏洞报告_字幕版.doc";
        public string XinHuaWangDzi = "";
        private System.Windows.Forms.DateTimePicker MSMonth;
        private System.Windows.Forms.Label MS_Static;
        private System.Windows.Forms.CheckBox IfUpdate;
    }
}

