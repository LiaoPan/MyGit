﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using Aspose.Words;
using Aspose.Words.Drawing;
using Aspose.Words.Reporting;
//using Aspose.Words.Viewer;

using System.Collections;
using System.Configuration;
using System.Web;
using System.Text.RegularExpressions;

namespace MyDoc
{
    public partial class Form1 : Form
    {

        
        public Form1()
        {
            InitializeComponent();
        }

        private void CreateDoc_Click(object sender, EventArgs e)
        {
            GetMyDate();
            GetMySummary("NVD_LogWeek");
            GetMyTable();

            GongAnBuWD = "d:\\国家计算机网络入侵防范中心（" + datasubmit.StartYear.ToString() + "年" + datasubmit.StartMonth.ToString() + "月" + datasubmit.StartDay.ToString() + "日至" + datasubmit.EndYear.ToString() + "年" + datasubmit.EndMonth.ToString() + "月" + datasubmit.EndDay.ToString() + "日).doc";
            MyCopyDoc(GongAnBuWS, GongAnBuWD);

            if (!File.Exists(GongAnBuWD))
            {
                MessageBox.Show("文件不存在");
            }

            doc = new Document(GongAnBuWD);

            SetMyDate();
            SetMySummary();
            SetMyTable();

            doc.Save(GongAnBuWD);
        }

        public void GetMyDate()
        {
            DBManager.IfUpdate = IfUpdate.Checked;
            datasubmit.StartYear = dateTimeStart.Value.Year;
            datasubmit.StartMonth = dateTimeStart.Value.Month;
            datasubmit.StartDay = dateTimeStart.Value.Day;
            datasubmit.EndYear = dateTimeEnd.Value.Year;
            datasubmit.EndMonth = dateTimeEnd.Value.Month;
            datasubmit.EndDay = dateTimeEnd.Value.Day;
            datasubmit.ReportYear = dateTimeReport.Value.Year;
            datasubmit.ReportMonth = dateTimeReport.Value.Month;
            datasubmit.ReportDay = dateTimeReport.Value.Day;

            datasubmit.StatStartYear = statStart.Value.Year.ToString();
            if (datasubmit.StatStartYear.Count() == 1)
                datasubmit.StatStartYear = "0" + datasubmit.StatStartYear;
            datasubmit.StatStartMonth = statStart.Value.Month.ToString();
            if (datasubmit.StatStartMonth.Count() == 1)
                datasubmit.StatStartMonth = "0" + datasubmit.StatStartMonth;
            datasubmit.StatStartDate = statStart.Value.Day.ToString();
            if (datasubmit.StatStartDate.Count() == 1)
                datasubmit.StatStartDate = "0" + datasubmit.StatStartDate;
            datasubmit.StatEndYear = statEnd.Value.Year.ToString();
            if (datasubmit.StatEndYear.Count() == 1)
                datasubmit.StatEndYear = "0" + datasubmit.StatEndYear;
            datasubmit.StatEndMonth = statEnd.Value.Month.ToString();
            if (datasubmit.StatEndMonth.Count() == 1)
                datasubmit.StatEndMonth = "0" + datasubmit.StatEndMonth;
            datasubmit.StatEndDate = statEnd.Value.Day.ToString();
            if (datasubmit.StatEndDate.Count() == 1)
                datasubmit.StatEndDate = "0" + datasubmit.StatEndDate;
        }

        public void SetMyDate()
        {
            if (doc.Range.Bookmarks[BookMarks.StartYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.StartYear];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.StartMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.StartMonth];
                mark1.Text = datasubmit.StartMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.StartDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.StartDay];
                mark1.Text = datasubmit.StartDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.EndYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.EndYear];
                mark1.Text = datasubmit.EndYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.EndMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.EndMonth];
                mark1.Text = datasubmit.EndMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.EndDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.EndDay];
                mark1.Text = datasubmit.EndDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.ReportYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.ReportYear];
                mark1.Text = datasubmit.ReportYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.ReportMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.ReportMonth];
                mark1.Text = datasubmit.ReportMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.ReportDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.ReportDay];
                mark1.Text = datasubmit.ReportDay.ToString();
            }
        }

        public void SetMyDateMG()
        {
            if (doc.Range.Bookmarks[BookMarksMG.StartYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.StartYear];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.StartMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.StartMonth];
                mark1.Text = datasubmit.StartMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.StartDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.StartDay];
                mark1.Text = datasubmit.StartDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.EndYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.EndYear];
                mark1.Text = datasubmit.EndYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.EndMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.EndMonth];
                mark1.Text = datasubmit.EndMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.EndDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.EndDay];
                mark1.Text = datasubmit.EndDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.ReportYear1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.ReportYear1];
                mark1.Text = datasubmit.ReportYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.ReportMonth1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.ReportMonth1];
                mark1.Text = datasubmit.ReportMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.ReportDay1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.ReportDay1];
                mark1.Text = datasubmit.ReportDay.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.ReportYear2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.ReportYear2];
                mark1.Text = datasubmit.ReportYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.ReportMonth2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.ReportMonth2];
                mark1.Text = datasubmit.ReportMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMG.ReportDay2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.ReportDay2];
                mark1.Text = datasubmit.ReportDay.ToString();
            }
        }

        public void SetMyDateMX()
        {
            if (doc.Range.Bookmarks[BookMarksMX.StartYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMX.StartYear];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMX.StartMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMX.StartMonth];
                mark1.Text = datasubmit.StartMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMX.EndMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMX.EndMonth];
                mark1.Text = datasubmit.EndMonth.ToString();
            }
        }

        public void SetMyDateMXW()
        {
            if (doc.Range.Bookmarks[BookMarksMXW.EndYear1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndYear1];
                mark1.Text = datasubmit.EndYear.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndYear2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndYear2];
                mark1.Text = datasubmit.EndYear.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndYear3] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndYear3];
                mark1.Text = datasubmit.EndYear.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndYear4] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndYear4];
                mark1.Text = datasubmit.EndYear.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndMonth1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndMonth1];
                mark1.Text = datasubmit.EndMonth.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndMonth2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndMonth2];
                mark1.Text = datasubmit.EndMonth.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndMonth3] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndMonth3];
                mark1.Text = datasubmit.EndMonth.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMXW.EndMonth4] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMXW.EndMonth4];
                mark1.Text = datasubmit.EndMonth.ToString();
            }
        }

        public void SetMyDateMK()
        {
            if (doc.Range.Bookmarks[BookMarksMK.StartYear1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.StartYear1];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMK.StartMonth1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.StartMonth1];
                mark1.Text = datasubmit.StartMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMK.StartDay1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.StartDay1];
                mark1.Text = datasubmit.StartDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMK.StartYear2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.StartYear2];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMK.StartMonth2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.StartMonth2];
                mark1.Text = datasubmit.StartMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMK.EndMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.EndMonth];
                mark1.Text = datasubmit.EndMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMK.EndDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.EndDay];
                mark1.Text = datasubmit.EndDay.ToString();
            }
        }

        public void SetMyDateMYW()
        {
            if (doc.Range.Bookmarks[BookMarksMYW.StartYear1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.StartYear1];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.StartMonth1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.StartMonth1];
                int a = datasubmit.StartMonth+1;
                mark1.Text = a.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.StartDay1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.StartDay1];
                mark1.Text = datasubmit.StartDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.StartYear2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.StartYear2];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.StartMonth2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.StartMonth2];
                mark1.Text = datasubmit.StartMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.StartDay2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.StartDay2];
                mark1.Text = datasubmit.StartDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.EndMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.EndMonth];
                mark1.Text = datasubmit.EndMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.EndDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.EndDay];
                mark1.Text = datasubmit.EndDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.ReportYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.ReportYear];
                mark1.Text = datasubmit.ReportYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.ReportMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.ReportMonth];
                mark1.Text = datasubmit.ReportMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksMYW.ReportDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.ReportDay];
                mark1.Text = datasubmit.ReportDay.ToString();
            }
        }

        public void SetMyDateWXHW()
        {
            if (doc.Range.Bookmarks[BookMarksWXHW.StartYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.StartYear];
                mark1.Text = datasubmit.StartYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.StartMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.StartMonth];
                int a = datasubmit.StartMonth;
                mark1.Text = a.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.StartDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.StartDay];
                mark1.Text = datasubmit.StartDay.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.EndYear] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.EndYear];
                mark1.Text = datasubmit.EndYear.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.EndMonth] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.EndMonth];
                mark1.Text = datasubmit.EndMonth.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.EndDay] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.EndDay];
                mark1.Text = datasubmit.EndDay.ToString();
            }

        }

        public void GetMySummary(string NVDLog)
        {
            DBManager.IfUpdate = IfUpdate.Checked;
            string statStartDate = datasubmit.StatStartYear + "/" + datasubmit.StatStartMonth + "/" + datasubmit.StatStartDate;
            string statEndDate = datasubmit.EndYear + "/" + datasubmit.StatEndMonth + "/" + datasubmit.StatEndDate;
            string statDateTimeStartstr = statDateTimeStart.Text;
            string statDateTimeEndstr = statDateTimeEnd.Text;
            DBManager.CountDataFromDB("NVD2", statStartDate, statEndDate, statDateTimeStartstr, statDateTimeEndstr, NVDLog);
            datasubmit.SevereNum = DBManager.numSevere.ToString();
            datasubmit.HighNum = DBManager.numHigh.ToString();
            datasubmit.SevereHighNum = (DBManager.numSevere + DBManager.numHigh).ToString();
            datasubmit.MiddleNum = DBManager.numMiddle.ToString();
            datasubmit.LowNum = DBManager.numLow.ToString();
            datasubmit.TotalNum = DBManager.numTotal.ToString();
            datasubmit.NetWorkNum = DBManager.numNetWork.ToString();
            datasubmit.AdjectionNum = DBManager.numAdjection.ToString();
            datasubmit.LocalNum = DBManager.numLocal.ToString();

            DBManager.CountLastDataFromDB(NVDLog);
            float f1 = (float)DBManager.numSevere + (float)DBManager.numHigh;
            float f2 = (float)DBManager.numSevereLast + (float)DBManager.numHighLast;
            float intHighNum = f1 / f2;
            f1 = (float)DBManager.numMiddle;
            f2 = (float)DBManager.numMiddleLast;
            float intMiddleNum = f1 / f2;
            f1 = (float)DBManager.numLow;
            f2 = (float)DBManager.numLowLast;
            float intLowNum = f1 / f2;
            f1 = (float)DBManager.numTotal;
            f2 = (float)DBManager.numTotalLast;
            float intTotalNum = f1 / f2;
            f1 = (float)DBManager.numSevere + (float)DBManager.numHigh;
            f2 = (float)DBManager.numTotal;
            float intHighPercent = f1 / f2;
            f1 = (float)DBManager.numSevere;
            f2 = (float)DBManager.numSevereLast;
            float intSevere2 = f1 / f2;
            f1 = (float)DBManager.numHigh;
            f2 = (float)DBManager.numHighLast;
            float intHigh2 = f1 / f2;

            if (intMiddleNum >= 1) { datasubmit.MiddleNumLast = string.Format("{0:0.00} 倍", intMiddleNum); }
            else { datasubmit.MiddleNumLast = string.Format("{0:0.00%} ", intMiddleNum); }

            if (intHighNum >= 1) { datasubmit.HighNumLast = string.Format("{0:0.00} 倍", intHighNum); }
            else { datasubmit.HighNumLast = string.Format("{0:0.00%} ", intHighNum); }

            if (intLowNum >= 1) { datasubmit.LowNumLast = string.Format("{0:0.00} 倍", intLowNum); }
            else { datasubmit.LowNumLast = string.Format("{0:0.00%} ", intLowNum); }

            if (intTotalNum >= 1) { datasubmit.TotalNumLast = string.Format("{0:0.00} 倍", intTotalNum); }
            else { datasubmit.TotalNumLast = string.Format("{0:0.00%} ", intTotalNum); }

            if (intSevere2 >= 1) { datasubmit.SevereLast2 = string.Format("{0:0.00} 倍", intSevere2); }
            else { datasubmit.SevereLast2 = string.Format("{0:0.00%} ", intSevere2); }

            if (intHigh2 >= 1) { datasubmit.HighLast2 = string.Format("{0:0.00} 倍", intHigh2); }
            else { datasubmit.HighLast2 = string.Format("{0:0.00%} ", intHigh2); }

            datasubmit.HighPercent = string.Format("{0:0.00%} ", intHighPercent);
            datasubmit.TotalDiffer = DBManager.numTotal - DBManager.numTotalLast;
            if (datasubmit.TotalDiffer > 0)
                datasubmit.TotalDifferStr = string.Format("比上月增加了{0}条", datasubmit.TotalDiffer);
            else if (datasubmit.TotalDiffer < 0)
                datasubmit.TotalDifferStr = string.Format("比上月减少了{0}条", -datasubmit.TotalDiffer);
            else if (datasubmit.TotalDiffer == 0)
                datasubmit.TotalDifferStr = string.Format("与上月相同");
            SetMySummaryText();
        }

        public void SetMySummaryText()
        {
            
            string str = "总：" + datasubmit.TotalNum;
            str = str + Environment.NewLine + "紧急：" + datasubmit.SevereNum;
            str = str + Environment.NewLine + "高：" + datasubmit.HighNum;
            str = str + Environment.NewLine + "中：" + datasubmit.MiddleNum;
            str = str + Environment.NewLine + "低：" + datasubmit.LowNum;
            str = str + Environment.NewLine;
            str = str + Environment.NewLine + "总：" + datasubmit.TotalNumLast;
            str = str + Environment.NewLine + "高：" + datasubmit.HighNumLast;
            str = str + Environment.NewLine + "中：" + datasubmit.MiddleNumLast;
            str = str + Environment.NewLine + "低：" + datasubmit.LowNumLast;
            str = str + Environment.NewLine;
            str = str + Environment.NewLine + "网络：" + datasubmit.NetWorkNum;
            str = str + Environment.NewLine + "局域网：" + datasubmit.AdjectionNum;
            str = str + Environment.NewLine + "本地：" + datasubmit.LocalNum;

            str = str + Environment.NewLine + "高/总：" + datasubmit.HighPercent;
            SummaryText.Text = str;
            SummaryText.Refresh();
        }

        public void SetMySummary(bool isMS = false)
        {
            GetMyMS();
            if (isMS == false)
            {
                if (doc.Range.Bookmarks[BookMarks.Atention] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.Atention];
                    mark1.Text = datasubmit.Atention.ToString();
                }
            }
            else 
            {
                if (doc.Range.Bookmarks[BookMarks.Atention] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.Atention];
                    mark1.Text = datasubmit.MSSummary + "用户可通过开启系统自动更新功能或到Microsoft 下载中心下载更新安装补丁程序，以保证系统安全性。";
                }
            }

            if (doc.Range.Bookmarks[BookMarks.HighNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.HighNum];
                //mark1.Text = datasubmit.HighNum.ToString();
                int highint = System.Int32.Parse(datasubmit.HighNum) + System.Int32.Parse(datasubmit.SevereNum);
                mark1.Text = highint.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.MiddleNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.MiddleNum];
                mark1.Text = datasubmit.MiddleNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.LowNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.LowNum];
                mark1.Text = datasubmit.LowNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.TotalNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.TotalNum];
                mark1.Text = datasubmit.TotalNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.HighNum_2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.HighNum_2];
                mark1.Text = datasubmit.HighNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.TotalNum_2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.TotalNum_2];
                mark1.Text = datasubmit.TotalNum.ToString();
            }

            if (doc.Range.Bookmarks[BookMarks.HighNumLast] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.HighNumLast];
                mark1.Text = datasubmit.HighNumLast.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.MiddleNumLast] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.MiddleNumLast];
                mark1.Text = datasubmit.MiddleNumLast.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.LowNumLast] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.LowNumLast];
                mark1.Text = datasubmit.LowNumLast.ToString();
            }
            if (doc.Range.Bookmarks[BookMarks.TotalNumLast] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarks.TotalNumLast];
                mark1.Text = datasubmit.TotalNumLast.ToString();
            }

        }

        public void SetMySummaryMG()
        {
            if (doc.Range.Bookmarks[BookMarksMG.SevereNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.SevereNum];
                mark1.Text = datasubmit.SevereNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.HighNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.HighNum];
                mark1.Text = datasubmit.HighNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.MiddleNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.MiddleNum];
                mark1.Text = datasubmit.MiddleNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.LowNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.LowNum];
                mark1.Text = datasubmit.LowNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.TotalNum] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.TotalNum];
                mark1.Text = datasubmit.TotalNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.HighNum_2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.HighNum_2];
                mark1.Text = datasubmit.HighNum.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMG.TotalNum_2] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMG.TotalNum_2];
                mark1.Text = datasubmit.TotalNum.ToString();
            }
        }

        public void GetMyMS(bool danshuang = false)
        {
            DBManager.MSMonth = MSMonth.Value.Month;
            DBManager.GetDataFromDBMS(danshuang);
            //DBManager.CountDataFromDBMS();

            string str = "";

            string str1 = string.Format("微软公司发布的{0}项安全更新，共修复{1}个漏洞，{2}个安全公告等级为“严重”，其余为“重要”。", DBManager.AdNum, DBManager.CveNum, DBManager.RankNum);
            string str2 = "";
            string temp = "";
            for (int k = 0; k < 50; k++)
            {
                if (DBManager.AdCve[k, 1] != "" && DBManager.AdCve[k, 1] != "0")
                {
                    temp = string.Format("{0}项安全公告针对{1}的漏洞，涉及{2}个CVE编号漏洞，", DBManager.AdCve[k, 1], DBManager.AdCve[k, 0], DBManager.AdCve[k, 2]);
                    str2 = str2 + temp;
                }
            }
            str2 = str2 + "此次微软安全公告包括了缓冲区溢出、任意代码执行等漏洞。";
            str = str1 + str2 + Environment.NewLine + Environment.NewLine + DBManager.MSAtention;
            datasubmit.MSSummary = str1 + str2;
            datasubmit.MSAtention = DBManager.MSAtention;
            MSSummaryText.Text = str;
            MSSummaryText.Refresh();
        }

        public void GetMyTable()
        {
            DBManager.IfUpdate = IfUpdate.Checked;
            int num = DBManager.ds2.Tables[0].Rows.Count;
            datasubmit.NameAtention = "本次值得关注的漏洞有，";
            for (int k = 0; k < num; k++)
            {
                datasubmit.volname[k] = (string)DBManager.ds2.Tables[0].Rows[k]["volname"];
                datasubmit.NameAtention = datasubmit.NameAtention + "[*]" + datasubmit.volname[k];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.cve[k] = (string)DBManager.ds2.Tables[0].Rows[k]["cve"];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.volclass[k] = (string)DBManager.ds2.Tables[0].Rows[k]["volclass"];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.severity_cve[k] = (string)DBManager.ds2.Tables[0].Rows[k]["rank"];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.volcause[k] = (string)DBManager.ds2.Tables[0].Rows[k]["volcause"];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.impact[k] = (string)DBManager.ds2.Tables[0].Rows[k]["Impact"];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.volref[k] = GetRefs(k);
            }

            //for (int k = 0; k < num; k++)
            //{
            //    datasubmit.volname_2[k] = (string)DBManager.ds2.Tables[0].Rows[k][36];
            //}

            for (int k = 0; k < num; k++)
            {
                datasubmit.affact[k] = (string)DBManager.ds2.Tables[0].Rows[k]["affect"];
            }

            datasubmit.Atention = "本次值得关注的漏洞有，";
            for (int k = 0; k < num; k++)
            {
                //datasubmit.translations[k] = (string)DBManager.ds2.Tables[0].Rows[k][27];
                datasubmit.translations[k] = (string)DBManager.ds2.Tables[0].Rows[k]["translations"];
                datasubmit.Atention = datasubmit.Atention + "[*]" + datasubmit.translations[k];
            }

            for (int k = 0; k < num; k++)
            {
                datasubmit.Original_release_date[k] = (string)DBManager.ds2.Tables[0].Rows[k]["Original_release_date"];
            }

            //datasubmit.Atention = atstr1 + "// " + atstr2 + "// " + atstr3 + "// " + atstr4 + "// " + atstr5;
        }

        public string GetRefs(int j)
        {
            string temp = "";
            string str1 = "\n";
            for(int k=17;k<27;k++)
            {
                temp = (string)DBManager.ds2.Tables[0].Rows[j][k];
                if (temp != "")
                {
                    str1 = str1 + temp + "\n";
                }
            }
            return str1;         
        }

        public void SetMyTable()
        {
            int num = DBManager.ds2.Tables[0].Rows.Count;
            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.volname[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.volname[k]];
                    mark1.Text = datasubmit.volname[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.cve[k]];
                    mark1.Text = datasubmit.cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.volclass[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.volclass[k]];
                    mark1.Text = datasubmit.volclass[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.severity_cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.severity_cve[k]];
                    mark1.Text = datasubmit.severity_cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.volcause[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.volcause[k]];
                    mark1.Text = datasubmit.volcause[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.impact[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.impact[k]];
                    mark1.Text = datasubmit.impact[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.volref[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.volref[k]];
                    mark1.Text = "安全公告及厂商补丁：" + datasubmit.volref[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.volname_2[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.volname_2[k]];
                    mark1.Text = datasubmit.volname[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.affact[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.affact[k]];
                    mark1.Text = datasubmit.affact[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarks.translations[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarks.translations[k]];
                    mark1.Text = datasubmit.translations[k].ToString();
                }
            }
        }

        public void SetMyTableMG()
        {
            int num = DBManager.ds2.Tables[0].Rows.Count;
            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.volname[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.volname[k]];
                    mark1.Text = datasubmit.volname[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.cve[k]];
                    mark1.Text = datasubmit.cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.volclass[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.volclass[k]];
                    mark1.Text = datasubmit.volclass[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.severity_cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.severity_cve[k]];
                    mark1.Text = datasubmit.severity_cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.volcause[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.volcause[k]];
                    mark1.Text = datasubmit.volcause[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.impact[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.impact[k]];
                    mark1.Text = datasubmit.impact[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.volref[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.volref[k]];
                    mark1.Text = "安全公告及厂商补丁：" + datasubmit.volref[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.volname_2[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.volname_2[k]];
                    mark1.Text = datasubmit.volname[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMG.affact[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMG.affact[k]];
                    mark1.Text = datasubmit.affact[k].ToString();
                }
            }
        }

        public void SetMyTableMX()
        {
            int num = DBManager.ds2.Tables[0].Rows.Count;
            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMX.volname[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMX.volname[k]];
                    mark1.Text = datasubmit.Original_release_date[k].ToString() + " " + datasubmit.volname[k].ToString();
                }
            }
            
            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMX.cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMX.cve[k]];
                    mark1.Text = datasubmit.cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMX.impact[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMX.impact[k]];
                    mark1.Text = datasubmit.impact[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMX.volref[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMX.volref[k]];
                    mark1.Text = datasubmit.volref[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMX.translations[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMX.translations[k]];
                    mark1.Text = datasubmit.translations[k].ToString();
                }
            }

        }

        public void SetMyTableMXW()
        {
            int num = DBManager.ds2.Tables[0].Rows.Count;
            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMXW.volname[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMXW.volname[k]];
                    mark1.Text = datasubmit.Original_release_date[k].ToString() + " " + datasubmit.volname[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMXW.cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMXW.cve[k]];
                    mark1.Text = datasubmit.cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMXW.impact[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMXW.impact[k]];
                    mark1.Text = datasubmit.impact[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMXW.volref[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMXW.volref[k]];
                    mark1.Text = datasubmit.volref[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMXW.translations[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMXW.translations[k]];
                    mark1.Text = datasubmit.translations[k].ToString();
                }
            }

        }

        public void SetMyTableMK()
        {
            int num = DBManager.ds2.Tables[0].Rows.Count;
            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMK.volname[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMK.volname[k]];
                    mark1.Text = datasubmit.Original_release_date[k].ToString() + " " + datasubmit.volname[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMK.cve[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMK.cve[k]];
                    mark1.Text = datasubmit.cve[k].ToString();
                }
            }

            for (int k = 0; k < num; k++)
            {
                if (doc.Range.Bookmarks[BookMarksMK.translations[k]] != null)
                {
                    mark1 = doc.Range.Bookmarks[BookMarksMK.translations[k]];
                    mark1.Text = datasubmit.translations[k].ToString();
                }
            }

        }

        public void SetMyContentMX()
        {
            GetMyMS(true);
            string[] strs = new string[21];
            strs[0] = datasubmit.StartYear.ToString();
            strs[1] = datasubmit.StartMonth.ToString();
            strs[2] = datasubmit.EndYear.ToString();
            strs[3] = datasubmit.EndMonth.ToString();
            strs[4] = datasubmit.TotalNum.ToString();
            strs[5] = datasubmit.SevereNum.ToString();
            strs[6] = datasubmit.HighNum.ToString();
            strs[7] = datasubmit.MiddleNum.ToString();
            strs[8] = datasubmit.LowNum.ToString();
            strs[9] = datasubmit.HighPercent.ToString();
            strs[10] = datasubmit.NetWorkNum.ToString();
            strs[11] = datasubmit.LocalNum.ToString();
            strs[12] = datasubmit.AdjectionNum.ToString();
            strs[13] = datasubmit.StartYear.ToString();
            strs[14] = datasubmit.StartMonth.ToString();
            strs[15] = datasubmit.EndYear.ToString();
            strs[16] = datasubmit.EndMonth.ToString();
            strs[17] = datasubmit.MSSummary;
            strs[18] = datasubmit.Atention.ToString();
            //string content = string.Format("2013年06月16日至2013年08月15日，国家计算机网络入侵防范中心发布漏洞总条目为883条，其中威胁级别为“紧急”的有212条，“高”的有130条，“中”的有498条，“低”的有109条。威胁级别为紧急和高的漏洞占到总量的38.7%。从漏洞利用方式来看，远程攻击的有768条，本地攻击的有171条，局域网攻击的有10条。可见，能够从远程进行攻击的漏洞占绝大多数，这使得攻击者利用相应漏洞发动攻击更为容易。2013年06月16日至2013年08月15日微软共发布15个安全公告，9个为严重等级，其余为重要等级，共修复Internet Explorer浏览器、Windows系统、Office等产品的37个漏洞。此外，Adobe公司修复了Adobe Reader、Flash Player、Shockwave Player等产品的多个整数溢出漏洞、释放后使用漏洞、缓冲区溢出漏洞、安全绕过漏洞等；Mozilla公司修复了Firefox、Thunderbird等产品的任意代码执行漏洞、缓冲区溢出漏洞、释放后使用漏洞等；Oracle公司也修复了Java的多个任意代码执行漏洞、未指明漏洞等。建议广大用户及时安装补丁，增强系统安全性，做好安全防范工作，保证信息系统安全。");
            string content = string.Format("{0}年{1}月16日至{2}年{3}月15日，国家计算机网络入侵防范中心发布漏洞总条目为{4}条，其中威胁级别为“紧急”的有{5}条，“高”的有{6}条，“中”的有{7}条，“低”的有{8}条。威胁级别为紧急和高的漏洞占到总量的{9}。从漏洞利用方式来看，远程攻击的有{10}条，本地攻击的有{11}条，局域网攻击的有{12}条。可见，能够从远程进行攻击的漏洞占绝大多数，这使得攻击者利用相应漏洞发动攻击更为容易。{13}年{14}月16日至{15}年{16}月15日{17}此外，{18}", strs[0], strs[1], strs[2], strs[3], strs[4], strs[5], strs[6], strs[7], strs[8], strs[9], strs[10], strs[11], strs[12], strs[13], strs[14], strs[15], strs[16], strs[17], strs[18]);
            datasubmit.Content = content;
            
            if (doc.Range.Bookmarks[BookMarksMX.Content] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMX.Content];
                mark1.Text = datasubmit.Content.ToString();
            }
            //return content;
        }

        public void SetMyContentMXW()
        {
            GetMyMS();
            string[] strs = new string[21];
            strs[0] = datasubmit.StartYear.ToString();
            strs[1] = datasubmit.StartMonth.ToString();
            strs[2] = datasubmit.EndYear.ToString();
            strs[3] = datasubmit.EndMonth.ToString();
            strs[4] = datasubmit.TotalNum.ToString();
            strs[5] = datasubmit.TotalNumLast.ToString();
            strs[6] = datasubmit.SevereNum.ToString();
            strs[7] = datasubmit.HighNum.ToString();
            strs[8] = datasubmit.MiddleNum.ToString();
            strs[9] = datasubmit.LowNum.ToString();
            strs[10] = datasubmit.HighPercent.ToString();

            strs[11] = datasubmit.NetWorkNum.ToString();
            strs[12] = datasubmit.LocalNum.ToString();
            strs[13] = datasubmit.AdjectionNum.ToString();
            strs[14] = datasubmit.MSSummary;

            //string content = string.Format("2013年08月21日至2013年09月20日，国家计算机网络入侵防范中心发布漏洞总条目为404条，漏洞总数为上月的1.21倍，有所上升。其中威胁级别为“紧急”的有92条，“高”的有73条，“中”的有198条，“低”的有41条。威胁级别为紧急和高的漏洞占到总量的23%，从漏洞利用方式来看，远程攻击的有338条，局域网攻击的有9条，本地攻击的有57条。可见，能够从远程进行攻击的漏洞占绝大多数，这使得攻击者利用相应漏洞发动攻击更为容易。本月微软发布了13个安全公告，其中4个为“严重”等级，其余为“重要”，共公布了IE浏览器、远程桌面客户端、Windows 内核等产品的49个漏洞，包括释放后使用漏洞、缓冲区溢出漏洞、任意代码执行漏洞等。建议广大用户及时安装补丁，增强系统安全性，做好安全防范工作，保证信息系统安全。");
            string content = string.Format("{0}年{1}月21日至{2}年{3}月20日，国家计算机网络入侵防范中心发布漏洞总条目为{4}条，漏洞总数为上月的{5}，有所上升。其中威胁级别为“紧急”的有{6}条，“高”的有{7}条，“中”的有{8}条，“低”的有{9}条。威胁级别为紧急和高的漏洞占到总量的{10}，从漏洞利用方式来看，远程攻击的有{11}条，局域网攻击的有{12}条，本地攻击的有{13}条。可见，能够从远程进行攻击的漏洞占绝大多数，这使得攻击者利用相应漏洞发动攻击更为容易。{14}建议广大用户及时安装补丁，增强系统安全性，做好安全防范工作，保证信息系统安全。", strs[0], strs[1], strs[2], strs[3], strs[4], strs[5], strs[6], strs[7], strs[8], strs[9], strs[10], strs[11], strs[12], strs[13], strs[14]);
            datasubmit.Content = content;

            if (doc.Range.Bookmarks[BookMarksMX.Content] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMX.Content];
                mark1.Text = datasubmit.Content.ToString();
            }
            //return content;
        }

        public void SetMyContentMK()
        {
            GetMyMS();
            string[] strs = new string[21];
            //strs[0] = datasubmit.StartYear.ToString();
            //strs[1] = datasubmit.StartMonth.ToString();
            //strs[2] = datasubmit.EndYear.ToString();
            //strs[3] = datasubmit.EndMonth.ToString();
            strs[0] = datasubmit.TotalNum.ToString();
            strs[1] = datasubmit.TotalDifferStr;
            strs[2] = datasubmit.SevereNum.ToString();
            strs[3] = datasubmit.SevereLast2;
            strs[4] = datasubmit.HighNum;
            strs[5] = datasubmit.HighLast2;
            strs[6] = datasubmit.MiddleNum;
            strs[7] = datasubmit.MiddleNumLast;
            strs[8] = datasubmit.LowNum;
            strs[9] = datasubmit.LowNumLast;
            strs[10] = datasubmit.HighPercent;
            strs[11] = datasubmit.MSSummary;
            strs[12] = datasubmit.Atention;

            //string content = string.Format("404条，漏洞总数与上月相比减少了47条，其中威胁级别为“紧急”的有107条，与上月相等，“高”的有55条，是上月的83.3%，“中”的有195条，是上月的79.92%，“低”的有47条，是上月的1.38倍。威胁级别为“紧急”和“高”的漏洞占到总量的40.1%，网络安全形势基本平稳。本月微软发布了12个安全公告，其中5个为“严重”等级，其余为“重要”，共公布了Internet Explorer浏览器、Windows系统、.NET Framework等产品的共计58个安全漏洞，包括缓冲区溢出漏洞、释放后使用漏洞、回调提升漏洞等；Adobe公司公布了Adobe Flash Player、Adobe AIR 、Adobe Reader、Shockwave Player等产品的多个整数溢出漏洞、缓冲区溢出漏洞、未指明漏洞等；Oracle公司公布了Java SE的多个任意代码执行漏洞、未指明漏洞等。针对以上漏洞各厂商均以发布更新补丁或解决方案。建议科学院院内广大用户及时下载补丁，增强系统安全性，做好安全防范工作，保证信息系统安全。漏洞详细信息参见 http://www.nipc.org.cn 。");
            string content = string.Format("{0}条，漏洞总数{1}，其中威胁级别为“紧急”的有{2}条，是上月的{3}，“高”的有{4}条，是上月的{5}，“中”的有{6}条，是上月的{7}，“低”的有{8}条，是上月的{9}。威胁级别为“紧急”和“高”的漏洞占到总量的{10}，网络安全形势基本平稳。{11}{12}针对以上漏洞各厂商均以发布更新补丁或解决方案。建议科学院院内广大用户及时下载补丁，增强系统安全性，做好安全防范工作，保证信息系统安全。漏洞详细信息参见 http://www.nipc.org.cn 。", strs[0], strs[1], strs[2], strs[3], strs[4], strs[5], strs[6], strs[7], strs[8], strs[9], strs[10], strs[11], strs[12]);
            datasubmit.Content = content;

            if (doc.Range.Bookmarks[BookMarksMK.Content] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.Content];
                mark1.Text = datasubmit.Content.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMK.MSContent] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMK.MSContent];
                mark1.Text = datasubmit.MSSummary.ToString() + datasubmit.MSAtention.ToString() + "目前，厂商也已发布安全公告修复了以上漏洞。建议用户关注厂商官网，及时下载更新，保证信息安全。";
            }
            //return content;
        }

        public void SetMyContentMYW()
        {
            GetMyMS();
            string[] strs = new string[21];
            //strs[0] = datasubmit.StartYear.ToString();
            //strs[1] = datasubmit.StartMonth.ToString();
            //strs[2] = datasubmit.EndYear.ToString();
            //strs[3] = datasubmit.EndMonth.ToString();
            strs[0] = datasubmit.TotalNum.ToString();
            strs[1] = datasubmit.TotalDifferStr;
            strs[2] = datasubmit.SevereNum.ToString();
            strs[3] = datasubmit.SevereLast2;
            strs[4] = datasubmit.HighNum;
            strs[5] = datasubmit.HighLast2;
            strs[6] = datasubmit.MiddleNum;
            strs[7] = datasubmit.MiddleNumLast;
            strs[8] = datasubmit.LowNum;
            strs[9] = datasubmit.LowNumLast;
            strs[10] = datasubmit.HighPercent;

            strs[11] = datasubmit.MSSummary;
            strs[12] = datasubmit.Atention;

            //string content = string.Format("本月发布漏洞总条目为350条，漏洞总数与上月相比增加了69条，其中威胁级别为“紧急”的有96条，是上月的2.46倍，“高”的有53条，是上月的63%，“中”的有237条，是上月的1.27倍，“低”的有33条，是上月的80%。威胁级别为“紧急”和“高”的漏洞占到总量的35.55%，网络安全形势基本平稳。");
            string content = string.Format("本月发布漏洞总条目为{0}条，漏洞总数与上月相比增加了{1}条，其中威胁级别为“紧急”的有{2}条，是上月的{3}，“高”的有{4}条，是上月的{5}，“中”的有{6}条，是上月的{7}，“低”的有{8}条，是上月的{9}。威胁级别为“紧急”和“高”的漏洞占到总量的{10}，网络安全形势基本平稳。针对以上漏洞各厂商均以发布更新补丁或解决方案。建议我院广大用户及时下载并安装补丁，增强系统安全性，做好安全防范工作，保证信息系统安全。", strs[0], strs[1], strs[2], strs[3], strs[4], strs[5], strs[6], strs[7], strs[8], strs[9], strs[10]);
            datasubmit.Summary = content;

            content = string.Format("据院研究生院国家计算机网络入侵防范中心研判，" + datasubmit.StartYear + "年" + datasubmit.StartMonth + "月的安全漏洞总体态势评定为良。");
            datasubmit.Content = content;

            if (doc.Range.Bookmarks[BookMarksMYW.Content1] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.Content1];
                mark1.Text = datasubmit.Content.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMYW.Summary] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.Summary];
                mark1.Text = datasubmit.Summary.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMYW.MSSummary] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.MSSummary];
                mark1.Text = datasubmit.MSSummary.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMYW.Atention] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.Atention];
                mark1.Text = datasubmit.Atention.ToString();
            }
            if (doc.Range.Bookmarks[BookMarksMYW.Period] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksMYW.Period];
                mark1.Text = datasubmit.period.ToString();
            }
            //return content;
        }

        public void SetMyContentWXHW(bool MS)
        {
            GetMyMS();
            string[] strs = new string[21];
            strs[0] = datasubmit.StartYear.ToString();
            strs[1] = datasubmit.StartMonth.ToString();
            strs[2] = datasubmit.StartDay.ToString();
            strs[3] = datasubmit.EndYear.ToString();
            strs[4] = datasubmit.EndMonth.ToString();
            strs[5] = datasubmit.EndDay.ToString();

            strs[6] = datasubmit.TotalNum.ToString();
            strs[7] = datasubmit.SevereHighNum.ToString();
            strs[8] = datasubmit.MiddleNum;
            strs[9] = datasubmit.LowNum;
            strs[10] = datasubmit.TotalNumLast;

            strs[11] = datasubmit.MSSummary;
            strs[12] = datasubmit.Atention;

            //string content = string.Format("2013年10月01日至2013年10月14日，安全漏洞264个，其中高危漏洞77个，中等威胁漏168个，低威胁漏洞19个，安全漏洞总量与上周相比有所上升。");
            string content = string.Format("{0}年{1}月{2}日至{3}年{4}月{5}日，安全漏洞{6}个，其中高危漏洞{7}个，中等威胁漏{8}个，低威胁漏洞{9}个，安全漏洞总量是上周的{10}。", strs[0], strs[1], strs[2], strs[3], strs[4], strs[5], strs[6], strs[7], strs[8], strs[9], strs[10]);
            datasubmit.Summary = content;

            if (doc.Range.Bookmarks[BookMarksWXHW.Summary] != null)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.Summary];
                mark1.Text = datasubmit.Summary.ToString();
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.Atention] != null && MS == false)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.Atention];
                mark1.Text = datasubmit.Atention.ToString();
            }
            else if (doc.Range.Bookmarks[BookMarksWXHW.Atention] != null && MS == true)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.Atention];
                mark1.Text = datasubmit.MSSummary + datasubmit.MSAtention;
            }

            if (doc.Range.Bookmarks[BookMarksWXHW.NameAtention] != null && MS == false)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.NameAtention];
                mark1.Text = datasubmit.NameAtention;
            }
            else if (doc.Range.Bookmarks[BookMarksWXHW.NameAtention] != null && MS == true)
            {
                mark1 = doc.Range.Bookmarks[BookMarksWXHW.NameAtention];
                mark1.Text = datasubmit.MSSummary;
            }
        }

        public bool MyCopyDoc(string pathS, string pathD)
        {
            if (!System.IO.File.Exists(pathS))
            {
                MessageBox.Show("模板不存在");
                return false;
            }

            bool isrewrite = true; // true=覆盖已存在的同名文件,false则反之
            System.IO.File.Copy(pathS, pathD, isrewrite);

            return true;
        }

        public string GetYear(string sTime)
        {
            return sTime.Substring(0, sTime.IndexOf("-"));
        }

        public string GetMonth(string sTime)
        {
            return sTime.Substring(sTime.IndexOf("-") + 1, 2);
        }
        
        public string GetDay(string sTime)
        {
            return sTime.Substring(sTime.LastIndexOf("-") + 1, 2);
        }

        private void XinXiHua_Click(object sender, EventArgs e)
        {

            GetMyDate();
            GetMySummary("NVD_LogMonth15");
            GetMyTable();
            string NameDate = datasubmit.StartYear + "." + datasubmit.StartMonth + "." + datasubmit.StartDay + "-" +
                              datasubmit.EndYear + "." + datasubmit.EndMonth + "." + datasubmit.EndDay + ".doc";
            string temp = XinXiHuaChuMonthDdan;
            //XinXiHuaChuMonthDdan = XinXiHuaChuMonthDdan + NameDate;
            //XinXiHuaChuMonthDshuang = XinXiHuaChuMonthDshuang + NameDate;
            XinXiHuaChuMonthDdan = "D:\\国家计算机网络入侵防范中心" + datasubmit.StartMonth + "月至" + datasubmit.EndMonth + "月十大安全漏洞通报 _单栏_双月版- " + NameDate;
            XinXiHuaChuMonthDshuang = "D:\\国家计算机网络入侵防范中心" + datasubmit.StartMonth + "月至" + datasubmit.EndMonth + "月十大安全漏洞通报 _双栏_双月版- " + NameDate;


            MyCopyDoc(XinXiHuaChuMonthSdan,XinXiHuaChuMonthDdan);
            if (!File.Exists(XinXiHuaChuMonthDdan))
            {
                MessageBox.Show("文件不存在");
                return;
            }

            doc = new Document(XinXiHuaChuMonthDdan);
            SetMyDateMX();
            SetMyContentMX();
            SetMyTableMX();
            doc.Save(XinXiHuaChuMonthDdan);

            MyCopyDoc(XinXiHuaChuMonthSshuang, XinXiHuaChuMonthDshuang);
            if (!File.Exists(XinXiHuaChuMonthDshuang))
            {
                MessageBox.Show("文件不存在");
                return;
            }
            doc = new Document(XinXiHuaChuMonthDshuang);
            SetMyDateMX();
            SetMyContentMX();
            SetMyTableMX();
            doc.Save(XinXiHuaChuMonthDshuang);

            XinXiHuaChuMonthDdan = temp;
            XinXiHuaChuMonthDshuang = temp;
        }

        private void statDate_CheckedChanged(object sender, EventArgs e)
        {
            DBManager.statDate = statDate.Checked;
        }

        private void statDateTime_CheckedChanged(object sender, EventArgs e)
        {
            DBManager.statDateTime = statDateTime.Checked;
        }

        private void GongW_Click(object sender, EventArgs e)
        {
            GetMyDate();
            GetMySummary("NVD_LogWeek");
            GetMyTable();

            GongAnBuWD = "d:\\国家计算机网络入侵防范中心（" + datasubmit.StartYear.ToString() + "年" + datasubmit.StartMonth.ToString() + "月" + datasubmit.StartDay.ToString() + "日至" + datasubmit.EndYear.ToString() + "年" + datasubmit.EndMonth.ToString() + "月" + datasubmit.EndDay.ToString() + "日).doc";
            MyCopyDoc(GongAnBuWS, GongAnBuWD);

            if (!File.Exists(GongAnBuWD))
            {
                MessageBox.Show("文件不存在");
            }

            doc = new Document(GongAnBuWD);

            SetMyDate();
            SetMySummary(true);
            SetMyTable();

            doc.Save(GongAnBuWD);
        }

        private void XinWangAnZaZhi_Click(object sender, EventArgs e)
        {
            GetMyDate();
            GetMySummary("NVD_LogMonth21");
            GetMyTable();

            XinWangAnZhaZhiD = "D:\\国家计算机网络入侵防范中心" + datasubmit.EndMonth + "月份十大安全漏洞通报（" + datasubmit.EndYear + "年）.doc";

            MyCopyDoc(XinWangAnZhaZhiS, XinWangAnZhaZhiD);
            if (!File.Exists(XinWangAnZhaZhiD))
            {
                MessageBox.Show("文件不存在");
                return;
            }

            doc = new Document(XinWangAnZhaZhiD);
            SetMyDateMXW();
            SetMyContentMXW();
            SetMyTableMXW();
            doc.Save(XinWangAnZhaZhiD);

            XinWangAnZhaZhiD = "";
        }

        private void GongAnBuM_Click(object sender, EventArgs e)
        {
            GetMyDate();
            GetMySummary("NVD_LogMonth01");
            GetMyTable();

            GongAnBuMonthD = "D:\\" + datasubmit.StartYear + "年" + datasubmit.StartMonth + "月份十大重要漏洞.doc";

            MyCopyDoc(GongAnBuMonthS, GongAnBuMonthD);
            if (!File.Exists(GongAnBuMonthD))
            {
                MessageBox.Show("文件不存在");
                return;
            }

            doc = new Document(GongAnBuMonthD);
            SetMyDateMG();
            SetMySummaryMG();
            SetMyTableMG();
            doc.Save(GongAnBuMonthD);
        }

        private void KeYuanM_Click(object sender, EventArgs e)
        {
            GetMyDate();
            GetMySummary("NVD_LogMonth01");
            GetMyTable();

            KeYuanMonthD = "D:\\国家计算机网络入侵防范中心_" + datasubmit.StartYear + "年" + datasubmit.StartMonth + "月安全漏洞信息月报.doc";
            //KeYuanMonthD = "D:\\bbb.doc";

            MyCopyDoc(KeYuanMonthS, KeYuanMonthD);
            if (!File.Exists(KeYuanMonthD))
            {
                MessageBox.Show("文件不存在");
                return;
            }

            doc = new Document(KeYuanMonthD);
            SetMyDateMK();
            SetMyContentMK();
            SetMyTableMK();
            doc.Save(KeYuanMonthD);
        }

        private void YuanWangXinM_Click(object sender, EventArgs e)
        {
            GetMyDate();
            GetMySummary("NVD_LogMonth01");
            GetMyTable();
            //int period = 30;
            datasubmit.period = (datasubmit.StartYear - 2013)*12 + datasubmit.StartMonth + 29;
            int a = datasubmit.StartMonth + 1;
            YuanWangXinD = "d:\\院网络与信息情况通报（" + datasubmit.StartYear.ToString() + "年第" + a.ToString() + "期-总第" + datasubmit.period.ToString() + "期)" + datasubmit.StartYear.ToString() + datasubmit.StartMonth.ToString() + datasubmit.StartDay.ToString() + ".doc";
            //YuanWangXinD = "D:\\bbb.doc";

            MyCopyDoc(YuanWangXinS, YuanWangXinD);
            if (!File.Exists(YuanWangXinD))
            {
                MessageBox.Show("文件不存在");
                return;
            }

            doc = new Document(YuanWangXinD);
            SetMyDateMYW();
            SetMyContentMYW();
            //SetMyTableMYW();
            doc.Save(YuanWangXinD);
        }

        public void XinHuaWang(bool MS)
        {
            GetMyDate();
            GetMySummary("NVD_LogWeek");
            GetMyTable();

            XinHuaWangDwan = "d:\\" + datasubmit.StartYear + "年" + datasubmit.StartMonth + "月" + datasubmit.StartDay + "日至" + datasubmit.EndYear + "年" + datasubmit.EndMonth + "月" + datasubmit.EndDay + "日漏洞报告_完整版" + ".doc";
            MyCopyDoc(XinHuaWangSwan, XinHuaWangDwan);
            if (!File.Exists(XinHuaWangDwan))
            {
                MessageBox.Show("文件不存在");
                return;
            }
            doc = new Document(XinHuaWangDwan);
            SetMyDateWXHW();
            SetMyContentWXHW(MS);
            doc.Save(XinHuaWangDwan);

            XinHuaWangDzi = "d:\\" + datasubmit.StartYear + "年" + datasubmit.StartMonth + "月" + datasubmit.StartDay + "日至" + datasubmit.EndYear + "年" + datasubmit.EndMonth + "月" + datasubmit.EndDay + "日漏洞报告_字幕版" + ".doc";
            MyCopyDoc(XinHuaWangSzi, XinHuaWangDzi);
            if (!File.Exists(XinHuaWangDzi))
            {
                MessageBox.Show("文件不存在");
                return;
            }
            doc = new Document(XinHuaWangDzi);
            SetMyDateWXHW();
            SetMyContentWXHW(MS);
            doc.Save(XinHuaWangDzi);
        }

        private void XinHua_Click(object sender, EventArgs e)
        {
            XinHuaWang(false);
        }

        private void XinHuaW_Click(object sender, EventArgs e)
        {
            XinHuaWang(true);
        }

        private void IfUpdate_CheckedChanged(object sender, EventArgs e)
        {
            DBManager.IfUpdate = IfUpdate.Checked;
        }

    }
}
