﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyDoc
{
    partial class CAddVolcChineseDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtVolc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtChinese = new System.Windows.Forms.TextBox();
            this.AddBtn = new System.Windows.Forms.Button();
            this.UpdateBtn = new System.Windows.Forms.Button();
            this.FindBtn = new System.Windows.Forms.Button();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtOrderID = new System.Windows.Forms.TextBox();
            this.txtCVE = new System.Windows.Forms.TextBox();
            this.txtOverview = new System.Windows.Forms.TextBox();
            this.txtTrans = new System.Windows.Forms.TextBox();
            this.AddOrderBtn = new System.Windows.Forms.Button();
            this.FindIDBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtIDvolc = new System.Windows.Forms.TextBox();
            this.UpBtn = new System.Windows.Forms.Button();
            this.DownBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAlready = new System.Windows.Forms.TextBox();
            this.volcInOverviewBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtVolc
            // 
            this.txtVolc.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtVolc.Location = new System.Drawing.Point(83, 18);
            this.txtVolc.Name = "txtVolc";
            this.txtVolc.Size = new System.Drawing.Size(448, 29);
            this.txtVolc.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 20;
            this.label1.Text = "volc:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 21;
            this.label2.Text = "Chinese:";
            // 
            // txtChinese
            // 
            this.txtChinese.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtChinese.Location = new System.Drawing.Point(83, 54);
            this.txtChinese.Name = "txtChinese";
            this.txtChinese.Size = new System.Drawing.Size(448, 29);
            this.txtChinese.TabIndex = 1;
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(452, 163);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(40, 23);
            this.AddBtn.TabIndex = 11;
            this.AddBtn.Text = "添加";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.Location = new System.Drawing.Point(452, 192);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(40, 23);
            this.UpdateBtn.TabIndex = 13;
            this.UpdateBtn.Text = "更新";
            this.UpdateBtn.UseVisualStyleBackColor = true;
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // FindBtn
            // 
            this.FindBtn.Location = new System.Drawing.Point(494, 163);
            this.FindBtn.Name = "FindBtn";
            this.FindBtn.Size = new System.Drawing.Size(37, 23);
            this.FindBtn.TabIndex = 12;
            this.FindBtn.Text = "查找";
            this.FindBtn.UseVisualStyleBackColor = true;
            this.FindBtn.Click += new System.EventHandler(this.FindBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(494, 192);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(37, 23);
            this.DeleteBtn.TabIndex = 14;
            this.DeleteBtn.Text = "删除";
            this.DeleteBtn.UseVisualStyleBackColor = true;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 22;
            this.label3.Text = "id:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(554, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 28;
            this.label4.Text = "trans:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 23;
            this.label5.Text = "OrderID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 24;
            this.label6.Text = "cve:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 26;
            this.label7.Text = "Overview:";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(83, 91);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(174, 21);
            this.txtID.TabIndex = 3;
            // 
            // txtOrderID
            // 
            this.txtOrderID.Location = new System.Drawing.Point(83, 116);
            this.txtOrderID.Name = "txtOrderID";
            this.txtOrderID.Size = new System.Drawing.Size(363, 21);
            this.txtOrderID.TabIndex = 5;
            // 
            // txtCVE
            // 
            this.txtCVE.Location = new System.Drawing.Point(83, 142);
            this.txtCVE.Name = "txtCVE";
            this.txtCVE.Size = new System.Drawing.Size(363, 21);
            this.txtCVE.TabIndex = 6;
            // 
            // txtOverview
            // 
            this.txtOverview.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtOverview.Location = new System.Drawing.Point(83, 192);
            this.txtOverview.Multiline = true;
            this.txtOverview.Name = "txtOverview";
            this.txtOverview.Size = new System.Drawing.Size(363, 304);
            this.txtOverview.TabIndex = 0;
            // 
            // txtTrans
            // 
            this.txtTrans.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtTrans.Location = new System.Drawing.Point(612, 98);
            this.txtTrans.Multiline = true;
            this.txtTrans.Name = "txtTrans";
            this.txtTrans.Size = new System.Drawing.Size(363, 398);
            this.txtTrans.TabIndex = 19;
            // 
            // AddOrderBtn
            // 
            this.AddOrderBtn.Location = new System.Drawing.Point(452, 248);
            this.AddOrderBtn.Name = "AddOrderBtn";
            this.AddOrderBtn.Size = new System.Drawing.Size(79, 23);
            this.AddOrderBtn.TabIndex = 16;
            this.AddOrderBtn.Text = "添加序号";
            this.AddOrderBtn.UseVisualStyleBackColor = true;
            this.AddOrderBtn.Click += new System.EventHandler(this.AddOrderBtn_Click);
            // 
            // FindIDBtn
            // 
            this.FindIDBtn.Location = new System.Drawing.Point(452, 221);
            this.FindIDBtn.Name = "FindIDBtn";
            this.FindIDBtn.Size = new System.Drawing.Size(79, 23);
            this.FindIDBtn.TabIndex = 15;
            this.FindIDBtn.Text = "查找id_v";
            this.FindIDBtn.UseVisualStyleBackColor = true;
            this.FindIDBtn.Click += new System.EventHandler(this.FindIDBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 25;
            this.label8.Text = "id_volc:";
            // 
            // txtIDvolc
            // 
            this.txtIDvolc.Location = new System.Drawing.Point(83, 167);
            this.txtIDvolc.Name = "txtIDvolc";
            this.txtIDvolc.Size = new System.Drawing.Size(363, 21);
            this.txtIDvolc.TabIndex = 7;
            // 
            // UpBtn
            // 
            this.UpBtn.Location = new System.Drawing.Point(452, 274);
            this.UpBtn.Name = "UpBtn";
            this.UpBtn.Size = new System.Drawing.Size(79, 23);
            this.UpBtn.TabIndex = 17;
            this.UpBtn.Text = "上一条id_v";
            this.UpBtn.UseVisualStyleBackColor = true;
            this.UpBtn.Click += new System.EventHandler(this.UpBtn_Click);
            // 
            // DownBtn
            // 
            this.DownBtn.Location = new System.Drawing.Point(452, 300);
            this.DownBtn.Name = "DownBtn";
            this.DownBtn.Size = new System.Drawing.Size(79, 23);
            this.DownBtn.TabIndex = 18;
            this.DownBtn.Text = "下一条id_v";
            this.DownBtn.UseVisualStyleBackColor = true;
            this.DownBtn.Click += new System.EventHandler(this.DownBtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(543, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(216, 78);
            this.button1.TabIndex = 2;
            this.button1.Text = "下一条id";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(452, 126);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "上一条id";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(452, 98);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(79, 23);
            this.button3.TabIndex = 9;
            this.button3.Text = "查找id";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(264, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 27;
            this.label9.Text = "已完成：";
            // 
            // txtAlready
            // 
            this.txtAlready.Location = new System.Drawing.Point(312, 92);
            this.txtAlready.Name = "txtAlready";
            this.txtAlready.Size = new System.Drawing.Size(134, 21);
            this.txtAlready.TabIndex = 4;
            // 
            // volcInOverviewBtn
            // 
            this.volcInOverviewBtn.Location = new System.Drawing.Point(769, 5);
            this.volcInOverviewBtn.Name = "volcInOverviewBtn";
            this.volcInOverviewBtn.Size = new System.Drawing.Size(206, 78);
            this.volcInOverviewBtn.TabIndex = 29;
            this.volcInOverviewBtn.Text = "Overview查找volc";
            this.volcInOverviewBtn.UseVisualStyleBackColor = true;
            this.volcInOverviewBtn.Click += new System.EventHandler(this.volcInOverviewBtn_Click);
            // 
            // CAddVolcChineseDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 508);
            this.Controls.Add(this.volcInOverviewBtn);
            this.Controls.Add(this.txtAlready);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.DownBtn);
            this.Controls.Add(this.UpBtn);
            this.Controls.Add(this.txtIDvolc);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.FindIDBtn);
            this.Controls.Add(this.AddOrderBtn);
            this.Controls.Add(this.txtTrans);
            this.Controls.Add(this.txtOverview);
            this.Controls.Add(this.txtCVE);
            this.Controls.Add(this.txtOrderID);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.FindBtn);
            this.Controls.Add(this.UpdateBtn);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.txtChinese);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtVolc);
            this.Name = "CAddVolcChineseDlg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CAddVolcChineseDlg";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVolc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtChinese;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.Button UpdateBtn;
        private Button FindBtn;
        private Button DeleteBtn;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtID;
        private TextBox txtOrderID;
        private TextBox txtCVE;
        private TextBox txtOverview;
        private TextBox txtTrans;
        private Button AddOrderBtn;
        private Button FindIDBtn;
        private Label label8;
        private TextBox txtIDvolc;
        private Button UpBtn;
        private Button DownBtn;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label9;
        private TextBox txtAlready;
        private Button volcInOverviewBtn;
    }
}