﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace MyDoc
{
    //用于处理字符串
    public class Pro_String
    {
        public static string[] pro_str(string str)
        {
            str = str.Replace("@", "~!#$^&~!#$^&~!#$^&");

            str = str.Replace(" ", "@");
            str = str.Replace("\n", "@");

            //str = str.Replace("(", "@(@");
            //str = str.Replace(")", "@)@");
            str = str.Replace("[", "@[@");
            str = str.Replace("]", "@]@");
            str = str.Replace("{", "@{@");
            str = str.Replace("}", "@}@");

            str = str.Replace("'s", "@的@");
            str = str.Replace("'", "''");
            str = str.Replace(",", "@,@");
            //str = str.Replace("\"", "@\"@");
            str = str.Replace(";", "@;@");
            //str = str.Replace("!", "@!@");            
            str = str.Replace("`", "@`@");
            //str = str.Replace("?", "@?@");
            str = str.Replace(" '", "@''@");
            str = str.Replace("' ", "@''@");

            string[] strs = str.Split('@');

            //处理strs单个的单词
            for (int k = 0; k < strs.Count(); k++)
            {
                //去掉单词后面的‘.’
                strs[k] = strs[k].Replace("~!#$^&~!#$^&~!#$^&", "@");
                string strPoint = strs[k];
                if (strPoint != "")
                {
                    char start = strPoint[0];
                    if (strPoint.Length > 2)
                    {
                        char end = strPoint[strPoint.Length - 1];
                        char end2 = strPoint[strPoint.Length - 2];
                        if (end == '.' && end2 != '.')
                            strs[k] = strPoint.Substring(0, strPoint.Length - 1);
                    }
                    else if (strPoint.Length > 1)
                    {
                        char end = strPoint[strPoint.Length - 1];
                        if (end == '.')
                            strs[k] = strPoint.Substring(0, strPoint.Length - 1);
                    }

                    //else if (end == ')' && start != '(')
                    //    strs[k] = strPoint.Substring(0, strPoint.Length - 1);
                    //else if (end != ')' && start == '(')
                    //    strs[k] = strPoint.Substring(1);
                }
            }

            return strs;
        }

        //public static string SQLSentence = "";
        //public static int num2 = 0;
        public static void WhileGetNvdOverview()
        {
            string Overview = "";
            string SQLSentence = "";
            string trans = "";
            string cve = "";
            int num = 1;
            Double num2 = 0;

            //SQLSentence = string.Format("select count(distinct orderID) from _nvd_dictionary");
            SQLSentence = string.Format("select max(orderID) from _nvd_dictionary");
            Double h = DBManager2.OpSQLGetInt64(SQLSentence);            
            Double h2 = h + 50000;
            SQLSentence = string.Format("select max(id) from _nvd_dictionary");
            num2 = DBManager2.OpSQLGetInt64(SQLSentence);

            for (; h < h2; h++)
            {
                SQLSentence = string.Format("select UniOverview from nvd where orderID = {0}",h);
                Overview = DBManager2.OpSQLGetString(SQLSentence);
                SQLSentence = string.Format("select cve from nvd where orderID = {0}", h);
                cve = DBManager2.OpSQLGetString(SQLSentence);
                SQLSentence = string.Format("select trans from nvd where orderID = {0}", h);
                trans = DBManager2.OpSQLGetString(SQLSentence);
                string[] strs = pro_str(Overview);

                for (int k = 0; k < strs.Count(); k++)
                {
                    SQLSentence = string.Format("select count(*) from _nvd_dictionary where volc = '{0}'",strs[k]);
                    num = DBManager2.OpSQLGetInt(SQLSentence);
                    if (num <= 0)
                    {
                        //SQLSentence = string.Format("select max(id) from _nvd_dictionary");
                        ////string strint = DBManager2.OpSQLGetString(SQLSentence);
                        ////num2 = System.Int32.Parse(strint);
                        //num2 = DBManager2.OpSQLGetInt64(SQLSentence);
                        num2 = num2 + 1;
                        //num2 = num2 + 1;
                        SQLSentence = string.Format("insert into _nvd_dictionary (id,volc,orderID,cve,OverView,trans) values ({0},'{1}',{2},'{3}','{4}','{5}')", num2, strs[k],h,cve,Overview,trans);
                        //SQLSentence = string.Format("insert into _nvd_dictionary (id,volc,orderID,cve) values ({0},'{1}',{2},'{3}')", num2, strs[k], h, cve);
                        DBManager2.OpSQLWrite(SQLSentence);
                    }
                }
            }

        }


    }
}
