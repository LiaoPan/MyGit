﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyDoc
{
    public partial class CAddPhraseDlg : Form
    {
        public CAddPhraseDlg()
        {
            InitializeComponent();
        }
        
        public void myRefrash()
        {
            txt_phrase_id.Refresh();
            txt_phrase_phrase.Refresh();
            txt_phrase_trans.Refresh();
            txt_pre_end.Refresh();
            txt_pre_id.Refresh();
            txt_pre_phrase.Refresh();
            txt_pre_start.Refresh();
            txt_pre_teshu.Refresh();
            txt_pre_teshuyizuo.Refresh();
            txt_pre_volc.Refresh();
        }

        string SQLSentence = "";
        private void AddBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_phrase_phrase.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_phrase where phrase = '{0}'", txt_phrase_phrase.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    string str = string.Format("{0}已经存在", txt_phrase_trans.Text);
                    MessageBox.Show(str);
                }
                else
                {
                    SQLSentence = string.Format("insert into _nvd_dic_phrase (id,phrase,trans) values({0},'{1}','{2}')", txt_phrase_id.Text, txt_phrase_phrase.Text, txt_phrase_trans.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("添加成功");
                }
            }
        }

        private void FillBtn_Click(object sender, EventArgs e)
        {
            if (txt_phrase_phrase.Text != "")
            {
                SQLSentence = string.Format("select MAX(id) from _nvd_dic_phrase");
                double id = DBManager2.OpSQLGetInt64(SQLSentence) + 1;
                txt_phrase_id.Text = id.ToString();
                txt_phrase_trans.Text = "@" + txt_phrase_phrase.Text.Replace(" ", "^");

                SQLSentence = string.Format("select MAX(id) from _nvd_dic_preposition");
                id = DBManager2.OpSQLGetInt64(SQLSentence) + 1;
                txt_pre_id.Text = id.ToString();
                txt_pre_phrase.Text = txt_phrase_phrase.Text;
                txt_pre_volc.Text = txt_phrase_trans.Text;

            }
        }

        private void pre_AddBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_pre_volc.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_preposition where volc = '{0}'", txt_pre_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    string str = string.Format("{0}已经存在", txt_pre_volc.Text);
                    MessageBox.Show(str);
                }
                else
                {
                    SQLSentence = string.Format("insert into _nvd_dic_preposition (id,phrase,volc,senStart,senEnd,特殊,特殊译作,location) values({0},'{1}','{2}','{3}','{4}','{5}','{6}','{7}')", txt_pre_id.Text, txt_pre_phrase.Text, txt_pre_volc.Text,txt_pre_start.Text,txt_pre_end.Text,txt_pre_teshu.Text,txt_pre_teshuyizuo.Text,txtLocation.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("添加成功");
                }
            }
        }

        private void ModifyBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_phrase_phrase.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_phrase where phrase = '{0}'", txt_phrase_phrase.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("update _nvd_dic_phrase set trans = '{0}' where phrase = '{1}'", txt_phrase_trans.Text, txt_phrase_phrase.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("更新成功");
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_phrase_trans.Text);
                    MessageBox.Show(str);
                }
            }
        }

        private void pre_ModifyBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_pre_volc.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_preposition where volc = '{0}'", txt_pre_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("update _nvd_dic_preposition set phrase = '{0}', senStart = '{1}', senEnd = '{2}', 特殊 = '{3}', 特殊译作 = '{4}', location = '{5}' where volc = '{6}'", txt_pre_phrase.Text, txt_pre_start.Text, txt_pre_end.Text, txt_pre_teshu.Text, txt_pre_teshuyizuo.Text,txtLocation.Text, txt_pre_volc.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("更新成功");
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_pre_volc.Text);
                    MessageBox.Show(str);
                }
            }
        }

        private void FindBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_phrase_phrase.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_phrase where phrase = '{0}'", txt_phrase_phrase.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("select * from _nvd_dic_phrase where phrase = '{0}'", txt_phrase_phrase.Text);
                    DataSet ds = new DataSet();
                    ds = DBManager2.OpSQLGetTable(SQLSentence);
                    txt_phrase_id.Text = ds.Tables[0].Rows[0]["id"].ToString();
                    //txt_phrase_phrase.Text = ds.Tables[0].Rows[0]["phrase"].ToString();
                    txt_phrase_trans.Text = ds.Tables[0].Rows[0]["trans"].ToString();
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_phrase_trans.Text);
                    MessageBox.Show(str);
                }
            }
        }

        private void pre_FindBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_pre_volc.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_preposition where volc = '{0}'", txt_pre_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("select * from _nvd_dic_preposition where volc = '{0}'", txt_pre_volc.Text);
                    DataSet ds = new DataSet();
                    ds = DBManager2.OpSQLGetTable(SQLSentence);
                    txt_pre_id.Text = ds.Tables[0].Rows[0]["id"].ToString();
                    txt_pre_phrase.Text = ds.Tables[0].Rows[0]["phrase"].ToString();
                    txt_pre_start.Text = ds.Tables[0].Rows[0]["senStart"].ToString();
                    txt_pre_end.Text = ds.Tables[0].Rows[0]["senEnd"].ToString();
                    txt_pre_teshu.Text = ds.Tables[0].Rows[0]["特殊"].ToString();
                    txt_pre_teshuyizuo.Text = ds.Tables[0].Rows[0]["特殊译作"].ToString();
                    txtLocation.Text = ds.Tables[0].Rows[0]["location"].ToString();
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_phrase_trans.Text);
                    MessageBox.Show(str);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_phrase_phrase.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_phrase where phrase = '{0}'", txt_phrase_phrase.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("delete from _nvd_dic_phrase where phrase = '{0}'", txt_phrase_phrase.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("删除成功");
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_phrase_trans.Text);
                    MessageBox.Show(str);
                }
            }
        }

        private void pre_DeleteBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_phrase_phrase.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dic_preposition where volc = '{0}'", txt_pre_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("delete from _nvd_dic_preposition where volc = '{0}'", txt_pre_volc.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("删除成功");
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_phrase_trans.Text);
                    MessageBox.Show(str);
                }
            }
        }
    }
}
