﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyDoc
{
    public partial class CAddVolDlg : Form
    {
        public CAddVolDlg()
        {
            InitializeComponent();
        }

        string SQLSentence = "";
        private void AddBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_volc.Text != "")
            {
                if (txt_phrase_id.Text == "")
                {
                    SQLSentence = string.Format("select MAX(id) from _nvd_dictionary");
                    double id = DBManager2.OpSQLGetInt64(SQLSentence) + 1;
                    txt_phrase_id.Text = id.ToString();
                }

                SQLSentence = string.Format("select count(*) from _nvd_dictionary where volc = '{0}'", txt_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    string str = string.Format("{0}已经存在", txt_volc.Text);
                    MessageBox.Show(str);
                }
                else
                {
                    SQLSentence = string.Format("insert into _nvd_dictionary (id,volc,chinese,cve) values({0},'{1}','{2}','{3}')", txt_phrase_id.Text, txt_volc.Text, txt_chinese.Text, txt_cve.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("添加成功");
                }
            }
        }

        public void myRefrash()
        {
            txt_phrase_id.Refresh();
            txt_chinese.Refresh();
            txt_cve.Refresh();
            txt_volc.Refresh();
        }

        private void ModifyBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_volc.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dictionary where volc = '{0}'", txt_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("update _nvd_dictionary set chinese = '{0}' where volc = '{1}'", txt_chinese.Text, txt_volc.Text);
                    DBManager2.OpSQLWrite(SQLSentence);
                    MessageBox.Show("更新成功");
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_volc.Text);
                    MessageBox.Show(str);
                }
            }
        }

        private void FindBtn_Click(object sender, EventArgs e)
        {
            myRefrash();

            if (txt_volc.Text != "")
            {
                SQLSentence = string.Format("select count(*) from _nvd_dictionary where volc = '{0}'", txt_volc.Text);
                int num = DBManager2.OpSQLGetInt(SQLSentence);
                if (num > 0)
                {
                    SQLSentence = string.Format("select * from _nvd_dictionary where volc = '{0}'", txt_volc.Text);
                    DataSet ds = new DataSet();
                    ds = DBManager2.OpSQLGetTable(SQLSentence);
                    txt_phrase_id.Text = ds.Tables[0].Rows[0]["id"].ToString();
                    //txt_phrase_phrase.Text = ds.Tables[0].Rows[0]["phrase"].ToString();
                    txt_chinese.Text = ds.Tables[0].Rows[0]["chinese"].ToString();
                }
                else
                {
                    string str = string.Format("{0}不存在", txt_volc.Text);
                    MessageBox.Show(str);
                }
            }
        }
    }
}
