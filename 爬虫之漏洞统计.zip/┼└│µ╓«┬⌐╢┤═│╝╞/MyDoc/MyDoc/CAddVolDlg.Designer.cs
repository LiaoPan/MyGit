﻿

namespace MyDoc
{
    partial class CAddVolDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.FindBtn = new System.Windows.Forms.Button();
            this.ModifyBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.txt_chinese = new System.Windows.Forms.TextBox();
            this.txt_volc = new System.Windows.Forms.TextBox();
            this.txt_phrase_id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_cve = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(219, 155);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(41, 25);
            this.DeleteBtn.TabIndex = 39;
            this.DeleteBtn.Text = "删除";
            this.DeleteBtn.UseVisualStyleBackColor = true;
            // 
            // FindBtn
            // 
            this.FindBtn.Location = new System.Drawing.Point(174, 155);
            this.FindBtn.Name = "FindBtn";
            this.FindBtn.Size = new System.Drawing.Size(39, 25);
            this.FindBtn.TabIndex = 38;
            this.FindBtn.Text = "查询";
            this.FindBtn.UseVisualStyleBackColor = true;
            this.FindBtn.Click += new System.EventHandler(this.FindBtn_Click);
            // 
            // ModifyBtn
            // 
            this.ModifyBtn.Location = new System.Drawing.Point(131, 155);
            this.ModifyBtn.Name = "ModifyBtn";
            this.ModifyBtn.Size = new System.Drawing.Size(37, 25);
            this.ModifyBtn.TabIndex = 37;
            this.ModifyBtn.Text = "修改";
            this.ModifyBtn.UseVisualStyleBackColor = true;
            this.ModifyBtn.Click += new System.EventHandler(this.ModifyBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(87, 155);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(38, 25);
            this.AddBtn.TabIndex = 36;
            this.AddBtn.Text = "添加";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // txt_chinese
            // 
            this.txt_chinese.Location = new System.Drawing.Point(72, 88);
            this.txt_chinese.Name = "txt_chinese";
            this.txt_chinese.Size = new System.Drawing.Size(188, 21);
            this.txt_chinese.TabIndex = 35;
            // 
            // txt_volc
            // 
            this.txt_volc.Location = new System.Drawing.Point(72, 61);
            this.txt_volc.Name = "txt_volc";
            this.txt_volc.Size = new System.Drawing.Size(188, 21);
            this.txt_volc.TabIndex = 34;
            // 
            // txt_phrase_id
            // 
            this.txt_phrase_id.Location = new System.Drawing.Point(72, 35);
            this.txt_phrase_id.Name = "txt_phrase_id";
            this.txt_phrase_id.Size = new System.Drawing.Size(188, 21);
            this.txt_phrase_id.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 32;
            this.label4.Text = "chinese:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 31;
            this.label3.Text = "volc:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 30;
            this.label2.Text = "id:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 12);
            this.label1.TabIndex = 29;
            this.label1.Text = "_nvd_dictionary";
            // 
            // txt_cve
            // 
            this.txt_cve.Location = new System.Drawing.Point(72, 115);
            this.txt_cve.Name = "txt_cve";
            this.txt_cve.Size = new System.Drawing.Size(188, 21);
            this.txt_cve.TabIndex = 41;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 40;
            this.label5.Text = "cve:";
            // 
            // CAddVolDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 199);
            this.Controls.Add(this.txt_cve);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.FindBtn);
            this.Controls.Add(this.ModifyBtn);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.txt_chinese);
            this.Controls.Add(this.txt_volc);
            this.Controls.Add(this.txt_phrase_id);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CAddVolDlg";
            this.Text = "CAddVolDlg";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Button FindBtn;
        private System.Windows.Forms.Button ModifyBtn;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.TextBox txt_chinese;
        private System.Windows.Forms.TextBox txt_volc;
        private System.Windows.Forms.TextBox txt_phrase_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_cve;
        private System.Windows.Forms.Label label5;
    }
}