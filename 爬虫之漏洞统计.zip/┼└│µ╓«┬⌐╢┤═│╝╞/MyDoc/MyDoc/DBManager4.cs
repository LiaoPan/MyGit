﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

//using Microsoft.ApplicationBlocks.Data;


namespace MyDoc
{
    public class DBManager4
    {

        public static List<Uri> NVD_CVE()
        {
            List<Uri> urlIndex = new List<Uri>();


            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP_db4 + ";database=" + VolOverAll.DataBaseName_db4 + ";uid=" + VolOverAll.DataUid_db4 + ";pwd=" + VolOverAll.DataPassword_db4;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    SqlCommand com2 = new SqlCommand();
                    com2.CommandType = CommandType.Text;

                    VolOverAll.DataBaseNameLink = "cvd";
                    string databasename2 = "cnvd";
                    string databasewhere2 = "where cve <> ''";
                    //int a = 10000;
                    VolOverAll.DataBaseWhere = "where id > 20020716";
                    com.CommandText = "select * from " + VolOverAll.DataBaseNameLink + " " + VolOverAll.DataBaseWhere + " " + "order by cvd";
                    com.Connection = con;
                    com2.CommandText = "select * from " + databasename2 + " " + databasewhere2 + " " + "order by cvd";
                    com2.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet dscl = new DataSet();
                    da.Fill(dscl);
                    SqlDataAdapter da2 = new SqlDataAdapter(com2);
                    DataSet dscl2 = new DataSet();
                    da2.Fill(dscl2);

                    for (int k = 0; k < dscl.Tables[0].Rows.Count; k++)
                    {
                        string str = (string)dscl.Tables[0].Rows[k]["url"];
                        //http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-1999-1191
                        str = str.Substring(48);
                        dscl.Tables[0].Rows[k]["cve"] = str;
                        dscl.Tables[0].Rows[k]["cvd"] = k+1;
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Update(dscl);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlIndex;
        }

        public static DataSet OpSQLWrite(string SQLSentence)
        {
            DataSet ds = new DataSet();

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP_db4 + ";database=" + VolOverAll.DataBaseName_db4 + ";uid=" + VolOverAll.DataUid_db4 + ";pwd=" + VolOverAll.DataPassword_db4;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;

                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    com.ExecuteNonQuery();

                    //SqlDataAdapter da = new SqlDataAdapter(com);
                    ////DataSet dscl = new DataSet();
                    //da.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return ds;
        }

        public static int OpSQLGetInt(string SQLSentence)
        {
            DataSet ds = new DataSet();
            int urlnum = -1;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP_db4 + ";database=" + VolOverAll.DataBaseName_db4 + ";uid=" + VolOverAll.DataUid_db4 + ";pwd=" + VolOverAll.DataPassword_db4;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    //string SQLSentence = "select count(*) from cvd_osvdb2";
                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    //com.ExecuteNonQuery();

                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    urlnum = dr.GetInt32(0);
                    //urlnum = dr.GetInt64(0);
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlnum;
        }

        public static Double OpSQLGetInt64(string SQLSentence)
        {
            DataSet ds = new DataSet();
            Double urlnum = -1;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP_db4 + ";database=" + VolOverAll.DataBaseName_db4 + ";uid=" + VolOverAll.DataUid_db4 + ";pwd=" + VolOverAll.DataPassword_db4;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    //string SQLSentence = "select count(*) from cvd_osvdb2";
                    com.CommandText = SQLSentence;
                    com.Connection = con;
                    //com.ExecuteNonQuery();

                    SqlDataReader dr = com.ExecuteReader();
                    dr.Read();
                    urlnum = dr.GetInt64(0);
                    //urlnum = dr.GetInt64(0);
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                int a = 0;
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlnum;
        }

        public static string OpSQLGetString(string SQLSentence)
        {
            //List<Uri> urlIndex = new List<Uri>();
            string urlnum = "";
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP_db4 + ";database=" + VolOverAll.DataBaseName_db4 + ";uid=" + VolOverAll.DataUid_db4 + ";pwd=" + VolOverAll.DataPassword_db4;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dscl);
                    urlnum = (string)dscl.Tables[0].Rows[0][0];
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return urlnum;
        }

        public static DataSet OpSQLGetTable(string SQLSentence)
        {
            //List<Uri> urlIndex = new List<Uri>();
            DataSet dscl = new DataSet();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = " + VolOverAll.DataBaseIP_db4 + ";database=" + VolOverAll.DataBaseName_db4 + ";uid=" + VolOverAll.DataUid_db4 + ";pwd=" + VolOverAll.DataPassword_db4;
            //con.ConnectionString = "Data Source = " + VolOverAll.DateBaseIP + ";database=" + VolOverAll.DateBaseName + ";uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = SQLSentence;
                    com.Connection = con;

                    SqlDataAdapter da = new SqlDataAdapter(com);
                    da.Fill(dscl);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }
            finally
            {
                con.Close();
            }

            return dscl;
        }
 
    }


}
