﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

//Excel
using System.Data.OleDb;    


namespace MyDoc
{
    public partial class Translations : Form
    {
        //DataSet ds = new DataSet();
        //SqlConnection con = new SqlConnection();
        //SqlCommand com = new SqlCommand();
        //SqlDataAdapter da = new SqlDataAdapter();
        public Translations()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            int rowindex = e.RowIndex;
            int columnindex = e.ColumnIndex;
            DBManager.GridRow = e.RowIndex;
            DBManager.GridColumn = e.ColumnIndex;
            DBManager.flagtods = 1;

            string value = "";

            try
            { 
                value = dataGridView1.Rows[rowindex].Cells[columnindex].Value.ToString();

                OverView.Text = string.Format("{0}", value);
                OverView.Refresh();
                OverView.Refresh();

                textCVE.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow][4];
                textCVE.Refresh();
                textCVE.Refresh();
            }
            catch (Exception exc) { MessageBox.Show("点击失败"); }
        }

        private void dataGridView2_CellClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            int rowindex = e.RowIndex;
            int columnindex = e.ColumnIndex;
            DBManager.GridRow = e.RowIndex;
            DBManager.GridColumn = e.ColumnIndex;
            DBManager.flagtods = 2;

            string value = "";

            try
            {
                //获得当前行的第一列的值  
                value = dataGridView2.Rows[rowindex].Cells[columnindex].Value.ToString();

                OverView.Text = string.Format("{0}", value);
                OverView.Refresh();
                OverView.Refresh();
            }
            catch (Exception exc) { MessageBox.Show("点击失败"); }
        }

        private void Translations_Load(object sender, EventArgs e)
        {
            //ReadOut();
            //if (DBManager.ds1flag == true)
            //{
            //    dataGridView1.DataSource = DBManager.ds1.Tables[0];
            //    dataGridView1.Refresh();
            //}
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            int rowindex = e.RowIndex;
            int columnindex = e.ColumnIndex;
            DBManager.GridRow = e.RowIndex;
            DBManager.GridColumn = e.ColumnIndex;
            DBManager.flagtods = 1;

            string value = "";

            try
            {
                //获得当前行的第一列的值  
                value = dataGridView1.Rows[rowindex].Cells[columnindex].Value.ToString();

                OverView.Text = string.Format("{0}", value);
                OverView.Refresh();
                OverView.Refresh();

                textCVE.Text = (string)DBManager.ds1.Tables[0].Rows[DBManager.GridRow][4];
                textCVE.Refresh();
                textCVE.Refresh();
            }
            catch (Exception exc) { MessageBox.Show("点击失败"); }
        }

        private void dataGridView2_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            int rowindex = e.RowIndex;
            int columnindex = e.ColumnIndex;
            DBManager.GridRow = e.RowIndex;
            DBManager.GridColumn = e.ColumnIndex;
            DBManager.flagtods = 1;

            string value = "";

            try
            {
                //获得当前行的第一列的值  
                value = dataGridView2.Rows[rowindex].Cells[columnindex].Value.ToString();

                OverView.Text = string.Format("{0}", value);
                OverView.Refresh();
                OverView.Refresh();
            }
            catch (Exception exc) { MessageBox.Show("点击失败"); }
        }

        private void 保存_Click(object sender, EventArgs e)
        {
            if (DBManager.flagtods != 1)
            {
                MessageBox.Show("没有选中");
                return;
            }
            //if (textName.Text == "" || textImpact.Text == "" || texttrans.Text == "")
            if (textName.Text == "" || texttrans.Text == "")
            {
                MessageBox.Show("存在空值");
                return;
            }
                
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][36] = textName.Text;
            //DBManager.ds1.Tables[0].Rows[DBManager.GridRow][28] = textImpact.Text;
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][28] = GetImpact();
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][27] = texttrans.Text;
            WriteIn();
        }

        public string GetImpact()
        {
            string renyi = "任意代码执行";
            string xinxi = "信息泄露";
            string quanxian = "权限提升";
            string jujue = "拒绝服务";
            string weizhistr = "未知";

            string ret = "";
            bool flag = false;
            if(renyidaimazhixing.Checked==true)
            {
                ret = ret + renyi;
                flag = true;
            }
            if (xinxixielu.Checked == true)
            {
                if (flag == true)
                    ret = ret + ", ";
                ret = ret + xinxi;
            }
            if (quanxiantisheng.Checked == true)
            {
                if (flag == true)
                    ret = ret + ", ";
                ret = ret + quanxian;
            }
            if (jujuefuwu.Checked == true)
            {
                if (flag == true)
                    ret = ret + ", ";
                ret = ret + jujue;
            }
            if (weizhi.Checked == true)
            {
                if (flag == true)
                    return ret;
                ret = ret + weizhistr;
            }

            return ret;

        }

        public void WriteIn()
        {
            //MessageBox.Show("1");
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            try
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    SqlCommand com = new SqlCommand();
                    com.CommandType = CommandType.Text;
                    com.CommandText = "select * from NVD2";
                    com.Connection = con;

                    //MessageBox.Show("2");
                    SqlDataAdapter da = new SqlDataAdapter(com);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    //MessageBox.Show("3");
                    //string str = ds.Tables[0].TableName;

                    //ds.Tables[0].Rows[0][1] = "aaa";
                    DataTable dtShow = new DataTable();
                    //dtShow = (DataTable)dataGridView1.DataSource;
                    dtShow = DBManager.ds1.Tables[0];
                    for (int k = 0; k < dtShow.Rows.Count; k++)
                    {
                        string str1 = (string)dtShow.Rows[k][4];
                        string str2 = (string)dtShow.Rows[k][8];
                        //dtShow.Rows[k][27] = str1 + "--" + str2;

                        string str3 = (string)dtShow.Rows[k][14];
                        //dtShow.Rows[k][28] = str1 + "--" + str3;
                    }
                    //MessageBox.Show("4");
                    ds.Tables[0].Rows.Clear();
                    for (int i = 0; i < dtShow.Rows.Count; i++)
                    {
                        ds.Tables[0].ImportRow(dtShow.Rows[i]);
                    }

                    SqlCommandBuilder scb = new SqlCommandBuilder(da);
                    da.Update(ds);
                    MessageBox.Show("保存完成");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("写入失败");
            }
            finally
            {
                con.Close();
            }
        }

        private void load_Click(object sender, EventArgs e)
        {

            LoadNVD2 loadnvd2 = new LoadNVD2();
            loadnvd2.Show();
            //MessageBox.Show("");
        }

        private void 刷新_Click(object sender, EventArgs e)
        {
            if (DBManager.ds1flag == true)
            {
                dataGridView1.DataSource = DBManager.ds1.Tables[0];
                dataGridView1.Refresh();
                DataTable dt = DBManager.ds1.Tables[0].Copy();
                DBManager.ds2.Tables.Clear();
                DBManager.ds2.Tables.Add(dt);
                dataGridView2.DataSource = DBManager.ds2.Tables[0];
                DBManager.ds2.Tables[0].Rows.Clear();
                dataGridView1.Refresh();
                DBManager.ds1flag = false;
            }
        }

        private void add_Click(object sender, EventArgs e)
        {
            DBManager.GridRow = dataGridView1.CurrentCell.RowIndex;
            DBManager.GridColumn = dataGridView1.CurrentCell.ColumnIndex;
            DBManager.ds2.Tables[0].ImportRow(DBManager.ds1.Tables[0].Rows[DBManager.GridRow]);
            
            dataGridView2.Refresh();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            //DBManager.ds2.Tables[0].Rows[DBManager.GridRow].Delete();
            DBManager.GridRow = dataGridView2.CurrentCell.RowIndex;
            DBManager.GridColumn = dataGridView2.CurrentCell.ColumnIndex;
            DBManager.ds2.Tables[0].Rows[DBManager.GridRow].Delete();
            DBManager.ds2.Tables[0].AcceptChanges(); 
            //myRemoveRow.Delete();
            //DBManager.ds2.Tables[0].AcceptChanges(); 
            dataGridView2.Refresh();
        }

        private void DocWeek_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void 修改_Click(object sender, EventArgs e)
        {
            if (DBManager.flagtods != 1)
            {
                MessageBox.Show("没有选中");
                return;
            }
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][DBManager.GridColumn] = OverView.Text;
        }

        private void addCVE_Click(object sender, EventArgs e)
        {
            DBManager.GridRow = dataGridView1.CurrentCell.RowIndex;
            DBManager.GridColumn = dataGridView1.CurrentCell.ColumnIndex;
            DBManager.GridRow2 = dataGridView2.CurrentCell.RowIndex;
            DBManager.GridColumn2 = dataGridView2.CurrentCell.ColumnIndex;
            //DBManager.ds2.Tables[0].ImportRow(DBManager.ds1.Tables[0].Rows[DBManager.GridRow]);
            DBManager.ds2.Tables[0].Rows[DBManager.GridRow2][4] = 
            DBManager.ds2.Tables[0].Rows[DBManager.GridRow2][4] + ", " +
            DBManager.ds1.Tables[0].Rows[DBManager.GridRow][4];

            dataGridView2.Refresh();
        }

        private void ExcelToMS_Click(object sender, EventArgs e)
        {
            string connString = "Data Source = 127.0.0.1;database=NVD;uid=sa;pwd=sqlserver";
            System.Windows.Forms.OpenFileDialog fd = new OpenFileDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                TransferData(fd.FileName, "sheet2", connString);
            }  
        }

        public void TransferData(string excelFile, string sheetName, string connectionString)
        {
            DataSet ds = new DataSet();
            try
            {
                //获取全部数据    
                string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                     "Data Source=" + excelFile + ";" + "Extended Properties=Excel 8.0;";
                OleDbConnection conn = new OleDbConnection(strConn);
                conn.Open();
                string strExcel = "";
                OleDbDataAdapter myCommand = null;
                strExcel = string.Format("select * from [{0}$]", sheetName);
                myCommand = new OleDbDataAdapter(strExcel, strConn);
                myCommand.Fill(ds, sheetName);

                //如果目标表不存在则创建    
                string strSql = string.Format("if object_id('{0}') is null create table {0}(", sheetName);
                foreach (System.Data.DataColumn c in ds.Tables[0].Columns)
                {
                    strSql += string.Format("[{0}] varchar(255),", c.ColumnName);
                }
                strSql = strSql.Trim(',') + ")";

                using (System.Data.SqlClient.SqlConnection sqlconn =
                    new System.Data.SqlClient.SqlConnection(connectionString))
                {
                    sqlconn.Open();
                    System.Data.SqlClient.SqlCommand command = sqlconn.CreateCommand();
                    command.CommandText = strSql;
                    command.ExecuteNonQuery();
                    sqlconn.Close();
                }

                ////用bcp导入数据    
                //using (System.Data.SqlClient.SqlBulkCopy bcp =
                //        new System.Data.SqlClient.SqlBulkCopy(connectionString))
                //{
                //    bcp.SqlRowsCopied +=
                //         new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                //    bcp.BatchSize = 100;//每次传输的行数    
                //    bcp.NotifyAfter = 100;//进度提示的行数    
                //    bcp.DestinationTableName = sheetName;//目标表    
                //    bcp.WriteToServer(ds.Tables[0]);
                //}
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public void SetDBMRank(string serverstr = "xx", string highstr = "xx", string middlestr = "xx", string lowstr = "xx")
        {
            DBManager.severestr = serverstr;
            DBManager.highstr = highstr;
            DBManager.lowstr = lowstr;
            DBManager.middlestr = middlestr;
        }

        private void Translations2_Click(object sender, EventArgs e)
        {
            translation2 trans2 = new translation2();
            trans2.Show();
        }

    }
}
