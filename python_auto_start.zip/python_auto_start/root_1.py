#!/usr/bin/env python
#coding:utf-8
#time:2015/7/13
#athuor:L.P
#main:ÈÃÕâ¸ö³ÌÐò×ÔÆô¶¯
##############保证时间是24小时制########
import os
import time
from datetime import timedelta,datetime
seconds_per_day = 24*60*60

curTime = datetime.now()   #现在时刻
print curTime
desTime = curTime.replace(hour=9,minute=6,second=0,microsecond=0) #程序执行时刻
print "destime::"
print desTime
delta = desTime - curTime
print delta
skipSeconds = delta.total_seconds()
print 'skipseconds:%d'%skipSeconds
#time.replace([ hour[ , minute[ , second[ , microsecond[ , tzinfo] ] ] ] ] )：创建一个新的时间对象，用参数指定的时、分、秒、微秒代替原有对象中的属性（原有对象仍保持不变）


time.sleep(skipSeconds)
os.system(r"I:\python_auto_start\root_2.bat")  #代替人工输入命令 :调用命令
print 'ok'
#while(1):
	#print "root success!!!_1"
