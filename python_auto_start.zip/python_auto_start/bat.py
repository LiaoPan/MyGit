#coding:utf-8
import os
os.system(r"I:\python_auto_start\root_2.bat")
